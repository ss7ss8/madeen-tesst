import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../data/local/hive_service.dart';
import '../../../data/models/debt.dart';
import '../../customers/providers/customers_provider.dart';
import '../../customers/providers/debts_provider.dart';
import '../../../core/services/sync_service.dart';

enum InstallmentFilter { all, pending, paid, overdue }

class InstallmentData {
  final Debt debt;
  final int index;
  final double amount;
  final DateTime dueDate;
  final String status;
  final DateTime? paidAt;
  final String? customerName;
  final String? customerPhone;

  InstallmentData({
    required this.debt,
    required this.index,
    required this.amount,
    required this.dueDate,
    required this.status,
    this.paidAt,
    this.customerName,
    this.customerPhone,
  });

  bool get isPaid => status == 'paid';
  bool get isOverdue => !isPaid && dueDate.isBefore(DateTime.now());
}

class InstallmentsNotifier extends StateNotifier<List<InstallmentData>> {
  final Ref _ref;
  InstallmentFilter _filter = InstallmentFilter.all;
  String _searchQuery = '';
  List<InstallmentData> _allInstallments = [];

  late final VoidCallback _syncListener;

  InstallmentsNotifier(this._ref) : super([]) {
    loadInstallments();
    _syncListener = () {
      final debts = HiveService.getAllDebts();
      final currentCount = debts.fold(0, (sum, d) => sum + (d.installmentDates?.length ?? 0));
      if (currentCount != state.length) {
        loadInstallments();
      }
    };
    syncCompletedVersion.addListener(_syncListener);
  }

  @override
  void dispose() {
    syncCompletedVersion.removeListener(_syncListener);
    super.dispose();
  }

  InstallmentFilter get filter => _filter;
  String get searchQuery => _searchQuery;
  List<InstallmentData> get allInstallments => _allInstallments;

  void loadInstallments() {
    final debts = HiveService.getAllDebts();
    final customers = HiveService.getAllCustomers();
    final customerMap = {for (final c in customers) c.id: c};

    List<InstallmentData> installments = [];

    for (final debt in debts) {
      if (!debt.isInstallment) continue;
      if (debt.installmentDates == null || debt.installmentAmounts == null) continue;

      final customer = customerMap[debt.customerId];

      for (int i = 0; i < debt.installmentDates!.length; i++) {
        final amount = i < debt.installmentAmounts!.length
            ? debt.installmentAmounts![i]
            : 0.0;
        final dueDate = debt.installmentDates![i];
        final status = (debt.installmentStatuses != null &&
                i < debt.installmentStatuses!.length)
            ? debt.installmentStatuses![i]
            : 'pending';
        final paidAt = (debt.installmentPaidAts != null &&
                i < debt.installmentPaidAts!.length)
            ? debt.installmentPaidAts![i]
            : null;

        installments.add(InstallmentData(
          debt: debt,
          index: i,
          amount: amount,
          dueDate: dueDate,
          status: status,
          paidAt: paidAt,
          customerName: customer?.name,
          customerPhone: customer?.phone,
        ));
      }
    }

    // Apply search
    if (_searchQuery.isNotEmpty) {
      installments = installments.where((inst) {
        final name = inst.customerName?.toLowerCase() ?? '';
        return name.contains(_searchQuery.toLowerCase());
      }).toList();
    }

    // Cache full list before status filter (for debt-group display)
    _allInstallments = List.from(installments);

    // Apply filter
    switch (_filter) {
      case InstallmentFilter.all:
        break;
      case InstallmentFilter.pending:
        installments = installments
            .where((i) => !i.isPaid && !i.isOverdue)
            .toList();
        break;
      case InstallmentFilter.paid:
        installments = installments.where((i) => i.isPaid).toList();
        break;
      case InstallmentFilter.overdue:
        installments = installments.where((i) => i.isOverdue).toList();
        break;
    }

    // Sort: overdue first, then pending, then paid
    installments.sort((a, b) {
      if (a.isOverdue && !b.isOverdue) return -1;
      if (!a.isOverdue && b.isOverdue) return 1;
      if (!a.isPaid && b.isPaid) return -1;
      if (a.isPaid && !b.isPaid) return 1;
      return a.dueDate.compareTo(b.dueDate);
    });

    state = installments;
  }

  void setFilter(InstallmentFilter filter) {
    _filter = filter;
    loadInstallments();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    loadInstallments();
  }

  Future<void> toggleInstallmentPaid({
    required String debtId,
    required int installmentIndex,
    required bool markAsPaid,
  }) async {
    await _ref.read(debtsProvider.notifier).toggleInstallmentPaid(
          debtId: debtId,
          installmentIndex: installmentIndex,
          markAsPaid: markAsPaid,
        );
    loadInstallments();
    _ref.invalidate(customersProvider);
  }

  int get totalInstallments => state.length;
  int get paidCount => state.where((i) => i.isPaid).length;
  int get pendingCount => state.where((i) => !i.isPaid && !i.isOverdue).length;
  int get overdueCount => state.where((i) => i.isOverdue).length;
  double get totalAmount =>
      state.fold<double>(0, (sum, i) => sum + i.amount);
  double get paidAmount =>
      state.where((i) => i.isPaid).fold<double>(0, (sum, i) => sum + i.amount);

  Map<String, List<InstallmentData>> get groupedByDebt {
    final map = <String, List<InstallmentData>>{};
    for (final inst in state) {
      map.putIfAbsent(inst.debt.id, () => []).add(inst);
    }
    return map;
  }
}

final installmentsProvider =
    StateNotifierProvider<InstallmentsNotifier, List<InstallmentData>>((ref) {
  return InstallmentsNotifier(ref);
});

final installmentStatsProvider = Provider<InstallmentStats>((ref) {
  final installments = ref.watch(installmentsProvider);
  return InstallmentStats(
    total: installments.length,
    paid: installments.where((i) => i.isPaid).length,
    pending: installments.where((i) => !i.isPaid && !i.isOverdue).length,
    overdue: installments.where((i) => i.isOverdue).length,
    totalAmount: installments.fold<double>(0, (sum, i) => sum + i.amount),
    paidAmount:
        installments.where((i) => i.isPaid).fold<double>(0, (sum, i) => sum + i.amount),
  );
});

class InstallmentStats {
  final int total;
  final int paid;
  final int pending;
  final int overdue;
  final double totalAmount;
  final double paidAmount;

  InstallmentStats({
    required this.total,
    required this.paid,
    required this.pending,
    required this.overdue,
    required this.totalAmount,
    required this.paidAmount,
  });

  double get completionRate => total > 0 ? paid / total : 0;
  double get remainingAmount => totalAmount - paidAmount;
}
