import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/constants/strings.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/services/notification_service.dart';
import '../../customers/providers/customers_provider.dart';
import '../../customers/providers/debts_provider.dart';
import '../../inventory/providers/inventory_provider.dart';
import '../../../data/local/hive_service.dart';
import '../../../data/models/customer.dart';
import '../../../data/models/product.dart';

class AddInstallmentSheet extends ConsumerStatefulWidget {
  const AddInstallmentSheet({super.key});

  @override
  ConsumerState<AddInstallmentSheet> createState() =>
      _AddInstallmentSheetState();
}

class _AddInstallmentSheetState extends ConsumerState<AddInstallmentSheet> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _productNameController = TextEditingController();
  final _installmentCountController = TextEditingController(text: '6');
  final _notesController = TextEditingController();

  Customer? _selectedCustomer;
  Product? _selectedProduct;
  int _productQuantity = 1;
  int _installmentCount = 6;
  String _interval = 'monthly';
  DateTime _startDate = DateTime.now();
  String? _limitWarning;

  @override
  void dispose() {
    _amountController.dispose();
    _productNameController.dispose();
    _installmentCountController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final customers = ref.watch(customersProvider);

    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          _buildHandle(),
          _buildHeader(),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(
                AppDimensions.spacingMd,
                AppDimensions.spacingMd,
                AppDimensions.spacingMd,
                MediaQuery.of(context).viewInsets.bottom +
                    AppDimensions.spacingMd,
              ),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildCustomerDropdown(customers),
                    const SizedBox(height: AppDimensions.spacingMd),
                    _buildAmountField(),
                    if (_limitWarning != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: AppColors.warning.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: AppColors.warning.withValues(alpha: 0.5),
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.warning_amber,
                                color: AppColors.warning,
                                size: 20,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  _limitWarning!,
                                  style: const TextStyle(fontSize: 13),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    const SizedBox(height: AppDimensions.spacingMd),
                    _buildProductSection(),
                    const SizedBox(height: AppDimensions.spacingMd),
                    _buildInstallmentConfig(),
                    const SizedBox(height: AppDimensions.spacingMd),
                    _buildIntervalSelector(),
                    const SizedBox(height: AppDimensions.spacingMd),
                    _buildStartDatePicker(),
                    const SizedBox(height: AppDimensions.spacingMd),
                    _buildNotesField(),
                    const SizedBox(height: AppDimensions.spacingMd),
                    _buildPreview(),
                  ],
                ),
              ),
            ),
          ),
          _buildSubmitButton(),
        ],
      ),
    );
  }

  Widget _buildHandle() {
    return Center(
      child: Container(
        margin: const EdgeInsets.only(top: 8),
        width: 40,
        height: 4,
        decoration: BoxDecoration(
          color: AppColors.dividerLight,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(AppDimensions.spacingMd),
      child: Row(
        children: [
          const Icon(Icons.receipt_long, color: AppColors.primary),
          const SizedBox(width: AppDimensions.spacingSm),
          Text(
            'إضافة دين بالتقسيط',
            style: Theme.of(
              context,
            ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
          const Spacer(),
          IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.close),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomerDropdown(List<Customer> customers) {
    return DropdownButtonFormField<Customer>(
      initialValue: _selectedCustomer,
      decoration: const InputDecoration(
        labelText: 'اختر الزبون *',
        prefixIcon: Icon(Icons.person),
        border: OutlineInputBorder(),
      ),
      items: customers.map((customer) {
        return DropdownMenuItem(value: customer, child: Text(customer.name));
      }).toList(),
      onChanged: (value) => setState(() => _selectedCustomer = value),
      validator: (value) => value == null ? 'اختر الزبون' : null,
    );
  }

  double get _currentTotalDebt {
    if (_selectedCustomer == null) return 0;
    final debts = HiveService.getDebtsByCustomer(_selectedCustomer!.id);
    return debts.fold<double>(0, (sum, d) => sum + d.remainingAmount);
  }

  void _updateLimitWarning() {
    if (_selectedCustomer == null) return;
    final limit = _selectedCustomer!.maxDebtLimit;
    if (limit == null || limit <= 0) {
      setState(() => _limitWarning = null);
      return;
    }
    final newAmount = double.tryParse(
      _amountController.text.replaceAll(RegExp(r'[^\d.]'), ''),
    );
    if (newAmount == null || newAmount <= 0) {
      setState(() => _limitWarning = null);
      return;
    }
    final projectedTotal = _currentTotalDebt + newAmount;
    if (projectedTotal > limit) {
      setState(() {
        _limitWarning =
            'تنبيه: هذا الدين سيجعل رصيد الزبون يتجاوز الحد الأقصى المحدد (${Formatters.formatCurrency(limit)})';
      });
    } else {
      setState(() => _limitWarning = null);
    }
  }

  Widget _buildAmountField() {
    return TextFormField(
      controller: _amountController,
      keyboardType: TextInputType.number,
      inputFormatters: [
        FilteringTextInputFormatter.allow(RegExp(r'\d')),
      ],
      decoration: const InputDecoration(
        labelText: 'المبلغ الإجمالي *',
        prefixIcon: Icon(Icons.attach_money),
        border: OutlineInputBorder(),
        suffixText: AppStrings.currency,
      ),
      onChanged: (_) => _updateLimitWarning(),
      validator: (value) {
        if (value == null || value.isEmpty) return 'أدخل المبلغ';
        final amount = double.tryParse(value);
        if (amount == null || amount <= 0) return 'المبلغ غير صحيح';
        return null;
      },
    );
  }

  Widget _buildProductSection() {
    final products = ref.watch(productsProvider);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextFormField(
          controller: _productNameController,
          decoration: const InputDecoration(
            labelText: 'اسم السلعة *',
            hintText: 'أدخل اسم السلعة أو اختر من المخزون',
            prefixIcon: Icon(Icons.shopping_bag),
            border: OutlineInputBorder(),
          ),
          validator: (value) {
            if (value == null || value.trim().isEmpty) {
              return 'أدخل اسم السلعة';
            }
            return null;
          },
        ),
        const SizedBox(height: AppDimensions.spacingSm),
        DropdownButtonFormField<Product>(
          isExpanded: true,
          decoration: const InputDecoration(
            labelText: 'اختيار من المخزون (اختياري)',
            prefixIcon: Icon(Icons.inventory_2),
            border: OutlineInputBorder(),
          ),
          items: products.map((product) {
            final isOutOfStock = product.quantity <= 0;
            return DropdownMenuItem(
              value: product,
              enabled: !isOutOfStock,
              child: Text(
                isOutOfStock
                    ? '${product.name} - نفذ من المخزون'
                    : '${product.name} (متوفر: ${product.quantity})',
                style: TextStyle(color: isOutOfStock ? Colors.grey : null),
              ),
            );
          }).toList(),
          onChanged: (product) {
            if (product == null || product.quantity <= 0) return;
            setState(() {
              _selectedProduct = product;
              _productQuantity = 1;
              final total = product.salePrice * _productQuantity;
              if (_amountController.text.isEmpty ||
                  double.tryParse(_amountController.text) == 0) {
                _amountController.text = total.toStringAsFixed(0);
              }
              _productNameController.text = product.name;
            });
          },
        ),
        if (_selectedProduct != null) ...[
          const SizedBox(height: AppDimensions.spacingSm),
          Row(
            children: [
              Text('الكمية:', style: Theme.of(context).textTheme.titleSmall),
              const SizedBox(width: AppDimensions.spacingMd),
              IconButton(
                onPressed: _productQuantity > 1
                    ? () => setState(() => _productQuantity--)
                    : null,
                icon: const Icon(Icons.remove_circle_outline),
              ),
              Text(
                _productQuantity.toString(),
                style: Theme.of(context).textTheme.titleMedium,
              ),
              IconButton(
                onPressed: _productQuantity < _selectedProduct!.quantity
                    ? () => setState(() => _productQuantity++)
                    : null,
                icon: const Icon(Icons.add_circle_outline),
              ),
              const Spacer(),
              Text(
                'المجموع: ${(_selectedProduct!.salePrice * _productQuantity).toStringAsFixed(0)} د.ع',
                style: Theme.of(
                  context,
                ).textTheme.titleSmall?.copyWith(color: AppColors.primary),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildInstallmentConfig() {
    return Row(
      children: [
        Expanded(
          child: TextFormField(
            controller: _installmentCountController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'عدد الأقساط *',
              prefixIcon: Icon(Icons.numbers),
              border: OutlineInputBorder(),
            ),
            onChanged: (value) {
              final count = int.tryParse(value);
              if (count != null && count > 0) {
                setState(() => _installmentCount = count);
              }
            },
            validator: (value) {
              if (value == null || value.isEmpty) return 'أدخل عدد الأقساط';
              final count = int.tryParse(value);
              if (count == null || count < 2) return 'الحد الأدنى قسطين';
              return null;
            },
          ),
        ),
      ],
    );
  }

  Widget _buildIntervalSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'فترة السداد',
          style: Theme.of(
            context,
          ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: AppDimensions.spacingSm),
        Row(
          children: [
            _intervalChip('weekly', 'أسبوعي'),
            const SizedBox(width: AppDimensions.spacingSm),
            _intervalChip('monthly', 'شهري'),
            const SizedBox(width: AppDimensions.spacingSm),
            _intervalChip('quarterly', 'ربع سنوي'),
          ],
        ),
      ],
    );
  }

  Widget _intervalChip(String value, String label) {
    final isSelected = _interval == value;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _interval = value),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected
                ? AppColors.primary.withValues(alpha: 0.15)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(AppDimensions.radiusSm),
            border: Border.all(
              color: isSelected ? AppColors.primary : AppColors.dividerLight,
              width: isSelected ? 2 : 1,
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              color: isSelected
                  ? AppColors.primary
                  : AppColors.textSecondaryLight,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStartDatePicker() {
    return ListTile(
      leading: const Icon(Icons.calendar_today),
      title: const Text('تاريخ بداية السداد'),
      subtitle: Text(Formatters.formatDate(_startDate)),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppDimensions.radiusSm),
        side: const BorderSide(color: AppColors.dividerLight),
      ),
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: _startDate,
          firstDate: DateTime.now(),
          lastDate: DateTime.now().add(const Duration(days: 365)),
        );
        if (picked != null) {
          setState(() => _startDate = picked);
        }
      },
    );
  }

  Widget _buildNotesField() {
    return TextFormField(
      controller: _notesController,
      maxLines: 2,
      decoration: const InputDecoration(
        labelText: 'ملاحظات (اختياري)',
        prefixIcon: Icon(Icons.note),
        border: OutlineInputBorder(),
      ),
    );
  }

  Widget _buildPreview() {
    final amount = double.tryParse(_amountController.text) ?? 0;
    if (amount <= 0 || _installmentCount < 2) return const SizedBox.shrink();

    final installmentAmount = amount / _installmentCount;
    final dates = _generateDates();

    return Card(
      color: AppColors.primary.withValues(alpha: 0.05),
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.spacingMd),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.preview, size: 18, color: AppColors.primary),
                const SizedBox(width: 4),
                Text(
                  'معاينة جدول الأقساط',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
            const Divider(),
            if (_productNameController.text.isNotEmpty)
              _previewRow('السلعة', _productNameController.text),
            _previewRow('المبلغ الإجمالي', Formatters.formatCurrency(amount)),
            _previewRow('عدد الأقساط', '$_installmentCount'),
            _previewRow(
              'مبلغ القسط',
              Formatters.formatCurrency(installmentAmount),
            ),
            _previewRow('الفترة', _intervalLabel),
            const SizedBox(height: AppDimensions.spacingSm),
            Text(
              'أول 3 تواريخ:',
              style: Theme.of(
                context,
              ).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600),
            ),
            ...dates
                .take(3)
                .map(
                  (date) => Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.circle,
                          size: 6,
                          color: AppColors.primary,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          Formatters.formatDate(date),
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                ),
          ],
        ),
      ),
    );
  }

  Widget _previewRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 12)),
          Text(
            value,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  String get _intervalLabel {
    switch (_interval) {
      case 'weekly':
        return 'أسبوعي';
      case 'monthly':
        return 'شهري';
      case 'quarterly':
        return 'ربع سنوي';
      default:
        return 'شهري';
    }
  }

  List<DateTime> _generateDates() {
    final dates = <DateTime>[];
    for (int i = 0; i < _installmentCount; i++) {
      switch (_interval) {
        case 'weekly':
          dates.add(_startDate.add(Duration(days: 7 * i)));
          break;
        case 'monthly':
          dates.add(
            DateTime(_startDate.year, _startDate.month + i, _startDate.day),
          );
          break;
        case 'quarterly':
          dates.add(
            DateTime(
              _startDate.year,
              _startDate.month + (i * 3),
              _startDate.day,
            ),
          );
          break;
      }
    }
    return dates;
  }

  Widget _buildSubmitButton() {
    return Container(
      padding: const EdgeInsets.all(AppDimensions.spacingMd),
      child: SizedBox(
        width: double.infinity,
        height: 50,
        child: ElevatedButton(
          onPressed: _submit,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
            ),
          ),
          child: const Text(
            'حفظ الدين بالتقسيط',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedCustomer == null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('اختر الزبون')));
      return;
    }

    // Defense: reject out-of-stock product
    if (_selectedProduct != null && _selectedProduct!.quantity <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('هذا المنتج نفذ من المخزون، يرجى اختيار منتج آخر'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final amount = double.parse(_amountController.text);
    final installmentAmount = amount / _installmentCount;
    final dates = _generateDates();
    final amounts = List.generate(_installmentCount, (_) => installmentAmount);
    final productName = _productNameController.text.isNotEmpty
        ? _productNameController.text
        : _selectedProduct?.name;

    try {
      await ref
          .read(debtsProvider.notifier)
          .addDebt(
            customerId: _selectedCustomer!.id,
            amount: amount,
            productId: _selectedProduct?.id,
            productName: productName,
            productQuantity: _productQuantity,
            isInstallment: true,
            installmentCount: _installmentCount,
            installmentDates: dates,
            installmentAmounts: amounts,
            notes: _notesController.text.isNotEmpty
                ? _notesController.text
                : null,
          );

      final newTotalDebt = _currentTotalDebt + amount;
      final settings = HiveService.getAppSettings();
      await NotificationService.showLimitWarning(
        settings: settings,
        customer: _selectedCustomer!,
        totalDebt: newTotalDebt,
      );

      if (mounted) {
        HapticFeedback.lightImpact();
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تم حفظ الدين بالتقسيط بنجاح'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('خطأ: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }
}
