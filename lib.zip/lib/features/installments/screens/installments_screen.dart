import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/utils/formatters.dart';
import '../providers/installments_provider.dart';
import '../../customers/providers/debts_provider.dart';
import 'installment_detail_screen.dart';
import '../../../shared/widgets/customer_avatar.dart';

class InstallmentsScreen extends ConsumerStatefulWidget {
  const InstallmentsScreen({super.key});

  @override
  ConsumerState<InstallmentsScreen> createState() => _InstallmentsScreenState();
}

class _InstallmentsScreenState extends ConsumerState<InstallmentsScreen> {
  final _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final installments = ref.watch(installmentsProvider);
    final stats = ref.watch(installmentStatsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('الأقساط'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => _showSearch(context),
          ),
        ],
      ),
      body: Column(
        children: [
          _buildStatsHeader(stats),
          _buildFilterChips(),
          Expanded(
            child: installments.isEmpty
                ? _buildEmptyState()
                : _buildInstallmentsList(installments),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsHeader(InstallmentStats stats) {
    return Container(
      margin: const EdgeInsets.all(AppDimensions.spacingMd),
      padding: const EdgeInsets.all(AppDimensions.spacingMd),
      decoration: BoxDecoration(
        gradient: AppColors.primaryGradient,
        borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withValues(alpha: 0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _statItem('الكل', stats.total, Icons.receipt_long),
              _statItem('مدفوع', stats.paid, Icons.check_circle, color: AppColors.success),
              _statItem('معلق', stats.pending, Icons.pending, color: AppColors.warning),
              _statItem('متأخر', stats.overdue, Icons.warning, color: AppColors.error),
            ],
          ),
          const SizedBox(height: AppDimensions.spacingMd),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _statItem(
                'الإجمالي',
                stats.totalAmount.toInt(),
                Icons.attach_money,
                isAmount: true,
              ),
              _statItem(
                'المسدد',
                stats.paidAmount.toInt(),
                Icons.paid,
                isAmount: true,
                color: AppColors.success,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statItem(String label, int value, IconData icon,
      {Color? color, bool isAmount = false}) {
    return Column(
      children: [
        Icon(icon, color: color ?? Colors.white, size: 20),
        const SizedBox(height: 4),
        Text(
          isAmount ? Formatters.formatCurrency(value.toDouble()) : '$value',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withValues(alpha: 0.8),
            fontSize: 11,
          ),
        ),
      ],
    );
  }

  Widget _buildFilterChips() {
    final currentFilter = ref.watch(installmentsProvider.notifier).filter;

    return SizedBox(
      height: 50,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: AppDimensions.spacingMd),
        children: InstallmentFilter.values.map((filter) {
          final isSelected = currentFilter == filter;
          final label = _filterLabel(filter);
          final count = _filterCount(filter);

          return Padding(
            padding: const EdgeInsets.only(left: AppDimensions.spacingSm),
            child: FilterChip(
              label: Text('$label ($count)'),
              selected: isSelected,
              onSelected: (_) {
                ref.read(installmentsProvider.notifier).setFilter(filter);
              },
              selectedColor: AppColors.primary.withValues(alpha: 0.15),
              checkmarkColor: AppColors.primary,
              labelStyle: TextStyle(
                color: isSelected ? AppColors.primary : AppColors.textSecondaryLight,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              ),
              side: BorderSide(
                color: isSelected
                    ? AppColors.primary.withValues(alpha: 0.3)
                    : AppColors.dividerLight,
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  String _filterLabel(InstallmentFilter filter) {
    switch (filter) {
      case InstallmentFilter.all:
        return 'الكل';
      case InstallmentFilter.pending:
        return 'معلق';
      case InstallmentFilter.paid:
        return 'مدفوع';
      case InstallmentFilter.overdue:
        return 'متأخر';
    }
  }

  int _filterCount(InstallmentFilter filter) {
    final notifier = ref.read(installmentsProvider.notifier);
    switch (filter) {
      case InstallmentFilter.all:
        return notifier.totalInstallments;
      case InstallmentFilter.pending:
        return notifier.pendingCount;
      case InstallmentFilter.paid:
        return notifier.paidCount;
      case InstallmentFilter.overdue:
        return notifier.overdueCount;
    }
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.receipt_long, size: 64, color: AppColors.textSecondaryLight),
          const SizedBox(height: AppDimensions.spacingMd),
          Text(
            'لا توجد أقساط',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: AppColors.textSecondaryLight,
                ),
          ),
          const SizedBox(height: AppDimensions.spacingSm),
          Text(
            'أضف ديناً على شكل أقساط من صفحة الزبائن',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColors.textSecondaryLight,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildInstallmentsList(List<InstallmentData> installments) {
    // Use full unfiltered list for debt-group display
    final notifier = ref.read(installmentsProvider.notifier);
    final allInst = notifier.allInstallments;
    final allGrouped = <String, List<InstallmentData>>{};
    for (final inst in allInst) {
      allGrouped.putIfAbsent(inst.debt.id, () => []).add(inst);
    }

    // Determine which debt groups have at least one matching installment
    final matchedIds = installments.map((i) => i.debt.id).toSet();
    final displayGrouped = <String, List<InstallmentData>>{};
    for (final id in allGrouped.keys) {
      if (matchedIds.contains(id)) {
        displayGrouped[id] = allGrouped[id]!;
      }
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: AppDimensions.spacingMd),
      itemCount: displayGrouped.length,
      itemBuilder: (context, index) {
        final debtId = displayGrouped.keys.elementAt(index);
        final debtInstallments = displayGrouped[debtId]!;
        final first = debtInstallments.first;

        return _buildDebtGroup(debtInstallments, first);
      },
    );
  }

  Widget _buildDebtGroup(
      List<InstallmentData> installments, InstallmentData first) {
    final paidCount = installments.where((i) => i.isPaid).length;
    final totalCount = installments.length;
    final progress = totalCount > 0 ? paidCount / totalCount : 0.0;
    final hasOverdue = installments.any((i) => i.isOverdue);
    final allPaid = installments.every((i) => i.isPaid);
    final bool displayCardColor = hasOverdue || allPaid;

    return Card(
      margin: const EdgeInsets.only(bottom: AppDimensions.spacingMd),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
        side: displayCardColor
            ? BorderSide(
                color: hasOverdue
                    ? AppColors.error.withValues(alpha: 0.5)
                    : AppColors.success.withValues(alpha: 0.5),
                width: 1.5,
              )
            : BorderSide.none,
      ),
      color: displayCardColor
          ? (hasOverdue
              ? AppColors.error.withValues(alpha: 0.04)
              : AppColors.success.withValues(alpha: 0.04))
          : null,
      child: InkWell(
        onTap: () => _openDetail(first),
        borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
        child: Padding(
          padding: const EdgeInsets.all(AppDimensions.spacingMd),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CustomerAvatar(
                    name: first.customerName ?? '?',
                    radius: 20,
                  ),
                  const SizedBox(width: AppDimensions.spacingSm),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          first.customerName ?? 'غير معروف',
                          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                        Text(
                          'المنتج: ${first.debt.productName ?? "غير محدد"}',
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: AppColors.textSecondaryLight,
                              ),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    Formatters.formatCurrency(first.debt.amount),
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: AppColors.primary,
                        ),
                  ),
                  const SizedBox(width: AppDimensions.spacingSm),
                  SizedBox(
                    width: 32,
                    height: 32,
                    child: IconButton(
                      padding: EdgeInsets.zero,
                      iconSize: 20,
                      icon: Icon(
                        Icons.delete_outline,
                        color: AppColors.error.withValues(alpha: 0.7),
                      ),
                      onPressed: () => _confirmDelete(context, first),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppDimensions.spacingSm),
              Row(
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: progress,
                        backgroundColor: AppColors.dividerLight,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          progress >= 1.0
                              ? AppColors.success
                              : AppColors.primary,
                        ),
                        minHeight: 6,
                      ),
                    ),
                  ),
                  const SizedBox(width: AppDimensions.spacingSm),
                  Text(
                    '$paidCount/$totalCount',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ],
              ),
              const SizedBox(height: AppDimensions.spacingSm),
              Wrap(
                spacing: 4,
                runSpacing: 4,
                children: installments.take(6).map((inst) {
                  final isPaid = inst.isPaid;
                  final isOverdue = inst.isOverdue;
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: isPaid
                          ? AppColors.success.withValues(alpha: 0.15)
                          : isOverdue
                              ? AppColors.error.withValues(alpha: 0.15)
                              : AppColors.warning.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      '${inst.index + 1}',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        color: isPaid
                            ? AppColors.success
                            : isOverdue
                                ? AppColors.error
                                : AppColors.warning,
                      ),
                    ),
                  );
                }).toList(),
              ),
              if (installments.length > 6)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    '+${installments.length - 6} أقساط أخرى',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppColors.textSecondaryLight,
                        ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _openDetail(InstallmentData installment) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => InstallmentDetailScreen(installment: installment),
      ),
    );
  }

  void _confirmDelete(BuildContext context, InstallmentData installment) {
    final customerName = installment.customerName ?? 'هذا الزبون';
    final productName = installment.debt.productName ?? '';
    final totalInstallments = installment.debt.installmentCount;
    final paidCount = installment.debt.installmentPaidCount ?? 0;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        icon: Icon(Icons.delete_forever, color: AppColors.error, size: 40),
        title: const Text('حذف القسط'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
            Text('هل أنت متأكد من حذف أقساط $customerName؟'),
            if (productName.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(
                'المنتج: $productName',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.textSecondaryLight,
                    ),
              ),
            ],
            const SizedBox(height: 4),
            Text(
              'الأقساط: $paidCount مدفوعة من $totalInstallments',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppColors.textSecondaryLight,
                  ),
            ),
            const SizedBox(height: 8),
            const Text(
              'سيتم حذف جميع الأقساط المرتبطة بهذا الدين.',
              style: TextStyle(color: AppColors.error, fontSize: 12),
            ),
          ],
        ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () async {
              final navigator = Navigator.of(ctx);
              final messenger = ScaffoldMessenger.of(context);
              await ref
                  .read(debtsProvider.notifier)
                  .deleteDebt(installment.debt.id);
              if (ctx.mounted) {
                navigator.pop();
              }
              if (mounted) {
                messenger.showSnackBar(
                  const SnackBar(
                    content: Text('تم حذف الأقساط بنجاح'),
                    backgroundColor: Colors.green,
                  ),
                );
              }
            },
            style: FilledButton.styleFrom(backgroundColor: AppColors.error),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
  }

  void _showSearch(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('بحث في الأقساط'),
        content: TextField(
          controller: _searchController,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'اسم الزبون...',
            prefixIcon: Icon(Icons.search),
          ),
          onChanged: (value) {
            ref.read(installmentsProvider.notifier).setSearchQuery(value);
          },
        ),
        actions: [
          TextButton(
            onPressed: () {
              _searchController.clear();
              ref.read(installmentsProvider.notifier).setSearchQuery('');
              Navigator.of(context).pop();
            },
            child: const Text('مسح'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('إغلاق'),
          ),
        ],
      ),
    );
  }
}
