import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/utils/formatters.dart';
import '../providers/installments_provider.dart';
import '../../../shared/widgets/customer_avatar.dart';

class InstallmentDetailScreen extends ConsumerWidget {
  final InstallmentData installment;

  const InstallmentDetailScreen({super.key, required this.installment});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final debt = installment.debt;
    final installments = ref.watch(installmentsProvider);
    final debtInstallments =
        installments.where((i) => i.debt.id == debt.id).toList();
    final paidCount = debtInstallments.where((i) => i.isPaid).length;
    final totalCount = debtInstallments.length;
    final progress = totalCount > 0 ? paidCount / totalCount : 0.0;

    return Scaffold(
      appBar: AppBar(
        title: Text('تفاصيل القسط ${installment.index + 1}'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppDimensions.spacingMd),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCustomerCard(context),
            const SizedBox(height: AppDimensions.spacingMd),
            _buildProgressCard(context, progress, paidCount, totalCount),
            const SizedBox(height: AppDimensions.spacingMd),
            _buildInstallmentCard(context),
            const SizedBox(height: AppDimensions.spacingMd),
            _buildAllInstallments(context, ref, debtInstallments),
            const SizedBox(height: AppDimensions.spacingMd),
            _buildShareButton(context, debtInstallments),
          ],
        ),
      ),
    );
  }

  Widget _buildShareButton(
      BuildContext context, List<InstallmentData> instList) {
    final phone = installment.customerPhone;
    final customerName = installment.customerName ?? 'الزبون';
    final total = Formatters.formatCurrency(installment.debt.amount);
    final paid = instList.where((i) => i.isPaid).length;
    final totalCount = instList.length;

    final productName = installment.debt.productName;
    final buffer = StringBuffer();
    buffer.writeln('جدول أقساط $customerName');
    if (productName != null) buffer.writeln('السلعة: $productName');
    buffer.writeln('إجمالي العقد: $total');
    buffer.writeln('($paid أقساط مدفوعة من $totalCount)');
    buffer.writeln('---');
    for (int i = 0; i < instList.length; i++) {
      final inst = instList[i];
      final amt = Formatters.formatCurrency(inst.amount);
      final due = Formatters.formatDate(inst.dueDate);
      final status = inst.isPaid
          ? 'مدفوع ✓'
          : inst.isOverdue
              ? 'متأخر ⏰'
              : 'معلق ○';
      buffer.writeln('${i + 1}. $amt - $due - $status');
    }

    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: () async {
          if (phone == null || phone.trim().isEmpty) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('لا يوجد رقم هاتف لهذا الزبون')),
            );
            return;
          }
          final formatted = Formatters.formatPhoneForWhatsApp(phone);
          if (formatted.isEmpty) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('رقم الهاتف غير صالح')),
            );
            return;
          }
          final msg = Uri.encodeComponent(buffer.toString());
          final uri = Uri.parse('https://wa.me/$formatted?text=$msg');
          try {
            if (await canLaunchUrl(uri)) {
              await launchUrl(uri, mode: LaunchMode.externalApplication);
            } else {
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('تعذر فتح واتساب، تأكد من تثبيت التطبيق'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            }
          } catch (e) {
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('خطأ: $e'), backgroundColor: Colors.red),
              );
            }
          }
        },
        icon: const Icon(Icons.chat, size: 18),
        label: const Text('مشاركة عبر واتساب'),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF25D366),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14),
        ),
      ),
    );
  }

  Widget _buildCustomerCard(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.spacingMd),
        child: Row(
          children: [
            CustomerAvatar(
              name: installment.customerName ?? '?',
              radius: 24,
            ),
            const SizedBox(width: AppDimensions.spacingMd),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    installment.customerName ?? 'غير معروف',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  if (installment.customerPhone != null)
                    Text(
                      installment.customerPhone!,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: AppColors.textSecondaryLight,
                          ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressCard(
      BuildContext context, double progress, int paidCount, int totalCount) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.spacingMd),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'تقدم السداد',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: AppDimensions.spacingSm),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: progress,
                backgroundColor: AppColors.dividerLight,
                valueColor: AlwaysStoppedAnimation<Color>(
                  progress >= 1.0 ? AppColors.success : AppColors.primary,
                ),
                minHeight: 8,
              ),
            ),
            const SizedBox(height: AppDimensions.spacingSm),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '$paidCount أقساط مدفوعة من $totalCount',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                Text(
                  '${(progress * 100).toStringAsFixed(0)}%',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: progress >= 1.0
                            ? AppColors.success
                            : AppColors.primary,
                      ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInstallmentCard(BuildContext context) {
    final isPaid = installment.isPaid;
    final isOverdue = installment.isOverdue;

    Color statusColor = isPaid
        ? AppColors.success
        : isOverdue
            ? AppColors.error
            : AppColors.warning;

    String statusLabel = isPaid
        ? 'مدفوع'
        : isOverdue
            ? 'متأخر'
            : 'معلق';

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.spacingMd),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  isPaid
                      ? Icons.check_circle
                      : isOverdue
                          ? Icons.circle
                          : Icons.pending,
                  color: statusColor,
                  size: 24,
                ),
                const SizedBox(width: AppDimensions.spacingSm),
                Text(
                  'القسط ${installment.index + 1}',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: AppDimensions.spacingSm, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.15),
                    borderRadius:
                        BorderRadius.circular(AppDimensions.radiusSm),
                  ),
                  child: Text(
                    statusLabel,
                    style: TextStyle(
                      color: statusColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const Divider(height: AppDimensions.spacingMd * 2),
            _detailRow('المبلغ', Formatters.formatCurrency(installment.amount)),
            _detailRow('تاريخ الاستحقاق', Formatters.formatDate(installment.dueDate)),
            if (isPaid && installment.paidAt != null)
              _detailRow('تاريخ الدفع', Formatters.formatDate(installment.paidAt!)),
            _detailRow('المنتج', installment.debt.productName ?? 'غير محدد'),
            _detailRow('الكمية', '${installment.debt.productQuantity}'),
          ],
        ),
      ),
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textSecondaryLight,
              fontSize: 13,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAllInstallments(
      BuildContext context, WidgetRef ref, List<InstallmentData> allInstallments) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.spacingMd),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'جميع الأقساط',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: AppDimensions.spacingSm),
            ...allInstallments.map((inst) {
              final isPaid = inst.isPaid;
              final isOverdue = inst.isOverdue;
              final isCurrent = inst.index == installment.index;

              Color rowColor = Colors.transparent;
              if (isCurrent) {
                rowColor = AppColors.primary.withValues(alpha: 0.08);
              } else if (isPaid) {
                rowColor = AppColors.success.withValues(alpha: 0.08);
              } else if (isOverdue) {
                rowColor = AppColors.error.withValues(alpha: 0.08);
              }

              Color statusColor = isPaid
                  ? AppColors.success
                  : isOverdue
                      ? AppColors.error
                      : AppColors.warning;

              return Container(
                margin: const EdgeInsets.only(bottom: 4),
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: rowColor,
                  borderRadius:
                      BorderRadius.circular(AppDimensions.radiusSm),
                  border: isCurrent
                      ? Border.all(
                          color: AppColors.primary.withValues(alpha: 0.3),
                          width: 1.5,
                        )
                      : null,
                ),
                child: Row(
                  children: [
                    Icon(
                      isPaid
                          ? Icons.check_circle
                          : isOverdue
                              ? Icons.circle
                              : Icons.circle_outlined,
                      color: statusColor,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'قسط ${inst.index + 1}',
                      style: TextStyle(
                        fontWeight:
                            isCurrent ? FontWeight.bold : FontWeight.w500,
                        color: isCurrent ? AppColors.primary : null,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      Formatters.formatCurrency(inst.amount),
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: isPaid ? AppColors.success : null,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      Formatters.formatDate(inst.dueDate),
                      style: const TextStyle(
                        fontSize: 11,
                        color: AppColors.textSecondaryLight,
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
