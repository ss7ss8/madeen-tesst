import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/constants/strings.dart';
import '../../../core/services/sync_service.dart';
import '../../../data/models/product.dart';
import '../providers/inventory_provider.dart';
import '../widgets/product_card.dart';
import '../widgets/add_product_sheet.dart';
import '../../../shared/widgets/loading_indicator.dart';
import '../../../shared/widgets/glass_sheet.dart';

class InventoryScreen extends ConsumerStatefulWidget {
  const InventoryScreen({super.key});

  @override
  ConsumerState<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends ConsumerState<InventoryScreen> {
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      setState(() {});
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final products = ref.watch(productsProvider);
    final notifier = ref.read(productsProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.inventory)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(AppDimensions.paddingScreen),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: '${AppStrings.search} المنتجات...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          notifier.setSearchQuery('');
                        },
                      )
                    : null,
              ),
              onChanged: (value) => notifier.setSearchQuery(value),
            ),
          ),
          Expanded(
            child: products.isEmpty
                ? _searchController.text.isNotEmpty
                      ? EmptyState(
                          icon: Icons.search_off,
                          title: 'لا توجد نتائج',
                          subtitle: 'لم يتم العثور على منتجات تطابق البحث',
                        )
                      : const EmptyState(
                          icon: Icons.inventory_2_outlined,
                          title: AppStrings.noProducts,
                          subtitle: 'اضغط على + لإضافة منتج جديد',
                        )
                : RefreshIndicator(
                    onRefresh: () async {
                      // Pull-to-refresh now triggers a real Supabase sync
                      // (push pending local changes + pull remote updates,
                      // including freshly uploaded product image URLs)
                      // instead of just re-reading the local Hive cache.
                      await SyncService.syncAll().catchError((_) {});
                      ref.invalidate(productsProvider);
                    },
                    child: GridView.builder(
                      padding: const EdgeInsets.all(
                        AppDimensions.paddingScreen,
                      ),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: AppDimensions.gridSpacing,
                            mainAxisSpacing: AppDimensions.gridSpacing,
                            childAspectRatio: 0.70,
                          ),
                      itemCount: products.length,
                      itemBuilder: (context, index) {
                        final product = products[index];
                        return ProductCard(
                          product: product,
                          onTap: () => _showEditProductSheet(context, product),
                          onDelete: () => _confirmDelete(context, ref, product),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  void _showEditProductSheet(BuildContext context, Product product) {
    GlassSheet.show(context, (context) => AddProductSheet(product: product));
  }

  void _confirmDelete(BuildContext context, WidgetRef ref, product) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text(AppStrings.deleteProduct),
        content: Text('هل أنت متأكد من حذف ${product.name}؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(AppStrings.cancel),
          ),
          ElevatedButton(
            onPressed: () {
              ref.read(productsProvider.notifier).deleteProduct(product.id);
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
            ),
            child: const Text(AppStrings.delete),
          ),
        ],
      ),
    );
  }
}
