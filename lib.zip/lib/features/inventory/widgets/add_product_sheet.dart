import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import '../../../core/constants/dimensions.dart';
import '../../../core/constants/strings.dart';
import '../../../data/models/product.dart';
import '../providers/inventory_provider.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_network_image.dart';
import '../../../shared/widgets/barcode_scanner_sheet.dart';

class AddProductSheet extends ConsumerStatefulWidget {
  final Product? product;

  const AddProductSheet({super.key, this.product});

  @override
  ConsumerState<AddProductSheet> createState() => _AddProductSheetState();
}

class _AddProductSheetState extends ConsumerState<AddProductSheet> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _purchasePriceController = TextEditingController();
  final _salePriceController = TextEditingController();
  final _quantityController = TextEditingController();
  final _barcodeController = TextEditingController();
  String? _imagePath;
  bool _isLoading = false;
  final _picker = ImagePicker();

  bool get isEditing => widget.product != null;

  @override
  void initState() {
    super.initState();
    if (widget.product != null) {
      final p = widget.product!;
      _nameController.text = p.name;
      _purchasePriceController.text = p.purchasePrice.toStringAsFixed(0);
      _salePriceController.text = p.salePrice.toStringAsFixed(0);
      _quantityController.text = p.quantity.toString();
      _barcodeController.text = p.barcode ?? '';
      _imagePath = p.imageUrl;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _purchasePriceController.dispose();
    _salePriceController.dispose();
    _quantityController.dispose();
    _barcodeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(AppDimensions.paddingScreen),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    isEditing ? AppStrings.editProduct : AppStrings.addProduct,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                    tooltip: 'إغلاق',
                  ),
                ],
              ),
              const SizedBox(height: AppDimensions.spacingLg),

              // Image Picker
              Center(
                child: GestureDetector(
                  onTap: _pickImage,
                  child: Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      color: Theme.of(
                        context,
                      ).colorScheme.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(
                        AppDimensions.radiusLg,
                      ),
                      border: Border.all(
                        color: Theme.of(
                          context,
                        ).colorScheme.primary.withValues(alpha: 0.3),
                        width: 2,
                      ),
                    ),
                    child: _imagePath != null
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(
                              AppDimensions.radiusLg,
                            ),
                            child: _buildPreviewImage(),
                          )
                        : Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.add_a_photo,
                                size: 32,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'إضافة صورة',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                            ],
                          ),
                  ),
                ),
              ),
              const SizedBox(height: AppDimensions.spacingLg),

              AppTextField(
                controller: _nameController,
                label: AppStrings.productName,
                hint: 'أدخل اسم المنتج',
                prefixIcon: Icons.inventory_2,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppStrings.required;
                  }
                  return null;
                },
              ),
              const SizedBox(height: AppDimensions.spacingMd),

              Row(
                children: [
                  Expanded(
                    child: AppTextField(
                      controller: _purchasePriceController,
                      label: AppStrings.purchasePrice,
                      hint: '0',
                      prefixIcon: Icons.shopping_cart,
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(r'\d')),
                      ],
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return AppStrings.required;
                        }
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(width: AppDimensions.spacingMd),
                  Expanded(
                    child: AppTextField(
                      controller: _salePriceController,
                      label: AppStrings.salePrice,
                      hint: '0',
                      prefixIcon: Icons.sell,
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(r'\d')),
                      ],
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return AppStrings.required;
                        }
                        return null;
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppDimensions.spacingMd),

              AppTextField(
                controller: _quantityController,
                label: AppStrings.quantity,
                hint: '0',
                prefixIcon: Icons.numbers,
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppStrings.required;
                  }
                  return null;
                },
              ),
              const SizedBox(height: AppDimensions.spacingMd),

              AppTextField(
                controller: _barcodeController,
                label: 'الباركود',
                hint: 'امسح أو أدخل الباركود',
                prefixIcon: Icons.qr_code,
                keyboardType: TextInputType.text,
                suffix: IconButton(
                  icon: const Icon(Icons.qr_code_scanner),
                  tooltip: 'مسح الباركود',
                  onPressed: _scanBarcode,
                ),
              ),
              const SizedBox(height: AppDimensions.spacingXl),

              AppButton(
                text: AppStrings.save,
                isLoading: _isLoading,
                onPressed: _saveProduct,
              ),
              const SizedBox(height: AppDimensions.spacingMd),
            ],
          ),
        ),
      ),
    );
  }

  /// Renders the image preview from a network URL (when editing a product
  /// whose image was already uploaded to Supabase Storage) or from a local
  /// file path (for newly picked images that have not yet been uploaded).
  Widget _buildPreviewImage() {
    final path = _imagePath;
    if (path == null || path.isEmpty) {
      return const SizedBox.shrink();
    }

    return AppNetworkImage(
      imageUrl: path,
      fit: BoxFit.cover,
      width: 120,
      height: 120,
    );
  }

  Future<void> _pickImage() async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (context) => SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt),
                title: const Text(AppStrings.takePhoto),
                onTap: () => Navigator.pop(context, ImageSource.camera),
              ),
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text(AppStrings.chooseFromGallery),
                onTap: () => Navigator.pop(context, ImageSource.gallery),
              ),
            ],
          ),
        ),
      ),
    );

    if (source == null) return;

    final image = await _picker.pickImage(
      source: source,
      imageQuality: 65,
      maxWidth: 1000,
      maxHeight: 1000,
    );
    if (image != null) {
      // انسخ الصورة إلى مجلد دائم بدلاً من cache
      final appDir = await getApplicationDocumentsDirectory();
      final imagesDir = Directory(p.join(appDir.path, 'product_images'));
      // تأكد من وجود المجلد أولاً
      await imagesDir.create(recursive: true);
      final fileName =
          'product_${DateTime.now().millisecondsSinceEpoch}${p.extension(image.path)}';
      final savedImage = await File(
        image.path,
      ).copy(p.join(imagesDir.path, fileName));
      setState(() => _imagePath = savedImage.path);
    }
  }

  Future<void> _scanBarcode() async {
    final scanned = await showBarcodeScannerSheet(context);
    if (scanned == null || !mounted) return;

    if (isEditing &&
        (widget.product!.barcode == null ||
            widget.product!.barcode!.isEmpty)) {
      final updated = widget.product!.copyWith(
        barcode: scanned,
        updatedAt: DateTime.now(),
      );
      await ref.read(productsProvider.notifier).updateProduct(updated);
      if (mounted) {
        setState(() => _barcodeController.text = scanned);
        _fetchProductInfo(scanned);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم تسجيل الباركود على المنتج')),
        );
      }
      return;
    }

    if (mounted) {
      setState(() => _barcodeController.text = scanned);
      _fetchProductInfo(scanned);
    }
  }

  Future<void> _fetchProductInfo(String barcode) async {
    try {
      final uri = Uri.https(
        'world.openfoodfacts.org',
        'api/v0/product/$barcode.json',
      );
      final response = await http.get(
        uri,
        headers: {'User-Agent': 'DebtTracker/1.0'},
      );
      if (response.statusCode != 200) return;

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      if (data['status'] != 1) return;

      final product = data['product'] as Map<String, dynamic>?;
      if (product == null) return;

      if (!mounted) return;

      setState(() {
        if (_nameController.text.isEmpty) {
          final name = product['product_name'] as String?;
          if (name != null && name.isNotEmpty) {
            _nameController.text = name;
          }
        }
        if (_imagePath == null || _imagePath!.isEmpty) {
          final imageUrl =
              product['image_url'] as String? ??
              product['image_front_url'] as String?;
          if (imageUrl != null && imageUrl.isNotEmpty) {
            _imagePath = imageUrl;
          }
        }
      });
    } catch (e) {
      // تجاهل بصمت
    }
  }

  Future<void> _saveProduct() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final purchasePrice = double.parse(
        _purchasePriceController.text.replaceAll(RegExp(r'[^\d.]'), ''),
      );
      final salePrice = double.parse(
        _salePriceController.text.replaceAll(RegExp(r'[^\d.]'), ''),
      );
      final quantity = int.parse(
        _quantityController.text.replaceAll(RegExp(r'[^\d]'), ''),
      );

      if (isEditing) {
        final updated = widget.product!.copyWith(
          name: _nameController.text,
          purchasePrice: purchasePrice,
          salePrice: salePrice,
          quantity: quantity,
          imageUrl: _imagePath,
          barcode: _barcodeController.text.trim().isEmpty
              ? null
              : _barcodeController.text.trim(),
        );
        await ref.read(productsProvider.notifier).updateProduct(updated);
      } else {
        await ref
            .read(productsProvider.notifier)
            .addProduct(
              name: _nameController.text,
              purchasePrice: purchasePrice,
              salePrice: salePrice,
              quantity: quantity,
              imageUrl: _imagePath,
              barcode: _barcodeController.text.trim().isEmpty
                  ? null
                  : _barcodeController.text.trim(),
            );
      }

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text(AppStrings.successSaved)));
      }
    } catch (e) {
      // Show the error to the user (e.g. "User not logged in" thrown by
      // addProduct/updateProduct) instead of letting it fail silently.
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${AppStrings.errorOccurred}: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }
}
