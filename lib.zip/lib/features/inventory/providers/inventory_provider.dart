import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/utils/logger.dart';
import 'package:uuid/uuid.dart';
import '../../../data/local/hive_service.dart';
import '../../../data/models/product.dart';
import '../../../core/services/supabase_service.dart';
import '../../../core/services/sync_service.dart';


const _uuid = Uuid();

final productsProvider = StateNotifierProvider<ProductsNotifier, List<Product>>(
  (ref) {
    return ProductsNotifier(ref);
  },
);

class ProductsNotifier extends StateNotifier<List<Product>> {
  String _searchQuery = '';

  /// Listener for product image upload notifications from [SyncService].
  /// When a product image is uploaded to Supabase Storage, the sync
  /// service bumps [productImageSyncedVersion] so we reload products
  /// here — the UI then picks up the remote URL instead of the stale
  /// local file path.
  late final VoidCallback _imageSyncListener;
  late final VoidCallback _syncListener;

  ProductsNotifier(Ref _) : super([]) {
    loadProducts();
    _imageSyncListener = loadProducts;
    productImageSyncedVersion.addListener(_imageSyncListener);
    
    _syncListener = () {
      final currentCount = HiveService.getAllProducts().length;
      if (currentCount != state.length) {
        loadProducts();
      }
    };
    syncCompletedVersion.addListener(_syncListener);
  }

  @override
  void dispose() {
    productImageSyncedVersion.removeListener(_imageSyncListener);
    syncCompletedVersion.removeListener(_syncListener);
    super.dispose();
  }

  String get searchQuery => _searchQuery;

  void loadProducts() {
    var products = HiveService.getAllProducts();

    if (_searchQuery.isNotEmpty) {
      products = products
          .where(
            (p) => p.name.toLowerCase().contains(_searchQuery.toLowerCase()),
          )
          .toList();
    }

    products.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    state = products;
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    loadProducts();
  }

  Future<void> addProduct({
    required String name,
    required double purchasePrice,
    required double salePrice,
    required int quantity,
    String? imageUrl,
    String? category,
    String? barcode,
  }) async {
    // Guard: refuse to create a product when the user is not logged in.
    // Previously this fell back to 'local', which Supabase RLS rejects and
    // leaves the product stuck in the sync queue forever.
    final userId = SupabaseService.currentUser?.id;
    if (userId == null) {
      throw Exception('User not logged in');
    }
    final now = DateTime.now();
    final productId = _uuid.v4();

    final product = Product(
      id: productId,
      name: name,
      purchasePrice: purchasePrice,
      salePrice: salePrice,
      quantity: quantity,
      userId: userId,
      createdAt: now,
      updatedAt: now,
      imageUrl: imageUrl,
      category: category,
      barcode: barcode,
    );

    await HiveService.saveProduct(product);
    loadProducts();
    // تزامن مؤجل حتى لا ينتظر المستخدم ضغط/رفع صورة المنتج أثناء الحفظ.
    SyncService.syncAllDebounced();
  }

  Future<void> updateProduct(Product product) async {
    // Guard: refuse to update a product when the user is not logged in,
    // otherwise Supabase RLS rejects the row and it stays stuck in the
    // sync queue forever.
    final userId = SupabaseService.currentUser?.id;
    if (userId == null) {
      throw Exception('User not logged in');
    }

    final updated = product.copyWith(
      // Ensure the owning user is the current (logged-in) user so any stale
      // 'local' userId on legacy rows is corrected and RLS accepts the row.
      userId: userId,
      updatedAt: DateTime.now(),
      imageUrl: product.imageUrl,
    );
    await HiveService.saveProduct(updated);
    loadProducts();
    // تزامن مؤجل حتى لا ينتظر المستخدم ضغط/رفع صورة المنتج أثناء الحفظ.
    SyncService.syncAllDebounced();
  }

  Future<void> deleteProduct(String id) async {
    await HiveService.deleteProduct(id);
    loadProducts();
    // تزامن تلقائي بعد حذف المنتج
    SyncService.syncAll().catchError((e) {
      appLogger.warning('Auto-sync after deleteProduct failed: $e');
    });
  }

  Future<void> restoreProduct(String id) async {
    await HiveService.restoreProduct(id);
    loadProducts();
    // تزامن تلقائي بعد استعادة المنتج
    SyncService.syncAll().catchError((e) {
      appLogger.warning('Auto-sync after restoreProduct failed: $e');
    });
  }

  Future<void> permanentDeleteProduct(String id) async {
    await HiveService.permanentDeleteProduct(id);
    loadProducts();
    // تزامن تلقائي بعد الحذف النهائي للمنتج
    SyncService.syncAll().catchError((e) {
      appLogger.warning('Auto-sync after permanentDeleteProduct failed: $e');
    });
  }

  Future<void> updateQuantity(String id, int quantity) async {
    final product = HiveService.getProduct(id);
    if (product != null) {
      await HiveService.updateProductQuantity(id, quantity);
      loadProducts();
    }
  }

  Product? getProduct(String id) => HiveService.getProduct(id);
}
