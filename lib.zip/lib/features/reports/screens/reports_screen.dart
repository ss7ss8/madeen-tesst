import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:flutter/services.dart' show rootBundle;
import 'dart:io';
import 'package:excel/excel.dart' hide Border;
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/constants/strings.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/local/hive_service.dart';
import '../providers/reports_provider.dart';
import '../../../shared/widgets/loading_indicator.dart';
import '../../../shared/providers/pdf_service.dart';

class ReportsScreen extends ConsumerStatefulWidget {
  const ReportsScreen({super.key});

  @override
  ConsumerState<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends ConsumerState<ReportsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  ReportPeriod _period = ReportPeriod.monthly;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) {
        setState(() {
          switch (_tabController.index) {
            case 0:
              _period = ReportPeriod.daily;
              break;
            case 1:
              _period = ReportPeriod.weekly;
              break;
            case 2:
              _period = ReportPeriod.monthly;
              break;
          }
        });
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reportData = ref.watch(reportDataProvider(_period));

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.reports),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.ios_share),
            onSelected: (value) async {
              if (value == 'pdf') {
                _exportPdf();
              } else if (value == 'excel') {
                _exportExcel();
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'pdf',
                child: Row(
                  children: [
                    Icon(Icons.picture_as_pdf),
                    SizedBox(width: 8),
                    Text(AppStrings.exportPdf),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'excel',
                child: Row(
                  children: [
                    Icon(Icons.table_chart),
                    SizedBox(width: 8),
                    Text(AppStrings.exportExcel),
                  ],
                ),
              ),
            ],
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: AppStrings.daily),
            Tab(text: AppStrings.weekly),
            Tab(text: AppStrings.monthly),
          ],
        ),
      ),
      body: reportData.when(
        skipLoadingOnReload: true,
        data: (data) => RefreshIndicator(
          onRefresh: () async {
            ref.invalidate(reportDataProvider(_period));
            // Small delay to let the provider settle
            await Future.delayed(const Duration(milliseconds: 50));
          },
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(AppDimensions.paddingScreen),
            child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Summary Cards
              Row(
                children: [
                  Expanded(
                    child: _buildSummaryCard(
                      context,
                      AppStrings.totalDebts,
                      Formatters.formatCurrency(data.totalDebts),
                      Icons.account_balance_wallet,
                      AppColors.error,
                    ),
                  ),
                  const SizedBox(width: AppDimensions.spacingMd),
                  Expanded(
                    child: _buildSummaryCard(
                      context,
                      AppStrings.totalPaid,
                      Formatters.formatCurrency(data.totalPaid),
                      Icons.check_circle,
                      AppColors.success,
                    ),
                  ),
                  const SizedBox(width: AppDimensions.spacingMd),
                  Expanded(
                    child: _buildSummaryCard(
                      context,
                      'صافي الربح',
                      Formatters.formatCurrency(data.netProfit),
                      Icons.trending_up,
                      data.netProfit >= 0
                          ? AppColors.success
                          : AppColors.error,
                    ),
                  ),
                ],
              ),
              if (data.excludedCount > 0) ...[
                const SizedBox(height: AppDimensions.spacingSm),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppDimensions.spacingSm,
                    vertical: AppDimensions.spacingXs,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.orange.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(
                      AppDimensions.radiusSm,
                    ),
                    border: Border.all(
                      color: Colors.orange.withValues(alpha: 0.4),
                    ),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.warning_amber,
                        color: Colors.orange,
                        size: 14,
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'لم تُحتسب أرباح ${data.excludedCount} عملية مرتبطة بمنتج بسبب نقص بيانات الأسعار',
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(color: Colors.orange[800]),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: AppDimensions.spacingLg),

              // Bar chart for weekly period
              if (_period == ReportPeriod.weekly &&
                  data.weeklyBars.isNotEmpty) ...[
                Text(
                  'الديون اليومية هذا الأسبوع',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: AppDimensions.spacingMd),
                SizedBox(
                  height: AppDimensions.chartHeightMd,
                  child: BarChart(
                    BarChartData(
                      alignment: BarChartAlignment.spaceAround,
                      maxY: data.weeklyBars.isEmpty
                          ? 1
                          : data.weeklyBars
                                    .map((b) => b.value)
                                    .reduce((a, b) => a > b ? a : b) *
                                1.3,
                      barGroups: data.weeklyBars.asMap().entries.map((e) {
                        return BarChartGroupData(
                          x: e.key,
                          barRods: [
                            BarChartRodData(
                              toY: e.value.value,
                              color: AppColors.primary,
                              width: 16,
                              borderRadius: const BorderRadius.vertical(
                                top: Radius.circular(4),
                              ),
                            ),
                          ],
                        );
                      }).toList(),
                      titlesData: FlTitlesData(
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            getTitlesWidget: (value, meta) => Text(
                              data.weeklyBars[value.toInt()].label,
                              style: const TextStyle(fontSize: 10),
                            ),
                          ),
                        ),
                        leftTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false),
                        ),
                        topTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false),
                        ),
                        rightTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false),
                        ),
                      ),
                      gridData: const FlGridData(show: false),
                      borderData: FlBorderData(show: false),
                    ),
                  ),
                ),
                const SizedBox(height: AppDimensions.spacingXl),
              ],

              // Debt Distribution Chart
              if (data.debtDistribution.isNotEmpty) ...[
                Text(
                  'توزيع الديون',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: AppDimensions.spacingMd),
                SizedBox(
                  height: 200,
                  child: PieChart(
                    PieChartData(
                      sections: data.debtDistribution.entries.map((entry) {
                        final index = data.debtDistribution.keys
                            .toList()
                            .indexOf(entry.key);
                        return PieChartSectionData(
                          value: entry.value,
                          title: entry.key,
                          color: _getChartColor(index),
                          radius: 80,
                          titleStyle: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        );
                      }).toList(),
                      sectionsSpace: 2,
                      centerSpaceRadius: 40,
                    ),
                  ),
                ),
                const SizedBox(height: AppDimensions.spacingXl),
              ],

              // Top Indebted Customers
              if (data.topCustomers.isNotEmpty) ...[
                Text(
                  AppStrings.topCustomers,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: AppDimensions.spacingMd),
                ...data.topCustomers.map(
                  (item) => _buildTopItem(
                    context,
                    item['name']!,
                    Formatters.formatCurrency(item['amount']!),
                    Icons.person,
                  ),
                ),
                const SizedBox(height: AppDimensions.spacingXl),
              ],

              // Top Selling Products
              if (data.topProducts.isNotEmpty) ...[
                Text(
                  AppStrings.topProducts,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: AppDimensions.spacingMd),
                ...data.topProducts.asMap().entries.map(
                  (entry) => _buildTopItem(
                    context,
                    entry.value['name']!,
                    '${entry.value['quantity']} وحدة',
                    Icons.inventory_2,
                  ),
                ),
              ],
              ],
            ),
          ),
        ),
        loading: () => const LoadingIndicator(message: AppStrings.loading),
        error: (e, _) => ErrorState(
          message: e.toString(),
          onRetry: () => ref.invalidate(reportDataProvider(_period)),
        ),
      ),
    );
  }

  Widget _buildSummaryCard(
    BuildContext context,
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(AppDimensions.paddingCard),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withValues(alpha: 0.1), color.withValues(alpha: 0.05)],
        ),
        borderRadius: BorderRadius.circular(AppDimensions.radiusLg),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color),
          const SizedBox(height: AppDimensions.spacingSm),
          Text(
            value,
            style: Theme.of(
              context,
            ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
          ),
          Text(title, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }

  Widget _buildTopItem(
    BuildContext context,
    String title,
    String value,
    IconData icon,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: AppDimensions.spacingSm),
      child: Material(
        type: MaterialType.transparency,
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: AppColors.primary.withValues(alpha: 0.1),
            child: Icon(icon, color: AppColors.primary, size: 20),
          ),
          title: Text(title),
          trailing: Text(
            value,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: AppColors.error,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Color _getChartColor(int index) {
    final colors = [
      AppColors.primary,
      AppColors.secondary,
      AppColors.accent,
      AppColors.error,
      Colors.purple,
      Colors.teal,
    ];
    return colors[index % colors.length];
  }

  Future<void> _exportPdf() async {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('جاري إنشاء التقرير...')));

    try {
      final debts = HiveService.getAllDebts();
      final customers = HiveService.getAllCustomers();
      final payments = HiveService.getAllPayments();
      final settings = HiveService.getAppSettings();
      final printerType = settings.printerType;
      final s = PdfService.fontScaleFor(printerType);
      final thermal = PdfService.isThermal(printerType);

      final pdf = pw.Document();
      final regularData = await rootBundle.load(
        'assets/fonts/Amiri-Regular.ttf',
      );
      final arabicFont = pw.Font.ttf(regularData);
      final boldData = await rootBundle.load('assets/fonts/Amiri-Bold.ttf');
      final arabicFontBold = pw.Font.ttf(boldData);

      // Build period-filtered data
      final now = DateTime.now();
      final DateTime startDate;
      final String periodLabel;
      switch (_period) {
        case ReportPeriod.daily:
          startDate = DateTime(now.year, now.month, now.day);
          periodLabel = 'يومي';
          break;
        case ReportPeriod.weekly:
          startDate = now.subtract(Duration(days: now.weekday - 1));
          periodLabel = 'أسبوعي';
          break;
        case ReportPeriod.monthly:
          startDate = DateTime(now.year, now.month, 1);
          periodLabel = 'شهري';
      }

      final filteredDebts = debts
          .where((d) => d.createdAt.isAfter(startDate))
          .toList();
      final totalDebts = filteredDebts.fold<double>(0, (s, d) => s + d.amount);
      final totalPaid = payments
          .where((p) => p.createdAt.isAfter(startDate))
          .fold<double>(0, (s, p) => s + p.amount);

      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfService.pageFormatFor(printerType),
          theme: pw.ThemeData.withFont(base: arabicFont, bold: arabicFontBold),
          header: (pw.Context ctx) => pw.Directionality(
            textDirection: pw.TextDirection.rtl,
            child: pw.Container(
              padding: pw.EdgeInsets.all(thermal ? 8 : 16),
              decoration: const pw.BoxDecoration(color: PdfColors.blue100),
              child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text(
                        settings.storeName,
                        style: pw.TextStyle(
                          fontSize: 22 * s,
                          fontWeight: pw.FontWeight.bold,
                        ),
                      ),
                      pw.Text(
                        'تقرير $periodLabel',
                        style: pw.TextStyle(
                          fontSize: 14 * s,
                          color: PdfColors.grey700,
                        ),
                      ),
                      pw.Text(
                        'التاريخ: ${Formatters.formatDate(now)}',
                        style: pw.TextStyle(fontSize: 12 * s),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          build: (pw.Context ctx) {
            return [
              pw.Directionality(
                textDirection: pw.TextDirection.rtl,
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.stretch,
                  children: [
                    pw.SizedBox(height: 16),

                    // Summary
                    pw.Row(
                      children: [
                        pw.Expanded(
                          child: pw.Container(
                            padding: pw.EdgeInsets.all(thermal ? 8 : 12),
                            decoration: pw.BoxDecoration(
                              color: PdfColors.red50,
                              borderRadius: pw.BorderRadius.circular(8),
                            ),
                            child: pw.Column(
                              children: [
                                pw.Text(
                                  'إجمالي الديون',
                                  style: pw.TextStyle(
                                    fontSize: 12 * s,
                                    color: PdfColors.grey600,
                                  ),
                                ),
                                pw.Text(
                                  Formatters.formatCurrency(totalDebts),
                                  style: pw.TextStyle(
                                    fontSize: 16 * s,
                                    fontWeight: pw.FontWeight.bold,
                                    color: PdfColors.red,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        pw.SizedBox(width: 12),
                        pw.Expanded(
                          child: pw.Container(
                            padding: pw.EdgeInsets.all(thermal ? 8 : 12),
                            decoration: pw.BoxDecoration(
                              color: PdfColors.green50,
                              borderRadius: pw.BorderRadius.circular(8),
                            ),
                            child: pw.Column(
                              children: [
                                pw.Text(
                                  'إجمالي المسدد',
                                  style: pw.TextStyle(
                                    fontSize: 12 * s,
                                    color: PdfColors.grey600,
                                  ),
                                ),
                                pw.Text(
                                  Formatters.formatCurrency(totalPaid),
                                  style: pw.TextStyle(
                                    fontSize: 16 * s,
                                    fontWeight: pw.FontWeight.bold,
                                    color: PdfColors.green,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    pw.SizedBox(height: 16),

                    // Debts Table
                    if (filteredDebts.isNotEmpty) ...[
                      pw.Text(
                        'تفاصيل الديون',
                        style: pw.TextStyle(
                          fontSize: 14 * s,
                          fontWeight: pw.FontWeight.bold,
                        ),
                      ),
                      pw.SizedBox(height: 8),
                      pw.Table(
                        border: pw.TableBorder.all(color: PdfColors.grey300),
                        children: [
                          pw.TableRow(
                            decoration: const pw.BoxDecoration(
                              color: PdfColors.grey200,
                            ),
                            children: [
                              _pdfCell('الزبون', isHeader: true, scale: s),
                              _pdfCell('المنتج', isHeader: true, scale: s),
                              _pdfCell('المبلغ', isHeader: true, scale: s),
                              _pdfCell('المسدد', isHeader: true, scale: s),
                              _pdfCell('الحالة', isHeader: true, scale: s),
                            ],
                          ),
                          ...filteredDebts.map((debt) {
                            final cust = customers
                                .where((c) => c.id == debt.customerId)
                                .firstOrNull;
                            return pw.TableRow(
                              children: [
                                _pdfCell(cust?.name ?? '-', scale: s),
                                _pdfCell(debt.productName ?? '-', scale: s),
                                _pdfCell(
                                  Formatters.formatAmount(debt.amount),
                                  scale: s,
                                ),
                                _pdfCell(
                                  Formatters.formatAmount(debt.paidAmount),
                                  scale: s,
                                ),
                                _pdfCell(
                                  debt.isPaid ? 'مسدد' : 'مستحق',
                                  scale: s,
                                ),
                              ],
                            );
                          }),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ];
          },
        ),
      );

      final directory = await getApplicationDocumentsDirectory();
      final file = File(
        '${directory.path}/report_${_period.name}_${now.millisecondsSinceEpoch}.pdf',
      );
      await file.writeAsBytes(await pdf.save());

      await Share.shareXFiles([
        XFile(file.path),
      ], text: 'تقرير الديون - $periodLabel');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('خطأ: $e')));
      }
    }
  }

  pw.Widget _pdfCell(String text, {bool isHeader = false, double scale = 1.0}) {
    return pw.Container(
      padding: pw.EdgeInsets.all(scale < 1 ? 4 : 6),
      child: pw.Text(
        text,
        textAlign: pw.TextAlign.center,
        style: pw.TextStyle(
          fontSize: (isHeader ? 11 : 9) * scale,
          fontWeight: isHeader ? pw.FontWeight.bold : null,
        ),
      ),
    );
  }

  Future<void> _exportExcel() async {
    final debts = HiveService.getAllDebts();
    final customers = HiveService.getAllCustomers();

    final now = DateTime.now();
    final DateTime startDate;
    switch (_period) {
      case ReportPeriod.daily:
        startDate = DateTime(now.year, now.month, now.day);
        break;
      case ReportPeriod.weekly:
        final monday = now.subtract(Duration(days: now.weekday - 1));
        startDate = DateTime(monday.year, monday.month, monday.day);
        break;
      case ReportPeriod.monthly:
        startDate = DateTime(now.year, now.month, 1);
        break;
    }

    final filteredDebts = debts
        .where((d) => d.createdAt.isAfter(startDate))
        .toList();

    final excel = Excel.createExcel();
    final sheetName = 'التقرير';
    final sheet = excel[sheetName];
    try {
      excel.delete('Sheet1');
    } catch (_) {}

    // Headers
    final headers = [
      'الزبون',
      'المنتج',
      'الكمية',
      'المبلغ',
      'المسدد',
      'المتبقي',
      'التاريخ',
      'الحالة',
    ];
    for (int col = 0; col < headers.length; col++) {
      sheet
          .cell(CellIndex.indexByColumnRow(columnIndex: col, rowIndex: 0))
          .value = TextCellValue(
        headers[col],
      );
    }

    for (int i = 0; i < filteredDebts.length; i++) {
      final debt = filteredDebts[i];
      final customer = customers
          .where((c) => c.id == debt.customerId)
          .firstOrNull;
      final row = i + 1;
      final values = [
        customer?.name ?? '-',
        debt.productName ?? '-',
        debt.productQuantity.toString(),
        debt.amount.toStringAsFixed(0),
        debt.paidAmount.toStringAsFixed(0),
        debt.remainingAmount.toStringAsFixed(0),
        Formatters.formatDate(debt.createdAt),
        debt.isPaid ? 'تم التسديد' : 'مستحق',
      ];
      for (int col = 0; col < values.length; col++) {
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: col, rowIndex: row))
            .value = TextCellValue(
          values[col],
        );
      }
    }

    final directory = await getApplicationDocumentsDirectory();
    final file = File(
      '${directory.path}/report_${_period.name}_${DateTime.now().millisecondsSinceEpoch}.xlsx',
    );
    final bytes = excel.encode();
    if (bytes == null) return;
    await file.writeAsBytes(bytes);

    await Share.shareXFiles([XFile(file.path)], text: 'تقرير الديون');
  }
}
