import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../data/local/hive_service.dart';
import './reports_provider.dart';

/// Data model for profit report
class ProfitReportData {
  /// Total revenue from sales (sum of all debt amounts)
  final double totalRevenue;

  /// Total cost (sum of cost prices × quantities)
  final double totalCost;

  /// Net profit (revenue - cost)
  final double netProfit;

  /// Overall profit margin (netProfit / totalCost), 0.0 to 1.0+
  final double profitMargin;

  /// Number of sales with valid price data
  final int salesWithPriceData;

  /// Total number of sales in period
  final int totalSales;

  /// Percentage of sales with valid price data
  final double priceDataCoverage;

  /// Top profitable products (sorted by total profit descending)
  final List<Map<String, dynamic>> topProfitableProducts;

  /// Profit trend data for chart (date -> profit)
  final List<ProfitTrendItem> profitTrend;

  const ProfitReportData({
    required this.totalRevenue,
    required this.totalCost,
    required this.netProfit,
    required this.profitMargin,
    required this.salesWithPriceData,
    required this.totalSales,
    required this.priceDataCoverage,
    required this.topProfitableProducts,
    required this.profitTrend,
  });
}

/// Item for profit trend chart
class ProfitTrendItem {
  final DateTime date;
  final double profit;
  final double revenue;
  final double cost;

  const ProfitTrendItem({
    required this.date,
    required this.profit,
    required this.revenue,
    required this.cost,
  });
}

/// Provider for profit report data filtered by period
final profitReportProvider = FutureProvider.family<ProfitReportData, ReportPeriod>((
  ref,
  period,
) async {
  // Watch debts provider to auto-refresh when debts change
  ref.watch(reportDataProvider(period));

  final debts = HiveService.getAllDebts();

  // ── Period filter ──────────────────────────────────────────────────────────
  final now = DateTime.now();
  final DateTime startDate;
  final DateTime endDate = now;

  switch (period) {
    case ReportPeriod.daily:
      startDate = DateTime(now.year, now.month, now.day);
      break;
    case ReportPeriod.weekly:
      final monday = now.subtract(Duration(days: now.weekday - 1));
      startDate = DateTime(monday.year, monday.month, monday.day);
      break;
    case ReportPeriod.monthly:
      startDate = DateTime(now.year, now.month, 1);
      break;
  }

  final filteredDebts = debts
      .where(
        (d) => d.createdAt.isAfter(startDate) && d.createdAt.isBefore(endDate),
      )
      .toList();

  // ── Calculate totals ───────────────────────────────────────────────────────
  double totalRevenue = 0;
  double totalCost = 0;
  int salesWithPriceData = 0;

  for (final debt in filteredDebts) {
    totalRevenue += debt.amount;

    if (debt.hasPriceData) {
      totalCost += (debt.unitCostPrice! * debt.productQuantity);
      salesWithPriceData++;
    }
  }

  final netProfit = totalRevenue - totalCost;
  final profitMargin = totalCost > 0 ? netProfit / totalCost : 0.0;
  final priceDataCoverage = filteredDebts.isNotEmpty
      ? salesWithPriceData / filteredDebts.length
      : 0.0;

  // ── Top profitable products ────────────────────────────────────────────────
  final productProfits = <String, Map<String, dynamic>>{};

  for (final debt in filteredDebts.where((d) => d.hasPriceData)) {
    final productName = debt.productName ?? 'غير محدد';
    final profit = debt.totalProfit;
    final quantity = debt.productQuantity;

    if (productProfits.containsKey(productName)) {
      productProfits[productName]!['profit'] += profit;
      productProfits[productName]!['quantity'] += quantity;
      productProfits[productName]!['sales_count'] += 1;
    } else {
      productProfits[productName] = {
        'name': productName,
        'profit': profit,
        'quantity': quantity,
        'sales_count': 1,
      };
    }
  }

  final topProfitableProducts = productProfits.values.toList()
    ..sort((a, b) => (b['profit'] as double).compareTo(a['profit'] as double));

  // ── Profit trend (daily breakdown) ─────────────────────────────────────────
  final profitTrend = <ProfitTrendItem>[];

  if (period == ReportPeriod.monthly) {
    // Group by day of month
    final daysInMonth = DateTime(now.year, now.month + 1, 0).day;
    for (int day = 1; day <= daysInMonth; day++) {
      final dayDate = DateTime(now.year, now.month, day);
      final dayDebts = filteredDebts.where(
        (d) =>
            d.createdAt.year == dayDate.year &&
            d.createdAt.month == dayDate.month &&
            d.createdAt.day == dayDate.day,
      );

      double dayRevenue = 0;
      double dayCost = 0;

      for (final debt in dayDebts) {
        dayRevenue += debt.amount;
        if (debt.hasPriceData) {
          dayCost += (debt.unitCostPrice! * debt.productQuantity);
        }
      }

      if (dayRevenue > 0 || dayCost > 0) {
        profitTrend.add(
          ProfitTrendItem(
            date: dayDate,
            profit: dayRevenue - dayCost,
            revenue: dayRevenue,
            cost: dayCost,
          ),
        );
      }
    }
  } else if (period == ReportPeriod.weekly) {
    // Group by day of week
    final monday = now.subtract(Duration(days: now.weekday - 1));
    for (int i = 0; i < 7; i++) {
      final dayDate = DateTime(monday.year, monday.month, monday.day + i);
      final dayDebts = filteredDebts.where(
        (d) =>
            d.createdAt.year == dayDate.year &&
            d.createdAt.month == dayDate.month &&
            d.createdAt.day == dayDate.day,
      );

      double dayRevenue = 0;
      double dayCost = 0;

      for (final debt in dayDebts) {
        dayRevenue += debt.amount;
        if (debt.hasPriceData) {
          dayCost += (debt.unitCostPrice! * debt.productQuantity);
        }
      }

      profitTrend.add(
        ProfitTrendItem(
          date: dayDate,
          profit: dayRevenue - dayCost,
          revenue: dayRevenue,
          cost: dayCost,
        ),
      );
    }
  } else {
    // Daily: hourly breakdown
    for (int hour = 0; hour < 24; hour++) {
      final hourStart = DateTime(now.year, now.month, now.day, hour);
      final hourEnd = hourStart.add(const Duration(hours: 1));

      final hourDebts = filteredDebts.where(
        (d) => d.createdAt.isAfter(hourStart) && d.createdAt.isBefore(hourEnd),
      );

      double hourRevenue = 0;
      double hourCost = 0;

      for (final debt in hourDebts) {
        hourRevenue += debt.amount;
        if (debt.hasPriceData) {
          hourCost += (debt.unitCostPrice! * debt.productQuantity);
        }
      }

      if (hourRevenue > 0 || hourCost > 0) {
        profitTrend.add(
          ProfitTrendItem(
            date: hourStart,
            profit: hourRevenue - hourCost,
            revenue: hourRevenue,
            cost: hourCost,
          ),
        );
      }
    }
  }

  return ProfitReportData(
    totalRevenue: totalRevenue,
    totalCost: totalCost,
    netProfit: netProfit,
    profitMargin: profitMargin,
    salesWithPriceData: salesWithPriceData,
    totalSales: filteredDebts.length,
    priceDataCoverage: priceDataCoverage,
    topProfitableProducts: topProfitableProducts.take(10).toList(),
    profitTrend: profitTrend,
  );
});
