import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../data/local/hive_service.dart';
import '../../customers/providers/customers_provider.dart';
import '../../customers/providers/debts_provider.dart';

enum ReportPeriod { daily, weekly, monthly }

class BarItem {
  final String label;
  final double value;
  BarItem(this.label, this.value);
}

class ReportData {
  final double totalDebts;
  final double totalPaid;
  final double netProfit;
  final int excludedCount;
  final Map<String, double> debtDistribution;
  final List<Map<String, dynamic>> topCustomers;
  final List<Map<String, dynamic>> topProducts;
  final List<BarItem> weeklyBars;

  ReportData({
    required this.totalDebts,
    required this.totalPaid,
    this.netProfit = 0,
    this.excludedCount = 0,
    required this.debtDistribution,
    required this.topCustomers,
    required this.topProducts,
    this.weeklyBars = const [],
  });
}

final reportDataProvider = FutureProvider.family<ReportData, ReportPeriod>((
  ref,
  period,
) async {
  ref.watch(debtsProvider);
  ref.watch(customersProvider);

  final debts = HiveService.getAllDebts();
  final customers = HiveService.getAllCustomers();
  final payments = HiveService.getAllPayments();

  // ── Period filter ──────────────────────────────────────────────────────────
  final now = DateTime.now();
  final DateTime startDate;
  switch (period) {
    case ReportPeriod.daily:
      startDate = DateTime(now.year, now.month, now.day);
      break;
    case ReportPeriod.weekly:
      final monday = now.subtract(Duration(days: now.weekday - 1));
      startDate = DateTime(monday.year, monday.month, monday.day);
      break;
    case ReportPeriod.monthly:
      startDate = DateTime(now.year, now.month, 1);
      break;
  }

  final filteredDebts = debts
      .where((d) => d.createdAt.isAfter(startDate))
      .toList();
  final filteredPayments = payments
      .where((p) => p.createdAt.isAfter(startDate))
      .toList();

  final totalDebts = filteredDebts.fold<double>(0, (sum, d) => sum + d.amount);
  final totalPaid = filteredPayments.fold<double>(
    0,
    (sum, p) => sum + p.amount,
  );

  // ── Net profit (period-filtered, product-linked debts with full price data) ─
  double netProfit = 0;
  int excludedCount = 0;
  for (final debt in filteredDebts) {
    if (debt.productId == null) continue;
    if (debt.unitSalePrice != null && debt.unitCostPrice != null) {
      netProfit +=
          (debt.unitSalePrice! - debt.unitCostPrice!) * debt.productQuantity;
    } else {
      excludedCount++;
    }
  }

  // ── Debt distribution by product (period-filtered) ────────────────────────
  final debtDistribution = <String, double>{};
  for (final debt in filteredDebts) {
    final name = debt.productName ?? 'أخرى';
    debtDistribution[name] = (debtDistribution[name] ?? 0) + debt.amount;
  }

  // ── Top customers by unpaid debt (period-filtered) ────────────────────────
  final customerDebts = <String, double>{};
  for (final debt in filteredDebts.where((d) => !d.isPaid)) {
    customerDebts[debt.customerId] =
        (customerDebts[debt.customerId] ?? 0) + debt.remainingAmount;
  }

  final topCustomers =
      customerDebts.entries
          .map((e) {
            try {
              final c = customers.firstWhere((c) => c.id == e.key);
              return {'name': c.name, 'amount': e.value};
            } catch (_) {
              return null;
            }
          })
          .whereType<Map<String, dynamic>>()
          .toList()
        ..sort(
          (a, b) => (b['amount'] as double).compareTo(a['amount'] as double),
        );

  // ── Top products by quantity sold (period-filtered) ───────────────────────
  final productSales = <String, int>{};
  for (final debt in filteredDebts) {
    if (debt.productName != null) {
      productSales[debt.productName!] =
          (productSales[debt.productName!] ?? 0) + debt.productQuantity;
    }
  }
  final topProducts =
      productSales.entries
          .map((e) => {'name': e.key, 'quantity': e.value})
          .toList()
        ..sort(
          (a, b) => (b['quantity'] as int).compareTo(a['quantity'] as int),
        );

  // ── Weekly bar data (debt per day this week) ──────────────────────────────
  final List<BarItem> weeklyBars = [];
  if (period == ReportPeriod.weekly) {
    const dayNames = ['إث', 'ثل', 'أر', 'خم', 'جم', 'سب', 'أح'];
    final monday = now.subtract(Duration(days: now.weekday - 1));

    for (int i = 0; i < 7; i++) {
      final day = DateTime(monday.year, monday.month, monday.day + i);
      final amount = filteredDebts
          .where(
            (d) =>
                d.createdAt.year == day.year &&
                d.createdAt.month == day.month &&
                d.createdAt.day == day.day,
          )
          .fold<double>(0, (s, d) => s + d.amount);
      weeklyBars.add(BarItem(dayNames[i], amount));
    }
  }

  return ReportData(
    totalDebts: totalDebts,
    totalPaid: totalPaid,
    netProfit: netProfit,
    excludedCount: excludedCount,
    debtDistribution: debtDistribution,
    topCustomers: topCustomers.take(5).toList(),
    topProducts: topProducts.take(5).toList(),
    weeklyBars: weeklyBars,
  );
});
