import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/utils/formatters.dart';
import '../providers/dashboard_provider.dart';

class MonthlyComparisonCard extends ConsumerWidget {
  const MonthlyComparisonCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stats = ref.watch(dashboardStatsProvider);
    return stats.when(
      data: (data) => _buildCard(context, data.comparison),
      loading: () => const SizedBox.shrink(),
      error: (_, __) => const SizedBox.shrink(),
    );
  }

  Widget _buildCard(BuildContext context, MonthlyComparison cmp) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return ClipRRect(
      borderRadius: BorderRadius.circular(AppDimensions.radiusLg),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(AppDimensions.paddingCard),
          decoration: BoxDecoration(
            color: isDark
                ? const Color(0xFF1F2937).withValues(alpha: 0.85)
                : Colors.white.withValues(alpha: 0.85),
            borderRadius: BorderRadius.circular(AppDimensions.radiusLg),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'مقارنة الأداء',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: AppDimensions.spacingMd),
              cmp.allZero
                  ? _buildRow(
                      context,
                      icon: Icons.remove_circle_outline,
                      iconColor: AppColors.textSecondaryLight,
                      label: 'لا تغيير',
                      value: '',
                    )
                  : !cmp.hasPreviousData
                      ? _buildRow(
                          context,
                          icon: Icons.info_outline,
                          iconColor: AppColors.accent,
                          label: 'لا توجد بيانات كافية للمقارنة بعد',
                          value: '',
                        )
                      : Column(
                          children: [
                            _buildIndicator(
                              context,
                              label: 'الديون الجديدة',
                              current: cmp.thisMonthNewDebts,
                              percent: cmp.newDebtsPercent,
                              useValueColors: false,
                            ),
                            const SizedBox(height: AppDimensions.spacingMd),
                            _buildIndicator(
                              context,
                              label: 'المتحصل',
                              current: cmp.thisMonthCollections,
                              percent: cmp.collectionsPercent,
                              useValueColors: true,
                            ),
                          ],
                        ),
              const SizedBox(height: AppDimensions.spacingSm),
              Text(
                'مقارنة بنفس الفترة الشهر الماضي',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColors.textSecondaryLight,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIndicator(
    BuildContext context, {
    required String label,
    required double current,
    required double percent,
    required bool useValueColors,
  }) {
    final isPositive = percent >= 0;
    final arrow = isPositive ? '↑' : '↓';
    final color = useValueColors
        ? (isPositive ? AppColors.success : AppColors.error)
        : AppColors.accent;
    final sign = isPositive ? '+' : '';

    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColors.textSecondaryLight,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                Formatters.formatCurrency(current),
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        if (percent != 0 || current != 0)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              '$arrow $sign${percent.toStringAsFixed(1)}%',
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildRow(
    BuildContext context, {
    required IconData icon,
    required Color iconColor,
    required String label,
    required String value,
  }) {
    return Row(
      children: [
        Icon(icon, color: iconColor, size: 20),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            label,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ),
        if (value.isNotEmpty)
          Text(
            value,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
      ],
    );
  }
}
