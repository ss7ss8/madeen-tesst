import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';

class PaidVsOwingDonut extends StatelessWidget {
  final int paidCount;
  final int owingCount;

  const PaidVsOwingDonut({
    super.key,
    required this.paidCount,
    required this.owingCount,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final total = paidCount + owingCount;

    if (total == 0) {
      return Container(
        height: AppDimensions.chartHeightMd,
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF1F2937) : Colors.white,
          borderRadius: BorderRadius.circular(AppDimensions.radiusLg),
        ),
        child: Center(
          child: Text(
            'لا توجد بيانات',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ),
      );
    }

    final paidPct = paidCount / total;
    final owingPct = owingCount / total;

    return Container(
      height: AppDimensions.chartHeightMd,
      padding: const EdgeInsets.all(AppDimensions.paddingCard),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1F2937) : Colors.white,
        borderRadius: BorderRadius.circular(AppDimensions.radiusLg),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: PieChart(
              PieChartData(
                sectionsSpace: 2,
                centerSpaceRadius: 35,
                sections: [
                  PieChartSectionData(
                    value: paidPct,
                    color: AppColors.success,
                    title: '${(paidPct * 100).toStringAsFixed(0)}%',
                    radius: 55,
                    titleStyle: TextStyle(
                      color: isDark ? Colors.white : Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                  PieChartSectionData(
                    value: owingPct,
                    color: AppColors.error,
                    title: '${(owingPct * 100).toStringAsFixed(0)}%',
                    radius: 55,
                    titleStyle: TextStyle(
                      color: isDark ? Colors.white : Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: AppDimensions.spacingMd),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _LegendRow(
                color: AppColors.success,
                title: 'مسدد',
                value: paidCount,
              ),
              const SizedBox(height: AppDimensions.spacingXs),
              _LegendRow(
                color: AppColors.error,
                title: 'مدين',
                value: owingCount,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _LegendRow extends StatelessWidget {
  final Color color;
  final String title;
  final int value;

  const _LegendRow({
    required this.color,
    required this.title,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 8),
        Text('$title: $value', style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }
}
