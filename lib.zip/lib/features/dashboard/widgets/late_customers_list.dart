import 'package:flutter/material.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../providers/dashboard_provider.dart';

class LateCustomersList extends StatelessWidget {
  final List<LateCustomer> lateCustomers;

  const LateCustomersList({super.key, required this.lateCustomers});

  @override
  Widget build(BuildContext context) {
    if (lateCustomers.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(AppDimensions.paddingCard),
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF1F2937)
              : Colors.white,
          borderRadius: BorderRadius.circular(AppDimensions.radiusLg),
        ),
        child: Text(
          'لا يوجد زبائن متأخرون أكثر من 30 يوم',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(AppDimensions.paddingCard),
      decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark
            ? const Color(0xFF1F2937)
            : Colors.white,
        borderRadius: BorderRadius.circular(AppDimensions.radiusLg),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'يحتاج انتباهك',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: AppColors.error,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: AppDimensions.spacingSm),
          ...lateCustomers.take(10).map((c) {
            return Padding(
              padding: const EdgeInsets.only(bottom: AppDimensions.spacingXs),
              child: ListTile(
                contentPadding: EdgeInsets.zero,
                leading: CircleAvatar(
                  backgroundColor: AppColors.error.withValues(alpha: 0.15),
                  child: const Icon(
                    Icons.warning_amber_rounded,
                    color: AppColors.error,
                  ),
                ),
                title: Text(c.customerName),
                subtitle: Text(
                  'متأخر ${c.overdueDays} يوم • مستحق: ${c.remainingAmount.toStringAsFixed(2)} د.ع',
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
