import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../data/local/hive_service.dart';
import '../../../data/models/customer.dart';
import '../../../data/models/debt.dart';
import '../../../data/models/payment.dart';
import '../../../data/models/product.dart';
import '../../customers/providers/customers_provider.dart';
import '../../customers/providers/debts_provider.dart';
import '../../inventory/providers/inventory_provider.dart';

// Dashboard Stats
class DashboardStats {
  final double totalDebts;
  final int totalCustomers;
  final int totalProducts;
  final DateTime? lastOperation;
  final List<MonthlyDebt> monthlyDebts;
  final List<MonthlyDebt> monthlyCollections;
  final double monthlyCollectionRatePercent;
  final int paidCustomersCount;
  final int owingCustomersCount;
  final List<LateCustomer> lateCustomers;
  final MonthlyComparison comparison;
  final double totalCashSales;
  final double totalDebtSales;

  DashboardStats({
    required this.totalDebts,
    required this.totalCustomers,
    required this.totalProducts,
    this.lastOperation,
    required this.monthlyDebts,
    required this.monthlyCollections,
    required this.monthlyCollectionRatePercent,
    required this.paidCustomersCount,
    required this.owingCustomersCount,
    required this.lateCustomers,
    required this.comparison,
    required this.totalCashSales,
    required this.totalDebtSales,
  });
}

class MonthlyComparison {
  final double thisMonthNewDebts;
  final double lastMonthNewDebts;
  final double newDebtsPercent;
  final double thisMonthCollections;
  final double lastMonthCollections;
  final double collectionsPercent;
  final bool hasPreviousData;
  final bool allZero;

  MonthlyComparison({
    required this.thisMonthNewDebts,
    required this.lastMonthNewDebts,
    required this.newDebtsPercent,
    required this.thisMonthCollections,
    required this.lastMonthCollections,
    required this.collectionsPercent,
    required this.hasPreviousData,
    required this.allZero,
  });

  static MonthlyComparison compute(
    List<Debt> allDebts,
    List<Payment> payments,
  ) {
    final now = DateTime.now();
    final dayOfMonth = now.day;

    final thisMonthStart = DateTime(now.year, now.month, 1);

    final prevMonth = DateTime(now.year, now.month - 1, 1);
    final prevMonthStart = DateTime(prevMonth.year, prevMonth.month, 1);
    final prevMonthEnd = DateTime(
      prevMonth.year,
      prevMonth.month,
      dayOfMonth,
      23,
      59,
      59,
    );

    double thisMonthNewDebts = 0;
    double lastMonthNewDebts = 0;
    double thisMonthCollections = 0;
    double lastMonthCollections = 0;

    for (final debt in allDebts) {
      final created = debt.createdAt;
      if (!created.isBefore(thisMonthStart) && !created.isAfter(now)) {
        thisMonthNewDebts += debt.amount;
      } else if (!created.isBefore(prevMonthStart) &&
          !created.isAfter(prevMonthEnd)) {
        lastMonthNewDebts += debt.amount;
      }
    }

    for (final payment in payments) {
      final created = payment.createdAt;
      if (!created.isBefore(thisMonthStart) && !created.isAfter(now)) {
        thisMonthCollections += payment.amount;
      } else if (!created.isBefore(prevMonthStart) &&
          !created.isAfter(prevMonthEnd)) {
        lastMonthCollections += payment.amount;
      }
    }

    final hasPreviousData = lastMonthNewDebts > 0 || lastMonthCollections > 0;
    final allZero =
        thisMonthNewDebts == 0 &&
        lastMonthNewDebts == 0 &&
        thisMonthCollections == 0 &&
        lastMonthCollections == 0;

    double calcPercent(double current, double previous) {
      if (previous == 0) return current > 0 ? 100 : 0;
      return ((current - previous) / previous) * 100;
    }

    return MonthlyComparison(
      thisMonthNewDebts: thisMonthNewDebts,
      lastMonthNewDebts: lastMonthNewDebts,
      newDebtsPercent: calcPercent(thisMonthNewDebts, lastMonthNewDebts),
      thisMonthCollections: thisMonthCollections,
      lastMonthCollections: lastMonthCollections,
      collectionsPercent: calcPercent(
        thisMonthCollections,
        lastMonthCollections,
      ),
      hasPreviousData: hasPreviousData,
      allZero: allZero,
    );
  }
}

class LateCustomer {
  final String customerId;
  final String customerName;
  final double remainingAmount;
  final int overdueDays;

  LateCustomer({
    required this.customerId,
    required this.customerName,
    required this.remainingAmount,
    required this.overdueDays,
  });
}

class MonthlyDebt {
  final String month;
  final double amount;

  MonthlyDebt(this.month, this.amount);
}

/// بيانات الـ input للحسابات — قابلة للإرسال لـ Isolate
class _DashboardInput {
  final List<Debt> allDebts;
  final List<Debt> unpaidDebts;
  final List<Customer> allCustomers;
  final List<Product> allProducts;
  final List<Payment> allPayments;
  final int lateThresholdDays;

  const _DashboardInput({
    required this.allDebts,
    required this.unpaidDebts,
    required this.allCustomers,
    required this.allProducts,
    required this.allPayments,
    required this.lateThresholdDays,
  });
}

/// دالة top-level تُنفَّذ في Isolate منفصل
DashboardStats _computeDashboardStats(_DashboardInput input) {
  final allDebts = input.allDebts;
  final unpaidDebts = input.unpaidDebts;
  final customers = input.allCustomers;
  final products = input.allProducts;
  final payments = input.allPayments;

  final totalDebts = unpaidDebts.fold<double>(
    0,
    (sum, d) => sum + d.remainingAmount,
  );

  final timestamps = <DateTime>[];

  if (allDebts.isNotEmpty) {
    timestamps.add(
      allDebts
          .reduce((a, b) => a.createdAt.isAfter(b.createdAt) ? a : b)
          .createdAt,
    );
  }
  if (payments.isNotEmpty) {
    timestamps.add(
      payments
          .reduce((a, b) => a.createdAt.isAfter(b.createdAt) ? a : b)
          .createdAt,
    );
  }
  if (customers.isNotEmpty) {
    timestamps.add(
      customers
          .reduce((a, b) => a.updatedAt.isAfter(b.updatedAt) ? a : b)
          .updatedAt,
    );
  }
  if (products.isNotEmpty) {
    timestamps.add(
      products
          .reduce((a, b) => a.updatedAt.isAfter(b.updatedAt) ? a : b)
          .updatedAt,
    );
  }

  final lastOperation = timestamps.isNotEmpty
      ? timestamps.reduce((a, b) => a.isAfter(b) ? a : b)
      : null;

  final now = DateTime.now();
  final monthlyDebts = <MonthlyDebt>[];
  final monthlyCollections = <MonthlyDebt>[];

  for (int i = 5; i >= 0; i--) {
    final month = DateTime(now.year, now.month - i, 1);
    final monthName = _getMonthName(month.month);

    final monthDebtAmount = unpaidDebts
        .where(
          (d) =>
              d.createdAt.year == month.year &&
              d.createdAt.month == month.month,
        )
        .fold<double>(0, (sum, d) => sum + d.amount);

    final monthCollectionAmount = payments
        .where(
          (p) =>
              p.createdAt.year == month.year &&
              p.createdAt.month == month.month,
        )
        .fold<double>(0, (sum, p) => sum + p.amount);

    monthlyDebts.add(MonthlyDebt(monthName, monthDebtAmount));
    monthlyCollections.add(MonthlyDebt(monthName, monthCollectionAmount));
  }

  final currentMonthDebt = monthlyDebts.isNotEmpty
      ? monthlyDebts.last.amount
      : 0;
  final currentMonthCollection = monthlyCollections.isNotEmpty
      ? monthlyCollections.last.amount
      : 0;

  final monthlyCollectionRatePercent = currentMonthDebt > 0
      ? (currentMonthCollection / currentMonthDebt) * 100.0
      : 0.0;

  int paidCustomersCount = 0;
  int owingCustomersCount = 0;

  for (final customer in customers) {
    final customerRemaining = unpaidDebts
        .where((d) => d.customerId == customer.id)
        .fold<double>(0, (sum, d) => sum + d.remainingAmount);

    if (customerRemaining > 0) {
      owingCustomersCount++;
    } else {
      paidCustomersCount++;
    }
  }

  final overdueThresholdDays = input.lateThresholdDays;
  final lateCustomers = <LateCustomer>[];

  for (final customer in customers) {
    final customerDebts = unpaidDebts
        .where((d) => d.customerId == customer.id)
        .toList();
    final remaining = customerDebts.fold<double>(
      0,
      (sum, d) => sum + d.remainingAmount,
    );

    if (customerDebts.isEmpty || remaining <= 0) continue;

    int maxOverdue = 0;
    for (final debt in customerDebts) {
      final due = debt.dueDate ?? debt.createdAt;
      final overdueDays = now.difference(due).inDays;
      if (overdueDays > maxOverdue) maxOverdue = overdueDays;
    }

    if (maxOverdue > overdueThresholdDays) {
      lateCustomers.add(
        LateCustomer(
          customerId: customer.id,
          customerName: customer.name,
          remainingAmount: remaining,
          overdueDays: maxOverdue,
        ),
      );
    }
  }

  lateCustomers.sort((a, b) => b.remainingAmount.compareTo(a.remainingAmount));

  final comparison = MonthlyComparison.compute(allDebts, payments);

  final totalCashSales = allDebts
      .where((d) => d.isCashSale)
      .fold<double>(0, (sum, d) => sum + d.amount);

  final totalDebtSales = allDebts
      .where((d) => !d.isCashSale)
      .fold<double>(0, (sum, d) => sum + d.amount);

  return DashboardStats(
    totalDebts: totalDebts,
    totalCustomers: customers.length,
    totalProducts: products.length,
    lastOperation: lastOperation,
    monthlyDebts: monthlyDebts,
    monthlyCollections: monthlyCollections,
    monthlyCollectionRatePercent: monthlyCollectionRatePercent,
    paidCustomersCount: paidCustomersCount,
    owingCustomersCount: owingCustomersCount,
    lateCustomers: lateCustomers,
    comparison: comparison,
    totalCashSales: totalCashSales,
    totalDebtSales: totalDebtSales,
  );
}

final dashboardStatsProvider = FutureProvider<DashboardStats>((ref) async {
  ref.watch(customersProvider);
  ref.watch(debtsProvider);
  ref.watch(productsProvider);

  // قراءة Hive على main thread (سريعة — فقط قراءة)
  final allDebts = HiveService.getAllDebts();
  final unpaidDebts = allDebts
      .where((d) => !d.isPaid && d.deletedAt == null)
      .toList();
  final allCustomers = HiveService.getAllCustomers();
  final allProducts = HiveService.getAllProducts();
  final allPayments = HiveService.getAllPayments();
  final settings = HiveService.getAppSettings();

  // أعطِ فرصة للـ UI يتنفس قبل الحسابات
  await Future.microtask(() {});

  // الحسابات مباشرة (بدون compute) — Hive objects لا تُرسل لـ Isolate
  return _computeDashboardStats(
    _DashboardInput(
      allDebts: allDebts,
      unpaidDebts: unpaidDebts,
      allCustomers: allCustomers,
      allProducts: allProducts,
      allPayments: allPayments,
      lateThresholdDays: settings.lateThresholdDays,
    ),
  );
});

String _getMonthName(int month) {
  const months = [
    'يناير',
    'فبراير',
    'مارس',
    'أبريل',
    'مايو',
    'يونيو',
    'يوليو',
    'أغسطس',
    'سبتمبر',
    'أكتوبر',
    'نوفمبر',
    'ديسمبر',
  ];
  return months[month - 1];
}
