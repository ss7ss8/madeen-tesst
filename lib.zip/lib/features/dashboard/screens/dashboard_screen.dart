import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/constants/strings.dart';
import '../../../core/utils/formatters.dart';
import '../providers/dashboard_provider.dart';
import '../widgets/summary_card.dart';
import '../widgets/debts_collections_chart.dart';
import '../widgets/paid_vs_owing_donut.dart';
import '../widgets/late_customers_list.dart';
import '../widgets/monthly_comparison_card.dart';


class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stats = ref.watch(dashboardStatsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.appName)),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(dashboardStatsProvider);
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(AppDimensions.paddingScreen),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Stats Grid
              stats.when(
                data: (data) => _buildStatsGrid(context, data),
                loading: () => _buildLoadingGrid(),
                error: (e, _) => Center(child: Text('خطأ: $e')),
              ),

              const SizedBox(height: AppDimensions.spacingXl),

              // Monthly comparison indicator
              const MonthlyComparisonCard(),

              const SizedBox(height: AppDimensions.spacingXl),

              // Donut + collection rate
              stats.when(
                data: (data) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: AppDimensions.spacingXl),
                    Text(
                      'نسبة المسددين مقابل المدينين',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: AppDimensions.spacingMd),
                    PaidVsOwingDonut(
                      paidCount: data.paidCustomersCount,
                      owingCount: data.owingCustomersCount,
                    ),
                    const SizedBox(height: AppDimensions.spacingXl),
                    Text(
                      'مؤشر معدل التحصيل الشهري',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: AppDimensions.spacingSm),
                    Text(
                      '${data.monthlyCollectionRatePercent.toStringAsFixed(0)}%',
                      style: Theme.of(context).textTheme.headlineSmall
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                loading: () => const SizedBox.shrink(),
                error: (e, _) => const SizedBox.shrink(),
              ),

              const SizedBox(height: AppDimensions.spacingXl),

              // Late customers
              stats.when(
                data: (data) =>
                    LateCustomersList(lateCustomers: data.lateCustomers),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => const SizedBox.shrink(),
              ),

              const SizedBox(height: AppDimensions.spacingXl),

              // Chart: debts vs collections (last 6 months)
              Text(
                AppStrings.monthlyDebts,
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: AppDimensions.spacingMd),
              stats.when(
                data: (data) => DebtsCollectionsChart(
                  debts: data.monthlyDebts
                      .map((e) => ChartPoint(e.month, e.amount))
                      .toList(),
                  collections: data.monthlyCollections
                      .map((e) => ChartPoint(e.month, e.amount))
                      .toList(),
                ),
                loading: () => const SizedBox(
                  height: AppDimensions.chartHeightMd,
                  child: Center(child: CircularProgressIndicator()),
                ),
                error: (e, _) => const SizedBox.shrink(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsGrid(BuildContext context, DashboardStats stats) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: AppDimensions.gridSpacing,
      mainAxisSpacing: AppDimensions.gridSpacing,
      childAspectRatio: 1.4,
      children: [
        SummaryCard(
          icon: Icons.monetization_on,
          iconColor: Colors.teal,
          title: 'المبيعات النقدية',
          value: Formatters.formatCurrency(stats.totalCashSales),
          gradient: LinearGradient(
            colors: [
              Colors.teal.withValues(alpha: 0.1),
              Colors.teal.withValues(alpha: 0.05),
            ],
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
        ),
        SummaryCard(
          icon: Icons.money_off_csred,
          iconColor: Colors.purple,
          title: 'المبيعات بالآجل',
          value: Formatters.formatCurrency(stats.totalDebtSales),
          gradient: LinearGradient(
            colors: [
              Colors.purple.withValues(alpha: 0.1),
              Colors.purple.withValues(alpha: 0.05),
            ],
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
        ),
        SummaryCard(
          icon: Icons.account_balance_wallet,
          iconColor: AppColors.error,
          title: AppStrings.totalDebts,
          value: Formatters.formatCurrency(stats.totalDebts),
          gradient: LinearGradient(
            colors: [
              AppColors.error.withValues(alpha: 0.1),
              AppColors.error.withValues(alpha: 0.05),
            ],
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
        ),
        SummaryCard(
          icon: Icons.people,
          iconColor: AppColors.primary,
          title: AppStrings.totalCustomers,
          value: stats.totalCustomers.toString(),
          gradient: LinearGradient(
            colors: [
              AppColors.primary.withValues(alpha: 0.1),
              AppColors.primary.withValues(alpha: 0.05),
            ],
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
        ),
        SummaryCard(
          icon: Icons.inventory_2,
          iconColor: AppColors.secondary,
          title: AppStrings.totalProducts,
          value: stats.totalProducts.toString(),
          gradient: LinearGradient(
            colors: [
              AppColors.secondary.withValues(alpha: 0.1),
              AppColors.secondary.withValues(alpha: 0.05),
            ],
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
        ),
        SummaryCard(
          icon: Icons.access_time,
          iconColor: AppColors.accent,
          title: AppStrings.lastOperation,
          value: stats.lastOperation != null
              ? Formatters.formatRelativeDate(stats.lastOperation!)
              : '-',
          gradient: LinearGradient(
            colors: [
              AppColors.accent.withValues(alpha: 0.1),
              AppColors.accent.withValues(alpha: 0.05),
            ],
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingGrid() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: AppDimensions.gridSpacing,
      mainAxisSpacing: AppDimensions.gridSpacing,
      childAspectRatio: 1.4,
      children: List.generate(
        4,
        (_) => Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(AppDimensions.radiusLg),
          ),
          child: const Center(child: CircularProgressIndicator(strokeWidth: 2)),
        ),
      ),
    );
  }

}
