import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../data/models/customer.dart';
import '../../../data/models/debt.dart';
import '../../../data/models/settings.dart';
import '../../../shared/providers/thermal_invoice_renderer.dart';
import '../../../shared/providers/thermal_printer_service.dart';
import '../../../shared/providers/theme_provider.dart';

/// Screen for discovering, pairing, and testing Bluetooth thermal printers.
///
/// Shows a list of bonded Bluetooth devices, allows connecting to one, saves
/// the selected printer's MAC + name to [AppSettings] for auto-reconnect, and
/// provides a test-print button that renders a sample invoice via
/// [ThermalInvoiceRenderer].
class ThermalPrinterPairingScreen extends ConsumerStatefulWidget {
  const ThermalPrinterPairingScreen({super.key});

  @override
  ConsumerState<ThermalPrinterPairingScreen> createState() =>
      _ThermalPrinterPairingScreenState();
}

class _ThermalPrinterPairingScreenState
    extends ConsumerState<ThermalPrinterPairingScreen> {
  List<ThermalPrinterDevice> _devices = [];
  bool _isScanning = false;
  bool _isTesting = false;
  String? _scanError;

  @override
  void initState() {
    super.initState();
    // Auto-scan on open
    WidgetsBinding.instance.addPostFrameCallback((_) => _scanDevices());
  }

  // ── Scan ────────────────────────────────────────────────────────────────

  Future<void> _scanDevices() async {
    setState(() {
      _isScanning = true;
      _scanError = null;
    });

    try {
      final notifier = ref.read(thermalPrinterProvider.notifier);
      final devices = await notifier.getPairedDevices();
      if (mounted) {
        setState(() {
          _devices = devices;
          _isScanning = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _scanError = e.toString().replaceFirst('Exception: ', '');
          _isScanning = false;
        });
      }
    }
  }

  // ── Connect ─────────────────────────────────────────────────────────────

  Future<void> _connectToDevice(ThermalPrinterDevice device) async {
    final notifier = ref.read(thermalPrinterProvider.notifier);
    final ok = await notifier.connect(device.mac, name: device.name);

    if (ok) {
      // Save to settings for auto-reconnect
      final settings = ref.read(settingsProvider);
      await ref
          .read(settingsProvider.notifier)
          .update(
            settings.copyWith(
              lastPrinterMac: device.mac,
              lastPrinterName: device.name,
            ),
          );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('تم الاتصال بـ ${device.name}'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } else {
      final state = ref.read(thermalPrinterProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(state.errorMessage ?? 'فشل الاتصال'),
            backgroundColor: AppColors.error,
          ),
        );
      }
    }
  }

  // ── Disconnect ──────────────────────────────────────────────────────────

  Future<void> _disconnect() async {
    await ref.read(thermalPrinterProvider.notifier).disconnect();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم قطع الاتصال'),
          backgroundColor: AppColors.secondary,
        ),
      );
    }
  }

  // ── Test Print ──────────────────────────────────────────────────────────

  Future<void> _testPrint() async {
    final settings = ref.read(settingsProvider);

    // Determine paper width from settings
    final paperWidth = settings.printerType == 'thermal_58mm'
        ? ThermalPaperWidth.mm58
        : ThermalPaperWidth.mm80;

    setState(() => _isTesting = true);

    try {
      // Build a sample debt + customer for the test invoice
      final sampleCustomer = Customer(
        id: 'test',
        name: 'زبون تجريبي',
        phone: '07700000000',
        userId: 'test',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      final sampleDebt = Debt(
        id: 'test',
        customerId: 'test',
        amount: 50000,
        paidAmount: 20000,
        userId: 'test',
        createdAt: DateTime.now(),
        productName: 'منتج تجريبي',
        productQuantity: 2,
        invoiceNumber: settings.lastInvoiceNumber,
        isInstallment: false,
        installmentCount: 1,
      );

      final bytes = await ThermalInvoiceRenderer.renderInvoice(
        debt: sampleDebt,
        customer: sampleCustomer,
        settings: settings,
        paperWidth: paperWidth,
      );

      final result = await ref
          .read(thermalPrinterProvider.notifier)
          .printBytes(bytes);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result.message),
            backgroundColor: result.success
                ? AppColors.success
                : AppColors.error,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('خطأ في الطباعة التجريبية: $e'),
            backgroundColor: AppColors.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isTesting = false);
    }
  }

  // ── Build ───────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final printerState = ref.watch(thermalPrinterProvider);
    final settings = ref.watch(settingsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('اقتران الطابعة الحرارية'),
        actions: [
          IconButton(
            onPressed: _isScanning ? null : _scanDevices,
            icon: const Icon(Icons.refresh),
            tooltip: 'إعادة البحث',
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppDimensions.paddingScreen),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Connection status card ──
              _buildStatusCard(context, printerState, settings),
              const SizedBox(height: AppDimensions.spacingLg),

              // ── Section header ──
              Text(
                'الطابعات المقترنة',
                style: Theme.of(
                  context,
                ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: AppDimensions.spacingSm),

              // ── Devices list ──
              Expanded(child: _buildDevicesList(context, printerState)),

              const SizedBox(height: AppDimensions.spacingMd),

              // ── Test print button ──
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: (printerState.isConnected && !_isTesting)
                      ? _testPrint
                      : null,
                  icon: _isTesting
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.print),
                  label: Text(_isTesting ? 'جاري الطباعة...' : 'طباعة تجريبية'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Status Card ─────────────────────────────────────────────────────────

  Widget _buildStatusCard(
    BuildContext context,
    ThermalPrinterState printerState,
    AppSettings settings,
  ) {
    final isConnected = printerState.isConnected;
    final statusText = switch (printerState.status) {
      ThermalConnectionStatus.connected => 'متصل',
      ThermalConnectionStatus.connecting => 'جاري الاتصال...',
      ThermalConnectionStatus.error => 'خطأ',
      ThermalConnectionStatus.disconnected => 'غير متصل',
    };
    final statusColor = switch (printerState.status) {
      ThermalConnectionStatus.connected => AppColors.success,
      ThermalConnectionStatus.connecting => AppColors.warning,
      ThermalConnectionStatus.error => AppColors.error,
      ThermalConnectionStatus.disconnected => AppColors.secondary,
    };

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.paddingCard),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                isConnected ? Icons.bluetooth_connected : Icons.bluetooth,
                color: statusColor,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    printerState.connectedDevice?.name ??
                        settings.lastPrinterName ??
                        'لا توجد طابعة',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    statusText,
                    style: TextStyle(color: statusColor, fontSize: 13),
                  ),
                ],
              ),
            ),
            if (isConnected)
              TextButton(onPressed: _disconnect, child: const Text('قطع')),
          ],
        ),
      ),
    );
  }

  // ── Devices List ────────────────────────────────────────────────────────

  Widget _buildDevicesList(
    BuildContext context,
    ThermalPrinterState printerState,
  ) {
    if (_isScanning) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('جاري البحث عن الطابعات...'),
          ],
        ),
      );
    }

    if (_scanError != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 48, color: AppColors.error),
            const SizedBox(height: 12),
            Text(
              _scanError!,
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.error),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _scanDevices,
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      );
    }

    if (_devices.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.bluetooth_disabled, size: 48, color: Colors.grey[400]),
            const SizedBox(height: 12),
            Text(
              'لم يتم العثور على طابعات مقترنة\nيرجى اقتران طابعة من إعدادات البلوتوث أولاً',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey[600]),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _scanDevices,
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة البحث'),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: _devices.length,
      itemBuilder: (context, index) {
        final device = _devices[index];
        final isCurrent =
            printerState.connectedDevice?.mac == device.mac &&
            printerState.isConnected;

        return Card(
          margin: const EdgeInsets.only(bottom: AppDimensions.spacingSm),
          child: Material(
            type: MaterialType.transparency,
            child: ListTile(
              leading: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: (isCurrent ? AppColors.success : AppColors.primary)
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  isCurrent ? Icons.check_circle : Icons.print,
                  color: isCurrent ? AppColors.success : AppColors.primary,
                ),
              ),
              title: Text(
                device.name,
                style: TextStyle(
                  fontWeight: isCurrent ? FontWeight.bold : FontWeight.normal,
                ),
              ),
              subtitle: Text(device.mac),
              trailing: isCurrent
                  ? const Text('متصل', style: TextStyle(color: AppColors.success))
                  : printerState.status == ThermalConnectionStatus.connecting
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.link),
              onTap: isCurrent ? null : () => _connectToDevice(device),
            ),
          ),
        );
      },
    );
  }
}
