import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/local/hive_service.dart';
import '../../../data/models/customer.dart';
import '../../../data/models/product.dart';
import '../../customers/providers/customers_provider.dart';
import '../../inventory/providers/inventory_provider.dart';

// ---------------------------------------------------------------------------
// Reactive providers for deleted items.  Watching customersProvider /
// productsProvider means these are re-evaluated every time a restore or
// permanent-delete mutates the underlying state, causing TrashScreen and its
// child tabs to rebuild automatically.
// ---------------------------------------------------------------------------
final _deletedCustomersProvider = Provider<List<Customer>>((ref) {
  ref.watch(customersProvider); // invalidated on every customer state change
  return HiveService.getDeletedCustomers();
});

final _deletedProductsProvider = Provider<List<Product>>((ref) {
  ref.watch(productsProvider); // invalidated on every product state change
  return HiveService.getDeletedProducts();
});

class TrashScreen extends ConsumerWidget {
  const TrashScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final deletedCustomers = ref.watch(_deletedCustomersProvider);
    final deletedProducts  = ref.watch(_deletedProductsProvider);
    final hasItems = deletedCustomers.isNotEmpty || deletedProducts.isNotEmpty;

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('سلة المحذوفات'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'الزبائن', icon: Icon(Icons.people_outline)),
              Tab(text: 'المنتجات', icon: Icon(Icons.inventory_2_outlined)),
            ],
          ),
        ),
        body: hasItems
            ? const TabBarView(
                children: [
                  _CustomersTab(),
                  _ProductsTab(),
                ],
              )
            : const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.delete_sweep_outlined, size: 64, color: Colors.grey),
                    SizedBox(height: 16),
                    Text('لا توجد عناصر محذوفة', style: TextStyle(color: Colors.grey, fontSize: 16)),
                  ],
                ),
              ),
      ),
    );
  }
}

class _CustomersTab extends ConsumerWidget {
  const _CustomersTab();

  void _confirmPermanentDelete(BuildContext context, WidgetRef ref, Customer customer) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف نهائي لا رجعة فيه'),
        content: Text(
          'سيتم حذف كل بيانات ${customer.name} وديونه ودفعاته نهائياً '
          'ولن تتمكن من استرجاعها أبداً.\n\n'
          'هل أنت متأكد؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              ref.read(customersProvider.notifier).permanentDeleteCustomer(customer.id);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('حذف نهائي'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final deletedCustomers = ref.watch(_deletedCustomersProvider);

    if (deletedCustomers.isEmpty) {
      return const Center(
        child: Text('لا توجد زبائن محذوفة', style: TextStyle(color: Colors.grey)),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(AppDimensions.paddingScreen),
      itemCount: deletedCustomers.length + 1,
      itemBuilder: (context, index) {
        if (index == 0) {
          return _buildCleanupButton(context, ref, deletedCustomers);
        }
        final customer = deletedCustomers[index - 1];
        return Card(
          margin: const EdgeInsets.only(bottom: AppDimensions.spacingSm),
          child: Material(
            type: MaterialType.transparency,
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.orange.withValues(alpha: 0.2),
                child: const Icon(Icons.person_off, color: Colors.orange),
              ),
              title: Text(customer.name),
              subtitle: Text(
                'حُذف: ${_formatDeleteTime(customer.deletedAt)}',
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.restore, color: Colors.green),
                    tooltip: 'استرجاع',
                    onPressed: () {
                      ref.read(customersProvider.notifier).restoreCustomer(customer.id);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('تم استرجاع ${customer.name}')),
                      );
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_forever, color: Colors.red),
                    tooltip: 'حذف نهائي',
                    onPressed: () => _confirmPermanentDelete(context, ref, customer),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildCleanupButton(BuildContext context, WidgetRef ref, List<Customer> deletedCustomers) {
    final now = DateTime.now();
    final oldItems = deletedCustomers.where((c) {
      if (c.deletedAt == null) return false;
      return now.difference(c.deletedAt!).inDays >= 90;
    }).toList();

    if (oldItems.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimensions.spacingMd),
      child: ElevatedButton.icon(
        icon: const Icon(Icons.auto_delete),
        label: const Text('حذف نهائي للعناصر الأقدم من 90 يوماً'),
        style: ElevatedButton.styleFrom(backgroundColor: Colors.red.shade100),
        onPressed: () {
          showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text('حذف نهائي للقديم'),
              content: Text('سيتم حذف ${oldItems.length} زبون/زبونة حُذفوا منذ أكثر من 90 يوماً. هذا الإجراء لا رجعة فيه.'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                    for (final c in oldItems) {
                      ref.read(customersProvider.notifier).permanentDeleteCustomer(c.id);
                    }
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('تم حذف العناصر القديمة نهائياً')),
                    );
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  child: const Text('حذف نهائي'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  String _formatDeleteTime(DateTime? deletedAt) {
    if (deletedAt == null) return '';
    return Formatters.formatRelativeDate(deletedAt);
  }
}

class _ProductsTab extends ConsumerWidget {
  const _ProductsTab();

  void _confirmPermanentDelete(BuildContext context, WidgetRef ref, Product product) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف نهائي لا رجعة فيه'),
        content: Text(
          'سيتم حذف ${product.name} نهائياً ولن تتمكن من استرجاعه أبداً.\n\n'
          'هل أنت متأكد؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              ref.read(productsProvider.notifier).permanentDeleteProduct(product.id);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('حذف نهائي'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final deletedProducts = ref.watch(_deletedProductsProvider);

    if (deletedProducts.isEmpty) {
      return const Center(
        child: Text('لا توجد منتجات محذوفة', style: TextStyle(color: Colors.grey)),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(AppDimensions.paddingScreen),
      itemCount: deletedProducts.length,
      itemBuilder: (context, index) {
        final product = deletedProducts[index];
        return Card(
          margin: const EdgeInsets.only(bottom: AppDimensions.spacingSm),
          child: Material(
            type: MaterialType.transparency,
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.orange.withValues(alpha: 0.2),
                child: Icon(Icons.inventory_2, color: Colors.orange),
              ),
              title: Text(product.name),
              subtitle: Text(
                'حُذف: ${_formatDeleteTime(product.deletedAt)}',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.restore, color: Colors.green),
                    tooltip: 'استرجاع',
                    onPressed: () {
                      ref.read(productsProvider.notifier).restoreProduct(product.id);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('تم استرجاع ${product.name}')),
                      );
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_forever, color: Colors.red),
                    tooltip: 'حذف نهائي',
                    onPressed: () => _confirmPermanentDelete(context, ref, product),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  String _formatDeleteTime(DateTime? deletedAt) {
    if (deletedAt == null) return '';
    return Formatters.formatRelativeDate(deletedAt);
  }
}
