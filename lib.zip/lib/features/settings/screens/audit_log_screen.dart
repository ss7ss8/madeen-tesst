import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/local/hive_service.dart';
import '../../../data/models/audit_log.dart';
import '../../customers/providers/customers_provider.dart';
import '../../customers/providers/debts_provider.dart';
import '../../dashboard/providers/dashboard_provider.dart';

class AuditLogScreen extends ConsumerStatefulWidget {
  const AuditLogScreen({super.key});

  @override
  ConsumerState<AuditLogScreen> createState() => _AuditLogScreenState();
}

class _AuditLogScreenState extends ConsumerState<AuditLogScreen> {
  List<AuditLog> _logs = [];

  @override
  void initState() {
    super.initState();
    _loadLogs();
  }

  void _loadLogs() {
    setState(() {
      _logs = HiveService.auditLogs.values.toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    });
  }

  @override
  Widget build(BuildContext context) {
    // Find the most recent undoable operation (add_debt or add_payment)
    AuditLog? undoTarget;
    for (final l in _logs) {
      if (l.actionType == 'add_debt' || l.actionType == 'add_payment') {
        undoTarget = l;
        break;
      }
    }
    final hasUndo = undoTarget != null && undoTarget.id.isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: const Text('سجل العمليات'),
        actions: [
          if (hasUndo)
            IconButton(
              icon: const Icon(Icons.undo),
              tooltip: 'تراجع عن آخر عملية',
              onPressed: () => _confirmUndo(context, undoTarget!),
            ),
          IconButton(
            icon: const Icon(Icons.delete_sweep_outlined),
            tooltip: 'مسح السجل',
            onPressed: () => _confirmClear(context),
          ),
        ],
      ),
      body: _logs.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.history,
                    size: 64,
                    color: AppColors.textSecondaryLight,
                  ),
                  SizedBox(height: AppDimensions.spacingMd),
                  Text('لا توجد عمليات مسجّلة'),
                ],
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(AppDimensions.paddingScreen),
              itemCount: _logs.length,
              separatorBuilder: (_, __) =>
                  const SizedBox(height: AppDimensions.spacingSm),
              itemBuilder: (context, index) {
                final log = _logs[index];
                final isUndoable =
                    index == 0 &&
                    (log.actionType == 'add_debt' ||
                        log.actionType == 'add_payment');
                return _AuditLogTile(
                  log: log,
                  isUndoable: isUndoable,
                  onUndo: isUndoable ? () => _confirmUndo(context, log) : null,
                );
              },
            ),
    );
  }

  Future<void> _confirmUndo(BuildContext context, AuditLog log) async {
    final label = log.actionType == 'add_debt' ? 'إضافة الدين' : 'التسديد';
    final messenger = ScaffoldMessenger.of(context);
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تراجع عن العملية'),
        content: Text(
          'هل تريد التراجع عن آخر عملية "$label"؟\nهذا الإجراء لا يمكن التراجع عنه.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('تراجع'),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    try {
      if (log.actionType == 'add_debt') {
        await _undoAddDebt(log);
      } else if (log.actionType == 'add_payment') {
        await _undoAddPayment(log);
      }

      await HiveService.auditLogs.delete(log.key);

      ref.invalidate(customersProvider);
      ref.invalidate(debtsProvider);
      ref.invalidate(dashboardStatsProvider);

      _loadLogs();

      messenger.showSnackBar(
        const SnackBar(
          content: Text('تم التراجع عن العملية'),
          backgroundColor: AppColors.success,
        ),
      );
    } catch (e) {
      messenger.showSnackBar(
        SnackBar(
          content: Text('فشل التراجع: $e'),
          backgroundColor: AppColors.error,
        ),
      );
    }
  }

  /// Undo add_debt: delete the debt record and restore product quantity
  Future<void> _undoAddDebt(AuditLog log) async {
    final debtId = log.recordId;
    if (debtId == null) return;

    final debt = HiveService.debts.get(debtId);
    if (debt == null) return;

    // Restore product quantity if applicable
    if (debt.productId != null) {
      final product = HiveService.getProduct(debt.productId!);
      if (product != null) {
        await HiveService.updateProductQuantity(
          debt.productId!,
          product.quantity + debt.productQuantity,
        );
      }
    }

    await HiveService.debts.delete(debtId);
    await HiveService.syncQueue.add({
      'table': 'debts',
      'record_id': debtId,
      'operation': 'delete',
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// Undo add_payment: delete the payment and update debt paidAmount
  Future<void> _undoAddPayment(AuditLog log) async {
    final paymentId = log.recordId;
    if (paymentId == null) return;

    final payment = HiveService.payments.get(paymentId);
    if (payment == null) return;

    // Find the debt and subtract the payment amount
    final debt = HiveService.debts.get(payment.debtId);
    if (debt != null) {
      debt.paidAmount = (debt.paidAmount - payment.amount).clamp(
            0.0,
            debt.amount,
          ).toDouble();
      debt.isPaid = debt.paidAmount >= debt.amount;
      await HiveService.debts.put(debt.id, debt);
      await HiveService.syncQueue.add({
        'table': 'debts',
        'record_id': debt.id,
        'operation': 'upsert',
        'timestamp': DateTime.now().toIso8601String(),
      });
    }

    await HiveService.payments.delete(paymentId);
    await HiveService.syncQueue.add({
      'table': 'payments',
      'record_id': paymentId,
      'operation': 'delete',
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  void _confirmClear(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('مسح السجل'),
        content: const Text('هل أنت متأكد من مسح جميع سجلات العمليات؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            onPressed: () async {
              await HiveService.auditLogs.clear();
              if (ctx.mounted) Navigator.pop(ctx);
              _loadLogs();
            },
            child: const Text('مسح'),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _AuditLogTile extends StatelessWidget {
  final AuditLog log;
  final bool isUndoable;
  final VoidCallback? onUndo;

  const _AuditLogTile({
    required this.log,
    this.isUndoable = false,
    this.onUndo,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Material(
        type: MaterialType.transparency,
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: _actionColor(log.actionType).withValues(alpha: 0.1),
            child: Icon(
              _actionIcon(log.actionType),
              color: _actionColor(log.actionType),
              size: 20,
            ),
          ),
          title: Text(
            _actionLabel(log.actionType),
            style: Theme.of(
              context,
            ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (log.recordId != null)
                Text(
                  'ID: ${log.recordId!.substring(0, 8)}...',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              Text(
                Formatters.formatDateTime(log.createdAt),
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
          trailing: isUndoable
              ? IconButton(
                  icon: const Icon(Icons.undo, color: AppColors.accent),
                  tooltip: 'تراجع',
                  onPressed: onUndo,
                )
              : Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _actionColor(log.actionType).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    log.entity,
                    style: TextStyle(
                      color: _actionColor(log.actionType),
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
        ),
      ),
    );
  }

  Color _actionColor(String actionType) {
    switch (actionType) {
      case 'add_debt':
        return AppColors.error;
      case 'add_payment':
        return AppColors.success;
      case 'delete_debt':
      case 'delete_customer':
        return Colors.orange;
      default:
        return AppColors.primary;
    }
  }

  IconData _actionIcon(String actionType) {
    switch (actionType) {
      case 'add_debt':
        return Icons.add_circle_outline;
      case 'add_payment':
        return Icons.check_circle_outline;
      case 'delete_debt':
      case 'delete_customer':
        return Icons.delete_outline;
      default:
        return Icons.edit_outlined;
    }
  }

  String _actionLabel(String actionType) {
    switch (actionType) {
      case 'add_debt':
        return 'إضافة دين';
      case 'add_payment':
        return 'تسديد دين';
      case 'delete_debt':
        return 'حذف دين';
      case 'delete_customer':
        return 'حذف زبون';
      case 'add_customer':
        return 'إضافة زبون';
      case 'update_customer':
        return 'تعديل زبون';
      default:
        return actionType;
    }
  }
}
