import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/constants/strings.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/services/security_service.dart';
import '../../../core/services/sync_service.dart';
import '../../../shared/widgets/success_pulse_overlay.dart';
import '../../../services/backup_service.dart';
import '../../../data/local/hive_service.dart';
import '../../../shared/providers/theme_provider.dart';
import '../../customers/providers/customers_provider.dart';
import '../../customers/providers/debts_provider.dart';
import '../../inventory/providers/inventory_provider.dart';
import '../../installments/providers/installments_provider.dart';
import '../../dashboard/providers/dashboard_provider.dart';
import '../../auth/providers/auth_provider.dart';
import '../../auth/screens/setup_pin_screen.dart';
import 'audit_log_screen.dart';
import 'trash_screen.dart';
import 'thermal_printer_pairing_screen.dart';
import '../../../data/models/settings.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Watch settingsProvider so the screen rebuilds on every change
    final settings = ref.watch(settingsProvider);
    final themeMode = ref.watch(themeModeProvider);
    final themeColor = ref.watch(themeColorProvider);
    final authState = ref.watch(authNotifierProvider);

    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.settings)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppDimensions.paddingScreen),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Store Info ──────────────────────────────────────────────────
            _buildSectionHeader(context, AppStrings.storeInfo),
            _buildSettingsTile(
              context,
              icon: Icons.store,
              title: AppStrings.storeName,
              subtitle: settings.storeName,
              onTap: () =>
                  _showEditStoreNameDialog(context, ref, settings.storeName),
            ),
            _buildSettingsTile(
              context,
              icon: Icons.image,
              title: AppStrings.storeLogo,
              subtitle: 'تغيير شعار المتجر',
              trailing: settings.storeLogoPath != null
                  ? CircleAvatar(
                      radius: 20,
                      backgroundImage: FileImage(File(settings.storeLogoPath!)),
                    )
                  : null,
              onTap: () => _pickStoreLogo(context, ref),
            ),

            _buildSettingsTile(
              context,
              icon: Icons.phone,
              title: 'هاتف المتجر',
              subtitle: settings.storePhone ?? 'غير محدد',
              onTap: () =>
                  _showEditStorePhoneDialog(context, ref, settings.storePhone),
            ),

            const SizedBox(height: AppDimensions.spacingXl),
            _buildSectionHeader(context, AppStrings.account),
            authState.when(
              data: (user) => _buildSettingsTile(
                context,
                icon: Icons.person,
                title: user?.email ?? 'غير مسجل',
                subtitle: AppStrings.signInWithGoogle,
                trailing: user != null
                    ? const Icon(Icons.check_circle, color: AppColors.success)
                    : const Icon(Icons.warning, color: AppColors.warning),
                onTap: user == null
                    ? () => ref
                          .read(authNotifierProvider.notifier)
                          .signInWithGoogle()
                    : null,
              ),
              loading: () => const ListTile(
                leading: CircularProgressIndicator(),
                title: Text('جاري التحميل...'),
              ),
              error: (_, __) => const ListTile(
                leading: Icon(Icons.error),
                title: Text('خطأ في التحميل'),
              ),
            ),
            if (authState.value != null)
              _buildSettingsTile(
                context,
                icon: Icons.logout,
                title: AppStrings.signOut,
                subtitle: 'تسجيل الخروج من حساب Google',
                iconColor: AppColors.error,
                onTap: () => _confirmSignOut(context, ref),
              ),

            const SizedBox(height: AppDimensions.spacingXl),

            // ── Appearance ──────────────────────────────────────────────────
            _buildSectionHeader(context, AppStrings.appearance),
            SwitchListTile(
              secondary: const Icon(Icons.dark_mode),
              title: const Text(AppStrings.darkMode),
              subtitle: Text(
                themeMode == ThemeMode.dark ? 'مفعّل' : 'غير مفعّل',
              ),
              value: themeMode == ThemeMode.dark,
              onChanged: (_) => ref.read(themeModeProvider.notifier).toggle(),
            ),
            _buildSettingsTile(
              context,
              icon: Icons.palette,
              title: AppStrings.themeColor,
              subtitle: 'اختر لوناً أساسياً للتطبيق',
              trailing: Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: themeColor,
                  shape: BoxShape.circle,
                ),
              ),
              onTap: () => _showColorPicker(context, ref),
            ),

            const SizedBox(height: AppDimensions.spacingXl),

            // ── Backup ──────────────────────────────────────────────────────
            _buildSectionHeader(context, AppStrings.backup),
            SwitchListTile(
              secondary: const Icon(Icons.backup),
              title: const Text(AppStrings.autoBackup),
              subtitle: const Text('نسخ احتياطي تلقائي يومي'),
              value: settings.autoBackup,
              onChanged: (value) => ref
                  .read(settingsProvider.notifier)
                  .update(settings.copyWith(autoBackup: value)),
            ),
            _buildSettingsTile(
              context,
              icon: Icons.cloud_upload,
              title: AppStrings.backupNow,
              subtitle: settings.lastBackupAt != null
                  ? 'آخر نسخ: ${Formatters.formatDateTime(settings.lastBackupAt!)}'
                  : 'لم يتم النسخ بعد',
              onTap: () => _performBackup(context, ref),
            ),
            _buildSettingsTile(
              context,
              icon: Icons.file_download,
              title: 'تصدير نسخة احتياطية',
              subtitle: 'حفظ نسخة من البيانات كملف',
              onTap: () => _exportBackup(context),
            ),
            _buildSettingsTile(
              context,
              icon: Icons.file_upload,
              title: 'استيراد نسخة احتياطية',
              subtitle: 'استعادة بيانات من ملف سابق',
              onTap: () => _importBackup(context, ref),
            ),

            const SizedBox(height: AppDimensions.spacingXl),

            // ── Notifications ───────────────────────────────────────────────
            _buildSectionHeader(context, 'الإشعارات'),
            SwitchListTile(
              secondary: const Icon(Icons.notifications_active),
              title: const Text('تفعيل الإشعارات'),
              subtitle: const Text('إشعارات فورية ويومية وأسبوعية'),
              value: settings.notificationsEnabled,
              onChanged: (value) => ref
                  .read(settingsProvider.notifier)
                  .update(settings.copyWith(notificationsEnabled: value)),
            ),
            SwitchListTile(
              secondary: const Icon(Icons.notification_important),
              title: const Text('إشعارات فورية'),
              subtitle: const Text('عند إضافة دين أو تسديد'),
              value: settings.immediateNotificationsEnabled,
              onChanged: settings.notificationsEnabled
                  ? (value) => ref
                        .read(settingsProvider.notifier)
                        .update(
                          settings.copyWith(
                            immediateNotificationsEnabled: value,
                          ),
                        )
                  : null,
            ),
            SwitchListTile(
              secondary: const Icon(Icons.today),
              title: const Text('تذكير يومي'),
              subtitle: const Text('الساعة 9 صباحاً'),
              value: settings.dailyNotificationsEnabled,
              onChanged: settings.notificationsEnabled
                  ? (value) => ref
                        .read(settingsProvider.notifier)
                        .update(
                          settings.copyWith(dailyNotificationsEnabled: value),
                        )
                  : null,
            ),
            SwitchListTile(
              secondary: const Icon(Icons.calendar_view_week),
              title: const Text('ملخص أسبوعي'),
              subtitle: const Text('كل سبت - المتأخرون عن السداد'),
              value: settings.weeklyNotificationsEnabled,
              onChanged: settings.notificationsEnabled
                  ? (value) => ref
                        .read(settingsProvider.notifier)
                        .update(
                          settings.copyWith(weeklyNotificationsEnabled: value),
                        )
                  : null,
            ),
            SwitchListTile(
              secondary: const Icon(Icons.notifications_active),
              title: const Text('تنبيه استباقي قبل القسط'),
              subtitle: const Text('إشعار قبل يوم من موعد استحقاق القسط'),
              value: settings.notifyBeforeInstallment,
              onChanged: settings.notificationsEnabled
                  ? (value) => ref
                        .read(settingsProvider.notifier)
                        .update(
                          settings.copyWith(notifyBeforeInstallment: value),
                        )
                  : null,
            ),
            _buildSettingsTile(
              context,
              icon: Icons.timer,
              title: 'مدة التأخير',
              subtitle: '${settings.lateThresholdDays} يوم',
              onTap: () => _showLateThresholdPicker(context, ref, settings),
            ),

            const SizedBox(height: AppDimensions.spacingXl),

            // ── Business Settings ───────────────────────────────────────────
            _buildSectionHeader(context, 'إعدادات الأعمال'),
            _buildSettingsTile(
              context,
              icon: Icons.trending_down,
              title: 'عتبة هامش الربح المنخفض',
              subtitle:
                  'تنبيه عند انخفاض هامش الربح عن ${(settings.lowProfitMarginThreshold * 100).toStringAsFixed(0)}%',
              onTap: () =>
                  _showProfitMarginThresholdDialog(context, ref, settings),
            ),

            const SizedBox(height: AppDimensions.spacingXl),

            // ── Security ────────────────────────────────────────────────────
            _buildSectionHeader(context, 'الأمان'),
            SwitchListTile(
              secondary: const Icon(Icons.fingerprint),
              title: const Text('بصمة الإصبع / Face ID'),
              subtitle: const Text('فتح التطبيق بالبصمة'),
              value: settings.biometricEnabled,
              onChanged: (value) async {
                if (value) {
                  final available =
                      await SecurityService.isBiometricAvailable();
                  if (!available) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('البصمة غير متاحة على هذا الجهاز'),
                        ),
                      );
                    }
                    return;
                  }
                  // Require PIN fallback when enabling biometric
                  if (!settings.pinEnabled) {
                    if (!context.mounted) return;
                    final saved = await Navigator.push<bool>(
                      context,
                      MaterialPageRoute(builder: (_) => const SetupPinScreen()),
                    );
                    if (saved != true) return; // user cancelled PIN setup
                    ref
                        .read(settingsProvider.notifier)
                        .update(
                          settings.copyWith(
                            biometricEnabled: true,
                            pinEnabled: true,
                          ),
                        );
                    return;
                  }
                }
                ref
                    .read(settingsProvider.notifier)
                    .update(settings.copyWith(biometricEnabled: value));
              },
            ),
            SwitchListTile(
              secondary: const Icon(Icons.pin),
              title: const Text('رمز PIN احتياطي'),
              subtitle: const Text('فتح التطبيق برمز PIN'),
              value: settings.pinEnabled,
              onChanged: (value) async {
                if (value) {
                  // Open setup screen; only enable if user saves PIN
                  final saved = await Navigator.push<bool>(
                    context,
                    MaterialPageRoute(builder: (_) => const SetupPinScreen()),
                  );
                  if (saved == true) {
                    ref
                        .read(settingsProvider.notifier)
                        .update(settings.copyWith(pinEnabled: true));
                  }
                } else {
                  await SecurityService.clearPin();
                  ref
                      .read(settingsProvider.notifier)
                      .update(settings.copyWith(pinEnabled: false));
                }
              },
            ),
            if (settings.pinEnabled)
              _buildSettingsTile(
                context,
                icon: Icons.edit,
                title: 'تغيير رمز PIN',
                subtitle: 'تحديث رمز PIN الحالي',
                onTap: () async {
                  final saved = await Navigator.push<bool>(
                    context,
                    MaterialPageRoute(builder: (_) => const SetupPinScreen()),
                  );
                  if (saved == true && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('تم تحديث رمز PIN'),
                        backgroundColor: AppColors.success,
                      ),
                    );
                  }
                },
              ),
            _buildSettingsTile(
              context,
              icon: Icons.lock_clock,
              title: 'قفل تلقائي',
              subtitle: _lockTimeoutLabel(settings.autoLockTimeoutSeconds),
              onTap: () => _showLockTimeoutPicker(context, ref, settings),
            ),

            const SizedBox(height: AppDimensions.spacingXl),

            // ── Sync Status ──────────────────────────────────────────────────
            _buildSectionHeader(context, 'حالة المزامنة'),
            const _SyncStatusTile(),

            const SizedBox(height: AppDimensions.spacingXl),

            // ── Print Settings ──────────────────────────────────────────────
            _buildSectionHeader(context, 'إعدادات الطباعة'),
            _buildSettingsTile(
              context,
              icon: Icons.print,
              title: 'نوع الطابعة',
              subtitle: _printerTypeLabel(settings.printerType),
              onTap: () => _showPrinterTypePicker(context, ref, settings),
            ),
            if (settings.printerType != 'a4')
              _buildSettingsTile(
                context,
                icon: Icons.bluetooth,
                title: 'اقتران الطابعة الحرارية',
                subtitle: settings.lastPrinterName != null
                    ? settings.lastPrinterName!
                    : 'ابحث عن الطابعات واقترن بها',
                iconColor: AppColors.primary,
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const ThermalPrinterPairingScreen(),
                  ),
                ),
              ),
            _buildSettingsTile(
              context,
              icon: Icons.phone,
              title: 'رقم هاتف المتجر',
              subtitle: settings.storePhone?.isNotEmpty == true
                  ? settings.storePhone!
                  : 'غير محدد (يظهر في الفاتورة)',
              onTap: () =>
                  _showEditStorePhoneDialog(context, ref, settings.storePhone),
            ),

            const SizedBox(height: AppDimensions.spacingXl),

            // ── Audit Log ────────────────────────────────────────────────────
            _buildSectionHeader(context, 'سجل العمليات'),
            _buildSettingsTile(
              context,
              icon: Icons.history,
              title: 'سجل العمليات',
              subtitle: 'عرض جميع العمليات الحساسة',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AuditLogScreen()),
              ),
            ),

            // ── Trash ─────────────────────────────────────────────────────────
            _buildSectionHeader(context, 'العناصر المحذوفة'),
            _buildSettingsTile(
              context,
              icon: Icons.delete_outline,
              title: 'سلة المحذوفات',
              subtitle: 'استرجاع أو حذف نهائي للزبائن والمنتجات المحذوفة',
              iconColor: Colors.orange,
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const TrashScreen()),
              ),
            ),

            // ── Privacy Policy ────────────────────────────────────────────────
            _buildSettingsTile(
              context,
              icon: Icons.privacy_tip_outlined,
              title: 'سياسة الخصوصية',
              subtitle: 'عرض سياسة الخصوصية للتطبيق',
              onTap: () => launchUrl(
                Uri.parse('https://github.com/ttanto502/madeen-privacy'),
              ),
            ),

            const SizedBox(height: AppDimensions.spacing3xl),
          ],
        ),
      ),
    );
  }

  // ── Helpers ────────────────────────────────────────────────────────────────

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimensions.spacingSm),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
          color: Theme.of(context).colorScheme.primary,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildSettingsTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    String? subtitle,
    Widget? trailing,
    Color? iconColor,
    VoidCallback? onTap,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: AppDimensions.spacingSm),
      child: Material(
        type: MaterialType.transparency,
        child: ListTile(
          leading: Icon(
            icon,
            color: iconColor ?? Theme.of(context).colorScheme.primary,
          ),
          title: Text(title),
          subtitle: subtitle != null ? Text(subtitle) : null,
          trailing:
              trailing ?? (onTap != null ? const Icon(Icons.chevron_left) : null),
          onTap: onTap,
        ),
      ),
    );
  }

  void _showEditStoreNameDialog(
    BuildContext context,
    WidgetRef ref,
    String currentName,
  ) {
    final controller = TextEditingController(text: currentName);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text(AppStrings.storeName),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: 'أدخل اسم المتجر'),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(AppStrings.cancel),
          ),
          ElevatedButton(
            onPressed: () async {
              if (controller.text.isNotEmpty) {
                final s = ref.read(settingsProvider);
                await ref
                    .read(settingsProvider.notifier)
                    .update(s.copyWith(storeName: controller.text));
                if (context.mounted) Navigator.pop(context);
              }
            },
            child: const Text(AppStrings.save),
          ),
        ],
      ),
    );
  }

  Future<void> _pickStoreLogo(BuildContext context, WidgetRef ref) async {
    final picker = ImagePicker();
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (context) => SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt),
                title: const Text(AppStrings.takePhoto),
                onTap: () => Navigator.pop(context, ImageSource.camera),
              ),
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text(AppStrings.chooseFromGallery),
                onTap: () => Navigator.pop(context, ImageSource.gallery),
              ),
            ],
          ),
        ),
      ),
    );
    if (source == null) return;
    final image = await picker.pickImage(source: source, imageQuality: 80);
    if (image != null) {
      final s = ref.read(settingsProvider);
      await ref
          .read(settingsProvider.notifier)
          .update(s.copyWith(storeLogoPath: image.path));
    }
  }

  void _showColorPicker(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(AppDimensions.paddingScreen),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  AppStrings.themeColor,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: AppDimensions.spacingLg),
                Wrap(
                  spacing: AppDimensions.spacingMd,
                  runSpacing: AppDimensions.spacingMd,
                  children: AppColors.themePresets.map((color) {
                    return GestureDetector(
                      onTap: () {
                        ref.read(themeColorProvider.notifier).setColor(color);
                        Navigator.pop(context);
                      },
                      child: Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: color,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: color.withValues(alpha: 0.4),
                              blurRadius: 8,
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: AppDimensions.spacingLg),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _confirmSignOut(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text(AppStrings.signOut),
        content: const Text('هل أنت متأكد من تسجيل الخروج؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(AppStrings.cancel),
          ),
          ElevatedButton(
            onPressed: () {
              ref.read(authNotifierProvider.notifier).signOut();
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            child: const Text(AppStrings.signOut),
          ),
        ],
      ),
    );
  }

  String _lockTimeoutLabel(int seconds) {
    switch (seconds) {
      case 0:
        return 'فوري';
      case 30:
        return '30 ثانية';
      case 60:
        return 'دقيقة';
      case 300:
        return '5 دقائق';
      case -1:
        return 'أبداً';
      default:
        return '$seconds ثانية';
    }
  }

  void _showLateThresholdPicker(BuildContext context, WidgetRef ref, settings) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(AppDimensions.paddingScreen),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'اختر مدة التأخير',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: AppDimensions.spacingLg),
                ...[7, 14, 30].map(
                  (days) => ListTile(
                    title: Text('$days يوم'),
                    trailing: settings.lateThresholdDays == days
                        ? const Icon(Icons.check, color: AppColors.success)
                        : null,
                    onTap: () async {
                      await ref
                          .read(settingsProvider.notifier)
                          .update(settings.copyWith(lateThresholdDays: days));
                      if (context.mounted) Navigator.pop(context);
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showProfitMarginThresholdDialog(
    BuildContext context,
    WidgetRef ref,
    AppSettings settings,
  ) {
    double selectedThreshold = settings.lowProfitMarginThreshold;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('عتبة هامش الربح المنخفض'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'المنتجات التي يقل هامش ربحها عن ${(selectedThreshold * 100).toStringAsFixed(0)}% سيتم تمييزها بتنبيه.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: AppDimensions.spacingLg),
              Text(
                '${(selectedThreshold * 100).toStringAsFixed(0)}%',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  color: AppColors.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Slider(
                value: selectedThreshold,
                min: 0.0,
                max: 0.50,
                divisions: 50,
                label: '${(selectedThreshold * 100).toStringAsFixed(0)}%',
                onChanged: (value) {
                  setState(() {
                    selectedThreshold = value;
                  });
                },
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('0%', style: Theme.of(context).textTheme.bodySmall),
                  Text('50%', style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(AppStrings.cancel),
            ),
            ElevatedButton(
              onPressed: () async {
                await ref
                    .read(settingsProvider.notifier)
                    .update(
                      settings.copyWith(
                        lowProfitMarginThreshold: selectedThreshold,
                      ),
                    );
                if (context.mounted) {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'تم تحديث العتبة إلى ${(selectedThreshold * 100).toStringAsFixed(0)}%',
                      ),
                      backgroundColor: AppColors.success,
                    ),
                  );
                }
              },
              child: const Text(AppStrings.save),
            ),
          ],
        ),
      ),
    );
  }

  void _showLockTimeoutPicker(BuildContext context, WidgetRef ref, settings) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(AppDimensions.paddingScreen),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'اختر مدة القفل التلقائي',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: AppDimensions.spacingLg),
                ...[
                  (0, 'فوري'),
                  (30, '30 ثانية'),
                  (60, 'دقيقة'),
                  (300, '5 دقائق'),
                  (-1, 'أبداً'),
                ].map((entry) {
                  final (seconds, label) = entry;
                  return ListTile(
                    title: Text(label),
                    trailing: settings.autoLockTimeoutSeconds == seconds
                        ? const Icon(Icons.check, color: AppColors.success)
                        : null,
                    onTap: () async {
                      await ref
                          .read(settingsProvider.notifier)
                          .update(
                            settings.copyWith(autoLockTimeoutSeconds: seconds),
                          );
                      if (context.mounted) Navigator.pop(context);
                    },
                  );
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _performBackup(BuildContext context, WidgetRef ref) async {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('جاري النسخ الاحتياطي...')));
    try {
      await SyncService.syncAll();
      final s = ref.read(settingsProvider);
      await ref
          .read(settingsProvider.notifier)
          .update(s.copyWith(lastBackupAt: DateTime.now()));
      if (context.mounted) {
        HapticFeedback.lightImpact();
        SuccessPulseOverlay.show(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تمت المزامنة بنجاح'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('خطأ: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  Future<void> _exportBackup(BuildContext context) async {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('جاري تصدير النسخة الاحتياطية...')),
    );
    try {
      final result = await BackupService.exportToFile();
      if (!result.success) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(result.message),
              backgroundColor: AppColors.error,
            ),
          );
        }
        return;
      }
      if (context.mounted) {
        HapticFeedback.lightImpact();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تم تصدير النسخة الاحتياطية بنجاح'),
            backgroundColor: AppColors.success,
          ),
        );
        await BackupService.shareBackupFile();
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('خطأ: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  Future<void> _importBackup(BuildContext context, WidgetRef ref) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
      );
      if (result == null || result.files.isEmpty) return;

      final file = File(result.files.single.path!);
      if (!context.mounted) return;
      final confirm = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('استيراد نسخة احتياطية'),
          content: const Text(
            'سيتم استبدال جميع البيانات الحالية بالبيانات المستوردة. '
            'هل أنت متأكد؟',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('تأكيد'),
            ),
          ],
        ),
      );
      if (confirm != true) return;
      if (!context.mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('جاري استيراد النسخة الاحتياطية...')),
      );

      final importResult = await BackupService.importFromFile(file);

      // تحديث جميع الـ providers بعد الاستيراد
      if (importResult.success) {
        ref.invalidate(customersProvider);
        ref.invalidate(debtsProvider);
        ref.invalidate(productsProvider);
        ref.invalidate(installmentsProvider);
        ref.invalidate(dashboardStatsProvider);
        ref.invalidate(settingsProvider);
      }

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(importResult.message),
            backgroundColor: importResult.success
                ? AppColors.success
                : AppColors.error,
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('خطأ: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  // ── Printer Settings Helpers ────────────────────────────────────────────

  String _printerTypeLabel(String type) {
    switch (type) {
      case 'thermal_80mm':
        return 'طابعة حرارية 80mm';
      case 'thermal_58mm':
        return 'طابعة حرارية 58mm';
      case 'a4':
      default:
        return 'طابعة عادية A4';
    }
  }

  void _showPrinterTypePicker(
    BuildContext context,
    WidgetRef ref,
    AppSettings settings,
  ) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(AppDimensions.paddingScreen),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'اختر نوع الطابعة',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: AppDimensions.spacingLg),
                ...[
                  ('a4', 'طابعة عادية A4', Icons.print),
                  ('thermal_80mm', 'طابعة حرارية 80mm', Icons.local_printshop),
                  (
                    'thermal_58mm',
                    'طابعة حرارية 58mm',
                    Icons.local_printshop_outlined,
                  ),
                ].map((entry) {
                  final (type, label, icon) = entry;
                  return ListTile(
                    leading: Icon(icon, color: AppColors.primary),
                    title: Text(label),
                    trailing: settings.printerType == type
                        ? const Icon(Icons.check, color: AppColors.success)
                        : null,
                    onTap: () async {
                      await ref
                          .read(settingsProvider.notifier)
                          .update(settings.copyWith(printerType: type));
                      if (context.mounted) Navigator.pop(context);
                    },
                  );
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showEditStorePhoneDialog(
    BuildContext context,
    WidgetRef ref,
    String? currentPhone,
  ) {
    final controller = TextEditingController(text: currentPhone ?? '');
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('هاتف المتجر'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: 'أدخل رقم هاتف المتجر'),
          keyboardType: TextInputType.phone,
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(AppStrings.cancel),
          ),
          ElevatedButton(
            onPressed: () async {
              final s = ref.read(settingsProvider);
              await ref
                  .read(settingsProvider.notifier)
                  .update(
                    s.copyWith(
                      storePhone: controller.text.isEmpty
                          ? null
                          : controller.text,
                    ),
                  );
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text(AppStrings.save),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Extracted sync-status tile that caches the isOnline Future in initState,
// preventing a new Future from being created on every SettingsScreen rebuild.
// ---------------------------------------------------------------------------
class _SyncStatusTile extends StatefulWidget {
  const _SyncStatusTile();

  @override
  State<_SyncStatusTile> createState() => _SyncStatusTileState();
}

class _SyncStatusTileState extends State<_SyncStatusTile> {
  late Future<bool> _onlineFuture;

  @override
  void initState() {
    super.initState();
    _onlineFuture = SyncService.isOnline();
  }

  void _refresh() {
    setState(() {
      _onlineFuture = SyncService.isOnline();
    });
  }

  @override
  Widget build(BuildContext context) {
    final pendingCount = HiveService.getSyncQueue().length;
    return FutureBuilder<bool>(
      future: _onlineFuture,
      builder: (context, snapshot) {
        final isOnline = snapshot.data ?? false;
        return ListTile(
          onTap: _refresh, // tap to recheck connection
          leading: Icon(
            isOnline ? Icons.cloud_done : Icons.cloud_off,
            color: isOnline ? AppColors.success : AppColors.error,
          ),
          title: Text(isOnline ? AppStrings.online : AppStrings.offline),
          subtitle: Text(
            isOnline
                ? (pendingCount > 0
                      ? 'متصل - $pendingCount تغيير في انتظار المزامنة'
                      : 'متصل - البيانات متزامنة')
                : 'غير متصل - البيانات محفوظة محلياً',
          ),
          trailing: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: pendingCount > 0 ? AppColors.warning : AppColors.success,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              pendingCount > 0 ? '🔴 في انتظار المزامنة' : '🟢 متزامن',
              style: const TextStyle(color: Colors.white, fontSize: 12),
            ),
          ),
        );
      },
    );
  }
}
