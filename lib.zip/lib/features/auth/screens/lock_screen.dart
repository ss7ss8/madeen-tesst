import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/services/security_service.dart';
import '../../../data/local/hive_service.dart';

/// Shown when the app is locked. Calls [onUnlocked] on success.
class LockScreen extends ConsumerStatefulWidget {
  final VoidCallback onUnlocked;

  const LockScreen({super.key, required this.onUnlocked});

  @override
  ConsumerState<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends ConsumerState<LockScreen> {
  final List<String> _pin = [];
  bool _hasError = false;
  bool _biometricAvailable = false;
  static const int _pinLength = 4;

  @override
  void initState() {
    super.initState();
    _checkBiometric();
  }

  Future<void> _checkBiometric() async {
    final settings = HiveService.getAppSettings();
    if (!settings.biometricEnabled) return;
    final available = await SecurityService.isBiometricAvailable();
    if (mounted) setState(() => _biometricAvailable = available);
    if (available) _tryBiometric();
  }

  Future<void> _tryBiometric() async {
    final success = await SecurityService.authenticateWithBiometric();
    if (success && mounted) widget.onUnlocked();
  }

  void _onKeyTap(String key) {
    if (_pin.length >= _pinLength) return;
    setState(() {
      _pin.add(key);
      _hasError = false;
    });
    if (_pin.length == _pinLength) _verifyPin();
  }

  void _onDelete() {
    if (_pin.isEmpty) return;
    setState(() => _pin.removeLast());
  }

  Future<void> _verifyPin() async {
    final entered = _pin.join();
    final settings = HiveService.getAppSettings();

    bool valid = false;
    if (settings.pinEnabled) {
      valid = await SecurityService.verifyPin(entered);
    }
    // Biometric-only mode: PIN entry is not accepted.
    // The numpad is only shown when biometric hardware is unavailable,
    // but we must never grant access or enroll a new PIN without prior
    // biometric confirmation. Reject silently.

    if (valid) {
      widget.onUnlocked();
    } else {
      setState(() {
        _hasError = true;
        _pin.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = HiveService.getAppSettings();
    // Show PIN UI when PIN is enabled, or in biometric-only mode when biometric is unavailable (emergency fallback)
    final showPinUI =
        settings.pinEnabled ||
        (settings.biometricEnabled && !_biometricAvailable);
    final pinOnlyMode = settings.pinEnabled;

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.primary,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: IntrinsicHeight(
                  child: Column(
                    children: [
                      const Spacer(),

                      const Icon(Icons.lock, size: 64, color: Colors.white),
                      const SizedBox(height: AppDimensions.spacingMd),
                      const Text(
                        'مدين',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: AppDimensions.spacingSm),
                      Text(
                        pinOnlyMode
                            ? 'أدخل رمز PIN'
                            : _biometricAvailable
                            ? 'استخدم البصمة لفتح التطبيق'
                            : 'البصمة غير متاحة — استخدم البصمة على جهاز آخر أو تواصل مع الدعم',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.8),
                          fontSize: 16,
                        ),
                      ),

                      const SizedBox(height: AppDimensions.spacingXl),

                      // PIN dots — show when PIN is expected
                      if (showPinUI) ...[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(_pinLength, (i) {
                            final filled = i < _pin.length;
                            return Container(
                              margin: const EdgeInsets.symmetric(
                                horizontal: AppDimensions.spacingMd,
                              ),
                              width: 18,
                              height: 18,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _hasError
                                    ? Colors.red[300]
                                    : filled
                                    ? Colors.white
                                    : Colors.white.withValues(alpha: 0.3),
                                border: Border.all(
                                  color: Colors.white,
                                  width: 2,
                                ),
                              ),
                            );
                          }),
                        ),

                        if (_hasError) ...[
                          const SizedBox(height: AppDimensions.spacingMd),
                          const Text(
                            'رمز PIN غير صحيح',
                            style: TextStyle(color: Colors.red, fontSize: 14),
                          ),
                        ],
                      ],

                      const Spacer(),

                      // Biometric-only mode: show big fingerprint button
                      if (!pinOnlyMode && _biometricAvailable)
                        GestureDetector(
                          onTap: _tryBiometric,
                          child: Container(
                            width: 96,
                            height: 96,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withValues(alpha: 0.15),
                              border: Border.all(
                                color: Colors.white.withValues(alpha: 0.4),
                                width: 2,
                              ),
                            ),
                            child: const Icon(
                              Icons.fingerprint,
                              color: Colors.white,
                              size: 52,
                            ),
                          ),
                        ),

                      // Numpad — show when PIN is expected
                      if (showPinUI)
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppDimensions.spacing3xl,
                          ),
                          child: Column(
                            children: [
                              _buildRow(['1', '2', '3']),
                              const SizedBox(height: AppDimensions.spacingLg),
                              _buildRow(['4', '5', '6']),
                              const SizedBox(height: AppDimensions.spacingLg),
                              _buildRow(['7', '8', '9']),
                              const SizedBox(height: AppDimensions.spacingLg),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  _buildSpecialKey(
                                    _biometricAvailable
                                        ? const Icon(
                                            Icons.fingerprint,
                                            color: Colors.white,
                                            size: 28,
                                          )
                                        : const SizedBox(width: 60),
                                    _biometricAvailable ? _tryBiometric : null,
                                  ),
                                  _buildNumberKey('0'),
                                  _buildSpecialKey(
                                    const Icon(
                                      Icons.backspace_outlined,
                                      color: Colors.white,
                                      size: 24,
                                    ),
                                    _onDelete,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                      const SizedBox(height: AppDimensions.spacing3xl),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildRow(List<String> keys) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: keys.map(_buildNumberKey).toList(),
    );
  }

  Widget _buildNumberKey(String digit) {
    return GestureDetector(
      onTap: () => _onKeyTap(digit),
      child: Container(
        width: 72,
        height: 72,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withValues(alpha: 0.15),
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        alignment: Alignment.center,
        child: Text(
          digit,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Widget _buildSpecialKey(Widget child, VoidCallback? onTap) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(width: 72, height: 72, child: Center(child: child)),
    );
  }
}
