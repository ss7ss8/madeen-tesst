import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/constants/dimensions.dart';
import '../providers/auth_provider.dart';

class LoginScreen extends ConsumerWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authNotifier = ref.read(authNotifierProvider.notifier);
    final authState = ref.watch(authNotifierProvider);

    // Show error dialog if there's an error
    authState.whenOrNull(
      error: (error, stack) {
        if (error.toString().isNotEmpty) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('خطأ: $error'),
                backgroundColor: Colors.red,
                action: SnackBarAction(
                  label: 'إغلاق',
                  textColor: Colors.white,
                  onPressed: () {},
                ),
              ),
            );
          });
        }
      },
    );

    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: IntrinsicHeight(
                  child: Padding(
                    padding: const EdgeInsets.all(AppDimensions.paddingScreen),
                    child: Column(
                      children: [
                        const Spacer(),

                        // Logo and Title
                        Icon(
                              Icons.account_balance_wallet,
                              size: 120,
                              color: AppColors.primary,
                            )
                            .animate()
                            .fadeIn(duration: 600.ms)
                            .scale(begin: const Offset(0.8, 0.8)),

                        const SizedBox(height: AppDimensions.spacingXl),

                        Text(
                              AppStrings.appName,
                              style: Theme.of(context).textTheme.displayMedium
                                  ?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.primary,
                                  ),
                            )
                            .animate()
                            .fadeIn(delay: 200.ms, duration: 600.ms)
                            .slideY(begin: 0.3),

                        const SizedBox(height: AppDimensions.spacingSm),

                        Text(
                              AppStrings.appDescription,
                              style: Theme.of(context).textTheme.bodyLarge
                                  ?.copyWith(
                                    color: AppColors.textSecondaryLight,
                                  ),
                            )
                            .animate()
                            .fadeIn(delay: 300.ms, duration: 600.ms)
                            .slideY(begin: 0.3),

                        const Spacer(),

                        // Features list
                        _buildFeatureItem(
                              context,
                              Icons.cloud_done,
                              'مزامنة سحابية',
                              'احفظ بياناتك بأمان على السحابة',
                            )
                            .animate()
                            .fadeIn(delay: 400.ms, duration: 500.ms)
                            .slideX(begin: -0.2),

                        const SizedBox(height: AppDimensions.spacingMd),

                        _buildFeatureItem(
                              context,
                              Icons.wifi_off,
                              'يعمل بدون إنترنت',
                              'أضف بياناتك الآن واعمل بدون قلق',
                            )
                            .animate()
                            .fadeIn(delay: 500.ms, duration: 500.ms)
                            .slideX(begin: -0.2),

                        const SizedBox(height: AppDimensions.spacingMd),

                        _buildFeatureItem(
                              context,
                              Icons.security,
                              'بياناتك محمية',
                              'سجل دخول بـ Google للمزامنة التلقائية',
                            )
                            .animate()
                            .fadeIn(delay: 600.ms, duration: 500.ms)
                            .slideX(begin: -0.2),

                        const Spacer(),

                        // Error message if any
                        if (authState.hasError)
                          Container(
                            padding: const EdgeInsets.all(12),
                            margin: const EdgeInsets.only(bottom: 16),
                            decoration: BoxDecoration(
                              color: Colors.red.shade50,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.red.shade200),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.error_outline,
                                  color: Colors.red.shade700,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    'حدث خطأ: ${authState.error}',
                                    style: TextStyle(
                                      color: Colors.red.shade700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ).animate().fadeIn(duration: 300.ms),

                        // Sign In Button
                        SizedBox(
                              width: double.infinity,
                              height: AppDimensions.buttonHeightLg,
                              child: ElevatedButton.icon(
                                onPressed: authState.isLoading
                                    ? null
                                    : () =>
                                          _handleSignIn(context, authNotifier),
                                icon: authState.isLoading
                                    ? const SizedBox(
                                        width: 24,
                                        height: 24,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                          color: Colors.white,
                                        ),
                                      )
                                    : const Icon(Icons.g_mobiledata, size: 32),
                                label: Text(
                                  authState.isLoading
                                      ? 'جاري التسجيل...'
                                      : AppStrings.signInWithGoogle,
                                ),
                              ),
                            )
                            .animate()
                            .fadeIn(delay: 700.ms, duration: 600.ms)
                            .slideY(begin: 0.3),

                        const SizedBox(height: AppDimensions.spacingXl),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Future<void> _handleSignIn(
    BuildContext context,
    AuthNotifier authNotifier,
  ) async {
    try {
      await authNotifier.signInWithGoogle();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('فشل التسجيل: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    }
  }

  Widget _buildFeatureItem(
    BuildContext context,
    IconData icon,
    String title,
    String subtitle,
  ) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(AppDimensions.spacingMd),
          decoration: BoxDecoration(
            color: AppColors.primary.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
          ),
          child: Icon(icon, color: AppColors.primary),
        ),
        const SizedBox(width: AppDimensions.spacingMd),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleMedium),
              Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      ],
    );
  }
}
