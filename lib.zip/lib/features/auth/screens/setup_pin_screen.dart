import 'package:flutter/material.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/services/security_service.dart';

/// Screen for setting up or changing the PIN.
/// Returns true if PIN was saved successfully.
class SetupPinScreen extends StatefulWidget {
  const SetupPinScreen({super.key});

  @override
  State<SetupPinScreen> createState() => _SetupPinScreenState();
}

class _SetupPinScreenState extends State<SetupPinScreen> {
  final List<String> _pin = [];
  final List<String> _confirmPin = [];
  bool _isConfirming = false;
  bool _hasError = false;
  static const int _pinLength = 4;

  List<String> get _current => _isConfirming ? _confirmPin : _pin;

  void _onKeyTap(String key) {
    if (_current.length >= _pinLength) return;
    setState(() {
      _current.add(key);
      _hasError = false;
    });
    if (_current.length == _pinLength) {
      if (_isConfirming) {
        _finalize();
      } else {
        setState(() => _isConfirming = true);
      }
    }
  }

  void _onDelete() {
    if (_current.isEmpty) return;
    setState(() => _current.removeLast());
  }

  Future<void> _finalize() async {
    if (_pin.join() != _confirmPin.join()) {
      setState(() {
        _hasError = true;
        _confirmPin.clear();
      });
      return;
    }
    await SecurityService.savePin(_pin.join());
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final dots = _isConfirming ? _confirmPin : _pin;
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.primary,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'إعداد رمز PIN',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: IntrinsicHeight(
                  child: Column(
                    children: [
                      const Spacer(),
                      Text(
                        _isConfirming
                            ? 'أعد إدخال رمز PIN'
                            : 'أدخل رمز PIN جديد',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                        ),
                      ),
                      const SizedBox(height: AppDimensions.spacingXl),

                      // Dots
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(_pinLength, (i) {
                          final filled = i < dots.length;
                          return Container(
                            margin: const EdgeInsets.symmetric(
                              horizontal: AppDimensions.spacingMd,
                            ),
                            width: 18,
                            height: 18,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _hasError
                                  ? Colors.red[300]
                                  : filled
                                  ? Colors.white
                                  : Colors.white.withValues(alpha: 0.3),
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                          );
                        }),
                      ),

                      if (_hasError) ...[
                        const SizedBox(height: AppDimensions.spacingMd),
                        const Text(
                          'رمز PIN غير متطابق، حاول مجدداً',
                          style: TextStyle(color: Colors.red, fontSize: 14),
                        ),
                      ],

                      const Spacer(),

                      // Numpad
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: AppDimensions.spacing3xl,
                        ),
                        child: Column(
                          children: [
                            _buildRow(['1', '2', '3']),
                            const SizedBox(height: AppDimensions.spacingLg),
                            _buildRow(['4', '5', '6']),
                            const SizedBox(height: AppDimensions.spacingLg),
                            _buildRow(['7', '8', '9']),
                            const SizedBox(height: AppDimensions.spacingLg),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                const SizedBox(width: 72, height: 72),
                                _buildNumberKey('0'),
                                GestureDetector(
                                  onTap: _onDelete,
                                  child: SizedBox(
                                    width: 72,
                                    height: 72,
                                    child: Center(
                                      child: Icon(
                                        Icons.backspace_outlined,
                                        color: Colors.white.withValues(
                                          alpha: 0.8,
                                        ),
                                        size: 24,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: AppDimensions.spacing3xl),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildRow(List<String> keys) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: keys.map(_buildNumberKey).toList(),
  );

  Widget _buildNumberKey(String digit) => GestureDetector(
    onTap: () => _onKeyTap(digit),
    child: Container(
      width: 72,
      height: 72,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.white.withValues(alpha: 0.15),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      alignment: Alignment.center,
      child: Text(
        digit,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 24,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
  );
}
