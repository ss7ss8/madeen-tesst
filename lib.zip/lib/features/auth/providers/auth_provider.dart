import 'dart:async';
import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../core/config/app_config.dart';
import '../../../data/local/hive_service.dart';
import '../../../core/services/supabase_service.dart';
import '../../../shared/providers/sync_provider.dart';

final googleSignInProvider = Provider<GoogleSignIn>((ref) {
  final webClientId = AppConfig.googleWebClientId;
  assert(
    webClientId.isNotEmpty,
    'GOOGLE_WEB_CLIENT_ID is empty. Pass it via --dart-define '
    '(see .vscode/launch.json or build_release.ps1).',
  );
  return GoogleSignIn(
    serverClientId: webClientId, // injected via --dart-define
    scopes: <String>['email', 'profile', 'openid'],
  );
});

/// Whether [_isOfflineAuthError] matches the given error.
bool _isOfflineAuthError(Object error) {
  if (error is SocketException) return true;
  if (error is AuthRetryableFetchException) return true;
  final msg = error.toString();
  return msg.contains('SocketException') ||
      msg.contains('Failed host lookup') ||
      msg.contains('No address associated with hostname') ||
      msg.contains('ClientException');
}

/// Provides the current authenticated [User?] as a stream.
///
/// Network failures during background token refresh (offline use) are
/// silently swallowed: the stream emits the locally-cached user so the
/// UI never sees an error state when the device is offline.
final authStateProvider = StreamProvider<User?>((ref) async* {
  // انتظر اكتمال تهيئة التطبيق (Env + Hive + Supabase) أولاً.
  // بدون هذا، يُبنى المزوّد قبل تهيئة Supabase فيُطرح
  // "Supabase not initialized" عند الوصول لـ Supabase.instance.
  await ref.watch(appInitProvider.future);

  // أصدر الجلسة المخزّنة فوراً حتى لا تبقى SplashScreen معلّقة
  // إذا تأخر/فات حدث initialSession على onAuthStateChange.
  yield SupabaseService.currentUser;

  // الآن Supabase جاهز — اشترك في تغييرات حالة المصادقة.
  yield* SupabaseService.authStateChanges.transform(
    StreamTransformer<User?, User?>.fromHandlers(
      handleError: (error, stackTrace, sink) {
        if (_isOfflineAuthError(error)) {
          // Token refresh failed because we're offline.
          // Emit the session that the SDK has cached locally — the user
          // remains authenticated and the app keeps working.
          sink.add(SupabaseService.currentUser);
        } else {
          // Real (non-network) error → propagate normally.
          sink.addError(error, stackTrace);
        }
      },
    ),
  );
});

final authNotifierProvider =
    StateNotifierProvider<AuthNotifier, AsyncValue<User?>>((ref) {
      return AuthNotifier(ref);
    });

class AuthNotifier extends StateNotifier<AsyncValue<User?>> {
  final Ref _ref;

  AuthNotifier(this._ref) : super(const AsyncValue.loading()) {
    // Synchronize this notifier's state with the canonical authStateProvider stream
    _ref.listen<AsyncValue<User?>>(authStateProvider, (previous, next) {
      state = next;
    }, fireImmediately: true);
  }

  Future<void> signInWithGoogle() async {
    state = const AsyncValue.loading();

    try {
      if (AppConfig.googleWebClientId.isEmpty) {
        throw Exception(
          'GOOGLE_WEB_CLIENT_ID غير مُعرَّف. أضِف القيمة إلى ملف .env في '
          'جذر المشروع، أو شغّل التطبيق عبر VS Code (F5)، أو مرّر '
          '--dart-define=GOOGLE_WEB_CLIENT_ID=... عند البناء.',
        );
      }

      final googleSignIn = _ref.read(googleSignInProvider);

      try {
        await googleSignIn.signOut();
      } catch (_) {}

      final googleUser = await googleSignIn.signIn();

      if (googleUser == null) {
        state = const AsyncValue.data(null);
        return;
      }

      final authentication = await googleUser.authentication;
      final idToken = authentication.idToken;
      final accessToken = authentication.accessToken;

      if (idToken == null) {
        throw Exception(
          'Failed to get ID token from Google. Please check Google Cloud Console settings.',
        );
      }

      await SupabaseService.client.auth.signInWithIdToken(
        provider: OAuthProvider.google,
        idToken: idToken,
        accessToken: accessToken,
      );

      final user = SupabaseService.currentUser;
      if (user != null) {
        await HiveService.switchUser(user.id);
        final settings = HiveService.getAppSettings();
        await HiveService.saveAppSettings(settings.copyWith(userId: user.id));
      }

      // Show dashboard immediately — restore + sync run in background via
      // ref.listen(authStateProvider) in DebtTrackerApp.
      state = AsyncValue.data(user);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> signOut() async {
    try {
      final googleSignIn = _ref.read(googleSignInProvider);
      await googleSignIn.signOut();
      await SupabaseService.signOut();
      await HiveService.switchUser(null);
      state = const AsyncValue.data(null);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }
}
