import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:printing/printing.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/constants/strings.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/logger.dart';
import '../../../data/models/customer.dart';
import '../../../data/models/debt.dart';
import '../../../data/models/settings.dart';
import '../../../shared/widgets/success_pulse_overlay.dart';
import '../../../shared/widgets/customer_avatar.dart';
import '../../../data/models/payment.dart';
import '../../../data/local/hive_service.dart';
import '../providers/customers_provider.dart';
import '../providers/debts_provider.dart';
import '../providers/customer_activity_provider.dart';
import 'account_statement_screen.dart';
import '../../../shared/widgets/loading_indicator.dart';
import '../widgets/payment_sheet.dart';
import '../widgets/add_debt_sheet.dart';
import 'package:share_plus/share_plus.dart';
import '../../../shared/providers/pdf_service.dart';
import '../../../shared/providers/thermal_printer_service.dart';
import '../../../shared/providers/thermal_invoice_renderer.dart';
import '../../../shared/providers/thermal_statement_renderer.dart';
import '../../../shared/widgets/printer_disconnect_dialog.dart';
import '../providers/statement_provider.dart';

class CustomerDetailScreen extends ConsumerWidget {
  final String customerId;

  const CustomerDetailScreen({super.key, required this.customerId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final customers = ref.watch(customersProvider);
    final customer = customers.firstWhere(
      (c) => c.id == customerId,
      orElse: () => Customer(
        id: '',
        name: '',
        userId: '',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
    );

    if (customer.id.isEmpty) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: Text('الزبون غير موجود')),
      );
    }

    final totalDebt = ref.watch(customerDebtProvider(customerId));
    final debts = ref
        .watch(debtsProvider.notifier)
        .getDebtsByCustomer(customerId);
    final activities = ref.watch(customerActivityProvider(customerId));

    return Scaffold(
      appBar: AppBar(
        title: Text(customer.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.print),
            onPressed: () =>
                _showPrintOptionsBottomSheet(context, ref, customer, debts),
          ),
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () => _showEditCustomerSheet(context, ref, customer),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () => _confirmDelete(context, ref, customer),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(AppDimensions.paddingScreen),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Theme.of(context).colorScheme.primary,
                    Theme.of(
                      context,
                    ).colorScheme.primary.withValues(alpha: 0.8),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Column(
                children: [
                  GestureDetector(
                    onTap: () => _pickAndUploadImage(context, ref, customer),
                    child: Hero(
                      tag: 'customer_avatar_${customer.id}',
                      child: CustomerAvatar(
                        name: customer.name,
                        imageUrl: customer.imageUrl,
                        radius: 48,
                        reliability: HiveService.customerReliability(
                          customer.id,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: AppDimensions.spacingMd),
                  Text(
                    customer.name,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (customer.phone != null) ...[
                    const SizedBox(height: AppDimensions.spacingXs),
                    Text(
                      customer.phone!,
                      style: Theme.of(
                        context,
                      ).textTheme.bodyMedium?.copyWith(color: Colors.white70),
                    ),
                  ],
                  const SizedBox(height: AppDimensions.spacingSm),
                  _buildReliabilityBadge(context, customer.id),
                  const SizedBox(height: AppDimensions.spacingLg),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppDimensions.spacingXl,
                      vertical: AppDimensions.spacingMd,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(
                        AppDimensions.radiusLg,
                      ),
                    ),
                    child: Column(
                      children: [
                        Text(
                          'المبلغ المستحق',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                        const SizedBox(height: AppDimensions.spacingXs),
                        Text(
                          Formatters.formatCurrencyCompact(totalDebt),
                          style: Theme.of(context).textTheme.headlineMedium
                              ?.copyWith(
                                color: totalDebt > 0
                                    ? AppColors.error
                                    : AppColors.success,
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppDimensions.spacingLg),
                  if (customer.maxDebtLimit != null &&
                      customer.maxDebtLimit! > 0) ...[
                    _buildLimitIndicator(
                      context,
                      totalDebt,
                      customer.maxDebtLimit!,
                    ),
                    const SizedBox(height: AppDimensions.spacingLg),
                  ],
                  // Action Buttons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildActionButton(
                        context,
                        Icons.phone,
                        AppStrings.call,
                        () => _makePhoneCall(context, customer.phone),
                      ),
                      _buildActionButton(
                        context,
                        Icons.chat,
                        'واتساب',
                        () => _sendWhatsApp(context, customer, totalDebt),
                      ),
                       _buildActionButton(
                         context,
                         Icons.share,
                         AppStrings.shareInvoice,
                         () => _shareInvoice(context, ref, customer, debts),
                       ),
                       _buildActionButton(
                         context,
                         Icons.picture_as_pdf,
                         'تصدير PDF',
                         () =>
                             _exportAccountStatementPdf(context, ref, customer, debts),
                       ),
                       _buildActionButton(
                         context,
                         Icons.receipt_long,
                         'كشف حساب',
                         () => Navigator.push(
                           context,
                           MaterialPageRoute(
                             builder: (_) =>
                                 AccountStatementScreen(customerId: customer.id),
                           ),
                         ),
                       ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: AppDimensions.spacingLg),

            // Customer Activity Timeline
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppDimensions.paddingScreen,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'سجل العمليات',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      TextButton.icon(
                        onPressed: () =>
                            _showAddDebtSheet(context, ref, customer),
                        icon: const Icon(Icons.add),
                        label: const Text(AppStrings.addDebt),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppDimensions.spacingMd),
                  if (activities.isEmpty)
                    const EmptyState(
                      icon: Icons.receipt_long,
                      title: AppStrings.noDebts,
                    )
                  else
                    ...activities.map(
                      (item) => _buildActivityItem(context, ref, item),
                    ),
                ],
              ),
            ),

            const SizedBox(height: AppDimensions.spacingXl),
          ],
        ),
      ),
      bottomNavigationBar: debts.isNotEmpty && debts.any((d) => !d.isPaid)
          ? SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(AppDimensions.paddingScreen),
                child: ElevatedButton(
                  onPressed: () =>
                      _showPaymentSheet(context, ref, customer, debts),
                  child: const Text(AppStrings.payDebt),
                ),
              ),
            )
          : null,
    );
  }

  Widget _buildActionButton(
    BuildContext context,
    IconData icon,
    String label,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.spacingSm),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(AppDimensions.spacingMd),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: Colors.white),
            ),
            const SizedBox(height: AppDimensions.spacingXs),
            Text(
              label,
              style: const TextStyle(color: Colors.white, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActivityItem(
    BuildContext context,
    WidgetRef ref,
    CustomerActivityItem item,
  ) {
    if (item is DebtActivity) {
      return _buildDebtTimelineItem(context, ref, item.debt);
    }
    if (item is PaymentActivity) {
      return _buildPaymentTimelineItem(context, item);
    }
    return const SizedBox.shrink();
  }

  Widget _buildPaymentTimelineItem(
    BuildContext context,
    PaymentActivity activity,
  ) {
    final payment = activity.payment;
    final allDebts = HiveService.getAllDebts();
    Debt? debt;
    try {
      debt = allDebts.firstWhere((d) => d.id == payment.debtId);
    } catch (_) {
      debt = null;
    }
    // A payment is "partial" only if the debt still has a remaining balance after it,
    // meaning this payment alone did not complete the full repayment. Comparing against
    // debt.amount (total) incorrectly marks the final completing payment as partial
    // whenever the customer paid in multiple instalments.
    final isPartial =
        debt != null && !debt.isPaid && payment.amount < debt.amount;

    return Container(
      margin: const EdgeInsets.only(bottom: AppDimensions.spacingMd),
      padding: const EdgeInsets.all(AppDimensions.paddingCard),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
        border: Border.all(color: AppColors.success.withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.check_circle, color: AppColors.success, size: 20),
                  const SizedBox(width: AppDimensions.spacingSm),
                  Text(
                    'تم تسديد ${Formatters.formatCurrency(payment.amount)}',
                    style: Theme.of(
                      context,
                    ).textTheme.titleMedium?.copyWith(color: AppColors.success),
                  ),
                  if (isPartial) ...[
                    const SizedBox(width: AppDimensions.spacingSm),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.warning.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: const Text(
                        'دفعة جزئية',
                        style: TextStyle(
                          fontSize: 11,
                          color: AppColors.warning,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              Text(
                Formatters.formatRelativeDate(payment.createdAt),
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
          if (payment.notes != null && payment.notes!.isNotEmpty) ...[
            const SizedBox(height: AppDimensions.spacingSm),
            Text(
              payment.notes!,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: AppColors.textSecondaryLight,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildDebtTimelineItem(
    BuildContext context,
    WidgetRef ref,
    Debt debt,
  ) {
    final isPayment = debt.isPaid || debt.paidAmount > 0;

    return Container(
      margin: const EdgeInsets.only(bottom: AppDimensions.spacingMd),
      padding: const EdgeInsets.all(AppDimensions.paddingCard),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
        border: Border.all(
          color: isPayment
              ? AppColors.success.withValues(alpha: 0.3)
              : AppColors.error.withValues(alpha: 0.3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(
                    isPayment ? Icons.check_circle : Icons.receipt_long,
                    color: isPayment ? AppColors.success : AppColors.error,
                    size: 20,
                  ),
                  const SizedBox(width: AppDimensions.spacingSm),
                  Text(
                    isPayment
                        ? 'تسديد'
                        : debt.isInstallment
                        ? 'تقسيط: ${debt.productName ?? "غير محدد"}'
                        : 'دين جديد',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ],
              ),
              Text(
                Formatters.formatDate(debt.createdAt),
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
          const SizedBox(height: AppDimensions.spacingSm),
          if (debt.productName != null) ...[
            Text(
              'المنتج: ${debt.productName}',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            Text(
              'الكمية: ${debt.productQuantity}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: AppDimensions.spacingSm),
          ],
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'المبلغ: ${Formatters.formatCurrency(debt.amount)}',
                style: Theme.of(
                  context,
                ).textTheme.titleMedium?.copyWith(color: AppColors.error),
              ),
              if (!debt.isPaid && debt.paidAmount > 0)
                Text(
                  'المسدد: ${Formatters.formatCurrency(debt.paidAmount)}',
                  style: Theme.of(
                    context,
                  ).textTheme.bodySmall?.copyWith(color: AppColors.success),
                ),
            ],
          ),
          if (!debt.isPaid && debt.remainingAmount > 0) ...[
            const SizedBox(height: AppDimensions.spacingSm),
            LinearProgressIndicator(
              value: debt.paidPercentage,
              backgroundColor: AppColors.error.withValues(alpha: 0.2),
              valueColor: const AlwaysStoppedAnimation(AppColors.success),
            ),
            const SizedBox(height: AppDimensions.spacingXs),
            Text(
              'المتبقي: ${Formatters.formatCurrency(debt.remainingAmount)}',
              style: Theme.of(
                context,
              ).textTheme.bodySmall?.copyWith(color: AppColors.accent),
            ),
          ],
          // ── Installment schedule (with checkboxes & status tracking) ───
          if (debt.isInstallment &&
              debt.installmentDates != null &&
              debt.installmentAmounts != null) ...[
            const SizedBox(height: AppDimensions.spacingMd),
            Text(
              'جدول الأقساط',
              style: Theme.of(
                context,
              ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: AppDimensions.spacingSm),
            ...List.generate(debt.installmentDates!.length, (i) {
              final status =
                  (debt.installmentStatuses != null &&
                      i < debt.installmentStatuses!.length)
                  ? debt.installmentStatuses![i]
                  : 'pending';
              final isPaid = status == 'paid';
              final amount = debt.installmentAmounts![i];
              final dueDate = debt.installmentDates![i];
              final now = DateTime.now();
              final isOverdue = !isPaid && dueDate.isBefore(now);

              Color rowColor = Colors.transparent;
              if (isPaid) {
                rowColor = Colors.green.withValues(alpha: 0.08);
              } else if (isOverdue) {
                rowColor = Colors.red.withValues(alpha: 0.08);
              }

              Color statusColor = isPaid
                  ? AppColors.success
                  : isOverdue
                  ? AppColors.error
                  : AppColors.warning;

              String statusLabel = isPaid
                  ? 'مدفوع'
                  : isOverdue
                  ? 'متأخر'
                  : 'معلق';

              return Padding(
                padding: const EdgeInsets.only(bottom: AppDimensions.spacingXs),
                child: Material(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(AppDimensions.radiusSm),
                  clipBehavior: Clip.antiAlias,
                  child: Ink(
                    decoration: BoxDecoration(
                      color: rowColor,
                      borderRadius: BorderRadius.circular(
                        AppDimensions.radiusSm,
                      ),
                      border: Border.all(
                        color: isPaid
                            ? AppColors.success.withValues(alpha: 0.3)
                            : isOverdue
                            ? AppColors.error.withValues(alpha: 0.3)
                            : AppColors.dividerLight,
                        width: 1,
                      ),
                    ),
                    child: ListTile(
                      dense: true,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: AppDimensions.spacingSm,
                        vertical: 2,
                      ),
                      leading: IconButton(
                        icon: Icon(
                          isPaid
                              ? Icons.check_circle
                              : isOverdue
                              ? Icons.circle
                              : Icons.circle_outlined,
                          color: isPaid
                              ? AppColors.success
                              : isOverdue
                              ? AppColors.error
                              : AppColors.textSecondaryLight,
                          size: 22,
                        ),
                        onPressed: () =>
                            _toggleInstallment(context, ref, debt, i, !isPaid),
                        tooltip: isPaid ? 'إلغاء التسديد' : 'تسديد هذا القسط',
                      ),
                      title: Row(
                        children: [
                          Text(
                            'قسط ${i + 1}',
                            style: Theme.of(context).textTheme.bodyMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: isPaid
                                      ? AppColors.success
                                      : isOverdue
                                      ? AppColors.error
                                      : AppColors.textPrimaryLight,
                                ),
                          ),
                          const SizedBox(width: 8),
                          if (isOverdue)
                            Icon(
                              Icons.warning_amber,
                              color: AppColors.error,
                              size: 14,
                            ),
                          const Spacer(),
                          Text(
                            Formatters.formatCurrency(amount),
                            style: Theme.of(context).textTheme.bodyMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: isPaid
                                      ? AppColors.success
                                      : isOverdue
                                      ? AppColors.error
                                      : AppColors.textPrimaryLight,
                                ),
                          ),
                        ],
                      ),
                      subtitle: Row(
                        children: [
                          Icon(
                            Icons.calendar_today,
                            size: 12,
                            color: isOverdue
                                ? AppColors.error
                                : AppColors.textSecondaryLight,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            Formatters.formatDate(dueDate),
                            style: Theme.of(context).textTheme.bodySmall
                                ?.copyWith(
                                  color: isOverdue
                                      ? AppColors.error
                                      : AppColors.textSecondaryLight,
                                ),
                          ),
                          const SizedBox(width: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: statusColor.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              statusLabel,
                              style: Theme.of(context).textTheme.labelSmall
                                  ?.copyWith(
                                    color: statusColor,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }),
          ],
        ],
      ),
    );
  }

  void _toggleInstallment(
    BuildContext context,
    WidgetRef ref,
    Debt debt,
    int index,
    bool markAsPaid,
  ) async {
    if (!markAsPaid) {
      // Ask for confirmation before reverting
      final confirm = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('إلغاء تسديد القسط'),
          content: const Text(
            'هل تريد إلغاء تسديد هذا القسط؟ سيُطرح المبلغ من الرصيد المسدد.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('لا'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              child: const Text('نعم'),
            ),
          ],
        ),
      );
      if (confirm != true) return;
    }

    try {
      await ref
          .read(debtsProvider.notifier)
          .toggleInstallmentPaid(
            debtId: debt.id,
            installmentIndex: index,
            markAsPaid: markAsPaid,
          );

      if (context.mounted) {
        HapticFeedback.lightImpact();
        if (markAsPaid) {
          SuccessPulseOverlay.show(context);
        }
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              markAsPaid ? 'تم تسديد القسط بنجاح' : 'تم إلغاء تسديد القسط',
            ),
            backgroundColor: markAsPaid
                ? AppColors.success
                : Colors.grey.shade700,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('خطأ: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  // ── Print options ─────────────────────────────────────────────────────────
  void _showPrintOptionsBottomSheet(
    BuildContext context,
    WidgetRef ref,
    Customer customer,
    List<Debt> debts,
  ) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppDimensions.paddingScreen),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    margin: const EdgeInsets.only(bottom: 20),
                    decoration: BoxDecoration(
                      color: Colors.grey[300],
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                Text(
                  'خيارات الطباعة',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: AppDimensions.spacingLg),
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppColors.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.receipt_long,
                      color: AppColors.primary,
                    ),
                  ),
                  title: const Text('طباعة الملف الكامل'),
                  subtitle: const Text(
                    'جميع الديون والتسديدات والأقساط مع الرصيد الإجمالي',
                  ),
                  onTap: () {
                    Navigator.pop(ctx);
                    _printFullProfile(context, ref, customer, debts);
                  },
                ),
                const Divider(),
                ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppColors.accent.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.playlist_add_check,
                      color: AppColors.accent,
                    ),
                  ),
                  title: const Text('طباعة عملية محددة'),
                  subtitle: const Text('اختر عملية واحدة أو أكثر للطباعة'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _showSelectOperationsSheet(context, ref, customer, debts);
                  },
                ),
                const SizedBox(height: AppDimensions.spacingMd),
                if (HiveService.getAppSettings().printerType != 'a4') ...[
                  const Divider(),
                  ListTile(
                    leading: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.success.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.bluetooth,
                        color: AppColors.success,
                      ),
                    ),
                    title: const Text('طباعة حرارية'),
                    subtitle: const Text('طباعة الفواتير عبر الطابعة الحرارية'),
                    onTap: () {
                      Navigator.pop(ctx);
                      _printThermalInvoices(context, ref, customer, debts);
                    },
                  ),
                  const SizedBox(height: AppDimensions.spacingMd),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Thermal Printing ──────────────────────────────────────────────────────

  Future<void> _printThermalInvoices(
    BuildContext context,
    WidgetRef ref,
    Customer customer,
    List<Debt> debts,
  ) async {
    final settings = HiveService.getAppSettings();

    // Determine paper width from settings
    final paperWidth = settings.printerType == 'thermal_58mm'
        ? ThermalPaperWidth.mm58
        : ThermalPaperWidth.mm80;

    // Check if printer is connected; auto-connect if we have a saved MAC
    final printerState = ref.read(thermalPrinterProvider);
    if (!printerState.isConnected) {
      if (settings.lastPrinterMac != null) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('جاري الاتصال بالطابعة...')),
          );
        }
        final ok = await ref
            .read(thermalPrinterProvider.notifier)
            .connect(settings.lastPrinterMac!, name: settings.lastPrinterName);
        if (!ok) {
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  ref.read(thermalPrinterProvider).errorMessage ??
                      'فشل الاتصال بالطابعة',
                ),
                backgroundColor: AppColors.error,
              ),
            );
          }
          return;
        }
      } else {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'لا توجد طابعة مقترنة. يرجى اقتران طابعة من الإعدادات.',
              ),
              backgroundColor: AppColors.error,
            ),
          );
        }
        return;
      }
    }

    // Print each debt as a separate thermal invoice
    int successCount = 0;
    int failCount = 0;
    for (final debt in debts) {
      // (البند 3) تأكد من الاتصال قبل كل طبعة. إن لم تكن الطابعة متصلة
      // (انقطع الاتصال بين الفواتير) اعرض حواراً عربياً صريحاً بزر
      // "إعادة المحاولة" بدل الاكتفاء بـ SnackBar.
      if (!ref.read(thermalPrinterProvider).isConnected) {
        if (!context.mounted) return;
        final retry = await showPrinterDisconnectDialog(
          context,
          ref,
          settings,
          message: 'انقطع الاتصال بالطابعة. هل تريد إعادة المحاولة؟',
        );
        if (!context.mounted) return;
        if (!retry) break;
      }

      try {
        final bytes = await ThermalInvoiceRenderer.renderInvoice(
          debt: debt,
          customer: customer,
          settings: settings,
          paperWidth: paperWidth,
        );
        final result = await ref
            .read(thermalPrinterProvider.notifier)
            .printBytes(bytes);
        if (result.success) {
          successCount++;
        } else {
          // انقطع الاتصال أثناء الإرسال — اعرض الحوار قبل المتابعة.
          if (!context.mounted) return;
          final retry = await showPrinterDisconnectDialog(
            context,
            ref,
            settings,
            message: result.message,
          );
          if (!context.mounted) return;
          if (!retry) break;
        }
      } catch (_) {
        failCount++;
      }
    }

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            failCount == 0
                ? 'تمت طباعة $successCount فاتورة بنجاح'
                : 'تمت طباعة $successCount فاتورة، فشل $failCount',
          ),
          backgroundColor: failCount == 0
              ? AppColors.success
              : AppColors.warning,
        ),
      );
    }
  }

  Future<void> _printFullProfile(
    BuildContext context,
    WidgetRef ref,
    Customer customer,
    List<Debt> debts,
  ) async {
    final settings = HiveService.getAppSettings();

    // Thermal ESC/POS path (58mm/80mm): render + send via Bluetooth
    if (settings.printerType == 'thermal_58mm' ||
        settings.printerType == 'thermal_80mm') {
      try {
        final statement = ref.read(accountStatementProvider(customer.id));
        await _printThermalStatement(
          context: context,
          ref: ref,
          customer: customer,
          statement: statement,
          settings: settings,
        );
      } catch (e) {
        appLogger.error('printFullProfile (thermal) failed: $e');
        if (context.mounted) {
          await _showInvoiceErrorDialog(
            context,
            () => _printFullProfile(context, ref, customer, debts),
          );
        }
      }
      return;
    }

    // A4 path: generate PDF and show actions sheet (print/share)
    final pdfService = PdfService();
    try {
      final statement = ref.read(accountStatementProvider(customer.id));
      final file = await pdfService.generateAccountStatement(
        customer: customer,
        statement: statement,
        storeName: settings.storeName,
        storeLogoPath: settings.storeLogoPath,
        storePhone: settings.storePhone,
        printerType: settings.printerType,
      );
      if (context.mounted) {
        _showPdfActionsBottomSheet(context, file, customer.name);
      }
    } catch (e) {
      appLogger.error('printFullProfile (a4) failed: $e');
      if (context.mounted) {
        await _showInvoiceErrorDialog(
          context,
          () => _printFullProfile(context, ref, customer, debts),
        );
      }
    }
  }

  /// Prints full customer profile statement using thermal printer
  Future<void> _printThermalStatement({
    required BuildContext context,
    required WidgetRef ref,
    required Customer customer,
    required AccountStatement statement,
    required AppSettings settings,
  }) async {
    final paperWidth = settings.printerType == 'thermal_58mm'
        ? ThermalPaperWidth.mm58
        : ThermalPaperWidth.mm80;

    // Connect if not already connected (auto-connect to saved MAC)
    final printerState = ref.read(thermalPrinterProvider);
    if (!printerState.isConnected) {
      if (settings.lastPrinterMac != null) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('جاري الاتصال بالطابعة...')),
          );
        }
        final ok = await ref
            .read(thermalPrinterProvider.notifier)
            .connect(settings.lastPrinterMac!, name: settings.lastPrinterName);
        if (!ok) {
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  ref.read(thermalPrinterProvider).errorMessage ??
                      'فشل الاتصال بالطابعة',
                ),
                backgroundColor: AppColors.error,
              ),
            );
          }
          return;
        }
      } else {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'لم يتم اقتران طابعة — يرجى الذهاب للإعدادات أولاً',
              ),
              backgroundColor: AppColors.error,
            ),
          );
        }
        return;
      }
    }

    // Render and print
    if (context.mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('جاري إنشاء الكشف...')));
    }

    try {
      final bytes = await ThermalStatementRenderer.renderStatement(
        statement: statement,
        customer: customer,
        settings: settings,
        paperWidth: paperWidth,
      );

      final result = await ref
          .read(thermalPrinterProvider.notifier)
          .printBytes(bytes);

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result.message),
            backgroundColor: result.success
                ? AppColors.success
                : AppColors.error,
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('خطأ في الطباعة: $e'),
            backgroundColor: AppColors.error,
          ),
        );
      }
    }
  }

  void _showSelectOperationsSheet(
    BuildContext context,
    WidgetRef ref,
    Customer customer,
    List<Debt> debts,
  ) {
    final payments = debts
        .expand((d) => HiveService.getPaymentsByDebt(d.id))
        .toList();
    final allOperations = <Map<String, dynamic>>[];

    for (final debt in debts) {
      allOperations.add({
        'type': 'debt',
        'date': debt.createdAt,
        'amount': debt.amount,
        'label': debt.productName ?? 'دين',
        'id': debt.id,
      });
    }
    for (final payment in payments) {
      final debt = debts.firstWhere(
        (d) => d.id == payment.debtId,
        orElse: () => Debt(
          id: '',
          customerId: '',
          amount: 0,
          userId: '',
          createdAt: DateTime.now(),
        ),
      );
      if (debt.id.isNotEmpty) {
        allOperations.add({
          'type': 'payment',
          'date': payment.createdAt,
          'amount': payment.amount,
          'label': 'تسديد',
          'id': payment.id,
        });
      }
    }
    allOperations.sort(
      (a, b) => (b['date'] as DateTime).compareTo(a['date'] as DateTime),
    );

    final selected = <int>{};

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.8,
            ),
            child: Padding(
              padding: const EdgeInsets.all(AppDimensions.paddingScreen),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      margin: const EdgeInsets.only(bottom: 20),
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  Text(
                    'اختر العمليات للطباعة',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: AppDimensions.spacingMd),
                  Expanded(
                    child: ListView.builder(
                      itemCount: allOperations.length,
                      itemBuilder: (ctx, i) {
                        final op = allOperations[i];
                        final isSelected = selected.contains(i);
                        final isDebt = op['type'] == 'debt';
                        return Card(
                          margin: const EdgeInsets.only(
                            bottom: AppDimensions.spacingSm,
                          ),
                          color: isSelected
                              ? AppColors.primary.withValues(alpha: 0.05)
                              : null,
                          child: Material(
                            type: MaterialType.transparency,
                            child: ListTile(
                              leading: Checkbox(
                                value: isSelected,
                                onChanged: (v) {
                                  setState(() {
                                    if (v == true) {
                                      selected.add(i);
                                    } else {
                                      selected.remove(i);
                                    }
                                  });
                                },
                              ),
                              title: Text(
                                '${isDebt ? 'شراء' : 'تسديد'} — ${Formatters.formatCurrency(op['amount'] as double)}',
                                style: TextStyle(
                                  color: isDebt
                                      ? AppColors.error
                                      : AppColors.success,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              subtitle: Text(
                                '${Formatters.formatDateTime(op['date'] as DateTime)} — ${op['label']}',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                              trailing: Icon(
                                isDebt ? Icons.receipt_long : Icons.payments,
                                color: isDebt
                                    ? AppColors.error
                                    : AppColors.success,
                              ),
                              onTap: () {
                                setState(() {
                                  if (isSelected) {
                                    selected.remove(i);
                                  } else {
                                    selected.add(i);
                                  }
                                });
                              },
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: AppDimensions.spacingMd),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: selected.isEmpty
                          ? null
                          : () {
                              Navigator.pop(ctx);
                              final selectedDebts = <Debt>[];
                              final selectedPayments = <Payment>[];
                              for (final idx in selected) {
                                final op = allOperations[idx];
                                if (op['type'] == 'debt') {
                                  final d = debts.firstWhere(
                                    (d) => d.id == op['id'],
                                  );
                                  selectedDebts.add(d);
                                } else {
                                  final p = payments.firstWhere(
                                    (p) => p.id == op['id'],
                                  );
                                  selectedPayments.add(p);
                                }
                              }
                              _printSelectedOperations(
                                context,
                                ref,
                                customer,
                                selectedDebts,
                                selectedPayments,
                              );
                            },
                      child: Text('طباعة المحدد (${selected.length})'),
                    ),
                  ),
                  const SizedBox(height: AppDimensions.spacingMd),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _printSelectedOperations(
    BuildContext context,
    WidgetRef ref,
    Customer customer,
    List<Debt> selectedDebts,
    List<Payment> selectedPayments,
  ) async {
    final settings = HiveService.getAppSettings();
    final pdfService = PdfService();
    try {
      final file = await pdfService.generateSelectedOperationsInvoice(
        customer: customer,
        selectedDebts: selectedDebts,
        selectedPayments: selectedPayments,
        storeName: settings.storeName,
        storeLogoPath: settings.storeLogoPath,
        storePhone: settings.storePhone,
        printerType: settings.printerType,
      );
      if (context.mounted) {
        _showPdfActionsBottomSheet(context, file, customer.name);
      }
    } catch (e) {
      appLogger.error('printSelectedOperations failed: $e');
      if (context.mounted) {
        await _showInvoiceErrorDialog(
          context,
          () => _printSelectedOperations(
            context,
            ref,
            customer,
            selectedDebts,
            selectedPayments,
          ),
        );
      }
    }
  }

  void _showPdfActionsBottomSheet(
    BuildContext context,
    File file,
    String customerName,
  ) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppDimensions.paddingScreen),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Text(
                'تم توليد الفاتورة',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: AppDimensions.spacingLg),
              ListTile(
                leading: const Icon(Icons.print, color: AppColors.primary),
                title: const Text('طباعة مباشرة'),
                subtitle: const Text('افتح نافذة طباعة Android'),
                onTap: () async {
                  Navigator.pop(ctx);
                  await _printPdfDirectly(context, file, customerName);
                },
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.chat, color: Colors.green),
                title: const Text('مشاركة عبر واتساب'),
                subtitle: const Text('أرسل الفاتورة كملف PDF'),
                onTap: () async {
                  Navigator.pop(ctx);
                  await Share.shareXFiles(
                    [XFile(file.path)],
                    text: 'فاتورة $customerName',
                    subject: 'فاتورة $customerName',
                  );
                },
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.share, color: AppColors.accent),
                title: const Text('مشاركة'),
                subtitle: const Text('افتح قائمة مشاركة Android'),
                onTap: () async {
                  Navigator.pop(ctx);
                  await Share.shareXFiles([
                    XFile(file.path),
                  ], text: 'فاتورة $customerName');
                },
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.download, color: AppColors.secondary),
                title: const Text('حفظ في الهاتف'),
                subtitle: const Text('حفظ في مجلد Downloads'),
                onTap: () async {
                  Navigator.pop(ctx);
                  try {
                    final downloads = Directory('/storage/emulated/0/Download');
                    if (downloads.existsSync()) {
                      final newFile = File(
                        '${downloads.path}/invoice_${customerName}_${DateTime.now().millisecondsSinceEpoch}.pdf',
                      );
                      await file.copy(newFile.path);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('✅ تم الحفظ: ${newFile.path}'),
                            backgroundColor: AppColors.success,
                          ),
                        );
                      }
                    }
                  } catch (e) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('خطأ في الحفظ: $e'),
                          backgroundColor: AppColors.error,
                        ),
                      );
                    }
                  }
                },
              ),
              const SizedBox(height: AppDimensions.spacingMd),
            ],
          ),
        ),
      ),
    );
  }

  /// شبكة أمان دائمة: توليد/طباعة مباشرة عبر نافذة طباعة Android.
  /// عند أي خطأ (بما فيه RangeError) نسجّل الخطأ عبر appLogger ونعرض حواراً
  /// عربياً بلا تفاصيل تقنية مع زر "إعادة المحاولة".
  Future<void> _printPdfDirectly(
    BuildContext context,
    File file,
    String customerName,
  ) async {
    try {
      await Printing.layoutPdf(
        onLayout: (format) => file.readAsBytes(),
        name: 'invoice_$customerName',
      );
    } catch (e) {
      appLogger.error('layoutPdf failed: $e');
      if (context.mounted) {
        await _showInvoiceErrorDialog(
          context,
          () => _printPdfDirectly(context, file, customerName),
        );
      }
    }
  }

  /// حوار عربي موحّد عند فشل توليد/طباعة الفاتورة. لا يعرض أي تفاصيل تقنية،
  /// ويوفّر زر "إعادة المحاولة" لإعادة تنفيذ العملية الفاشلة.
  Future<void> _showInvoiceErrorDialog(
    BuildContext context,
    VoidCallback onRetry,
  ) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تعذّر توليد الفاتورة'),
        content: const Text('تعذّر توليد الفاتورة، حاول مرة أخرى'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              onRetry();
            },
            child: const Text('إعادة المحاولة'),
          ),
        ],
      ),
    );
  }

  void _showPaymentSheet(
    BuildContext context,
    WidgetRef ref,
    Customer customer,
    List<Debt> debts,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => PaymentSheet(
        customer: customer,
        debts: debts.where((d) => !d.isPaid).toList(),
      ),
    );
  }

  void _showAddDebtSheet(
    BuildContext context,
    WidgetRef ref,
    Customer customer,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AddDebtSheet(customer: customer),
    );
  }

  void _showEditCustomerSheet(
    BuildContext context,
    WidgetRef ref,
    Customer customer,
  ) {
    final nameController = TextEditingController(text: customer.name);
    final phoneController = TextEditingController(text: customer.phone ?? '');
    final limitController = TextEditingController(
      text: customer.maxDebtLimit != null
          ? customer.maxDebtLimit!.toStringAsFixed(0)
          : '',
    );

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Container(
          padding: const EdgeInsets.all(AppDimensions.paddingScreen),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'تعديل الزبون',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: AppDimensions.spacingLg),
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: AppStrings.customerName,
                  ),
                ),
                const SizedBox(height: AppDimensions.spacingMd),
                TextField(
                  controller: phoneController,
                  decoration: const InputDecoration(
                    labelText: AppStrings.phoneNumber,
                  ),
                  keyboardType: TextInputType.phone,
                ),
                const SizedBox(height: AppDimensions.spacingMd),
                TextField(
                  controller: limitController,
                  decoration: const InputDecoration(
                    labelText: 'حد الدين الأقصى (اختياري)',
                    prefixIcon: Icon(Icons.warning_amber),
                    hintText: '0',
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: AppDimensions.spacingXl),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      final limitText = limitController.text.replaceAll(
                        RegExp(r'[^\d.]'),
                        '',
                      );
                      final updated = customer.copyWith(
                        name: nameController.text,
                        phone: phoneController.text.isEmpty
                            ? null
                            : phoneController.text,
                        maxDebtLimit: limitText.isEmpty
                            ? null
                            : double.tryParse(limitText),
                        updatedAt: DateTime.now(),
                      );
                      try {
                        await ref
                            .read(customersProvider.notifier)
                            .updateCustomer(updated);
                        if (context.mounted) Navigator.pop(context);
                      } catch (e) {
                        if (context.mounted) {
                          final message = e.toString().replaceFirst(
                            'Exception: ',
                            '',
                          );
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(message),
                              backgroundColor: Colors.red,
                              duration: const Duration(seconds: 4),
                            ),
                          );
                        }
                      }
                    },
                    child: const Text(AppStrings.save),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLimitIndicator(
    BuildContext context,
    double totalDebt,
    double limit,
  ) {
    final ratio = (totalDebt / limit).clamp(0.0, 1.0);
    final percent = (totalDebt / limit).clamp(0.0, double.infinity);
    final color = percent >= 1.0
        ? AppColors.error
        : percent >= 0.7
        ? Colors.orange
        : AppColors.success;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppDimensions.paddingCard),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppDimensions.radiusLg),
      ),
      child: Column(
        children: [
          Text(
            'الرصيد مقابل حد الدين',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: AppDimensions.spacingXs),
          Text(
            '${Formatters.formatCurrencyCompact(totalDebt)} / ${Formatters.formatCurrencyCompact(limit)}',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: AppDimensions.spacingSm),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: ratio,
              minHeight: 8,
              backgroundColor: Colors.grey[300],
              valueColor: AlwaysStoppedAnimation(color),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, WidgetRef ref, Customer customer) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف الزبون'),
        content: Text(
          'هل أنت متأكد من حذف ${customer.name}؟ سيتم إخفاء جميع الديون المرتبطة.\n\nيمكنك استرجاع البيانات لاحقاً من سلة المحذوفات.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(AppStrings.cancel),
          ),
          ElevatedButton(
            onPressed: () {
              ref.read(customersProvider.notifier).deleteCustomer(customer.id);
              Navigator.pop(context);
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            child: const Text(AppStrings.delete),
          ),
        ],
      ),
    );
  }

  Future<void> _makePhoneCall(BuildContext context, String? phone) async {
    if (phone == null || phone.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('لا يوجد رقم هاتف مسجل لهذا الزبون'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }
    final cleanPhone = phone.replaceAll(RegExp(r'[^\d+]'), '');
    final uri = Uri(scheme: 'tel', path: cleanPhone);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'تعذر فتح تطبيق الاتصال، تأكد من وجود تطبيق هاتف على جهازك',
          ),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _pickAndUploadImage(
    BuildContext context,
    WidgetRef ref,
    Customer customer,
  ) async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt),
                title: const Text(AppStrings.takePhoto),
                onTap: () => Navigator.pop(ctx, ImageSource.camera),
              ),
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text(AppStrings.chooseFromGallery),
                onTap: () => Navigator.pop(ctx, ImageSource.gallery),
              ),
            ],
          ),
        ),
      ),
    );
    if (source == null) return;

    final picker = ImagePicker();
    final image = await picker.pickImage(source: source, imageQuality: 70);
    if (image == null) return;

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('جاري رفع الصورة...'),
          duration: Duration(seconds: 1),
        ),
      );
    }

    final url = await ref
        .read(customersProvider.notifier)
        .updateCustomerImage(customer.id, image.path);

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(url != null ? 'تم رفع الصورة بنجاح' : 'فشل رفع الصورة'),
          backgroundColor: url != null ? AppColors.success : AppColors.error,
        ),
      );
    }
  }

  void _sendWhatsApp(
    BuildContext context,
    Customer customer,
    double totalDebt,
  ) async {
    if (customer.phone == null || customer.phone!.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('لا يوجد رقم هاتف مسجل لهذا الزبون'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    final settings = HiveService.getAppSettings();
    final message =
        'السلام عليكم ${customer.name} 🙏\n'
        'نتمنى أنك بخير وعافية.\n\n'
        'نذكرّك بخصوص الحساب المتبقي عندك بـ ${settings.storeName}، المبلغ المتبقي '
        'هو ${Formatters.formatCurrencyDual(totalDebt)}.\n\n'
        'نكون ممنونين إذا تكدر تسدد المبلغ بأقرب وقت يناسبك، وإذا عندك '
        'أي استفسار احنا حاضرين.\n\n'
        'تحياتنا، ${settings.storeName} 🙏';

    final cleanPhone = Formatters.formatPhoneForWhatsApp(customer.phone!);
    final uri = Uri.parse(
      'https://wa.me/$cleanPhone?text=${Uri.encodeComponent(message)}',
    );

    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('تعذر فتح واتساب، تأكد من تثبيت التطبيق'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('خطأ: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _shareInvoice(
    BuildContext context,
    WidgetRef ref,
    Customer customer,
    List<Debt> debts,
  ) async {
    final settings = HiveService.getAppSettings();
    try {
      final pdfService = PdfService();
      final pdfFile = await pdfService.generateInvoice(
        customer: customer,
        debts: debts,
        storeName: settings.storeName,
        storeLogoPath: settings.storeLogoPath,
        storePhone: settings.storePhone,
        printerType: settings.printerType,
      );
      if (!context.mounted) return;
      await Share.shareXFiles([
        XFile(pdfFile.path),
      ], text: 'فاتورة ${customer.name}');
    } catch (e) {
      appLogger.error('shareInvoice failed: $e');
      if (context.mounted) {
        await _showInvoiceErrorDialog(
          context,
          () => _shareInvoice(context, ref, customer, debts),
        );
      }
    }
  }

  Future<void> _exportAccountStatementPdf(
    BuildContext context,
    WidgetRef ref,
    Customer customer,
    List<Debt> debts,
  ) async {
    final settings = HiveService.getAppSettings();
    final pdfService = PdfService();
    try {
      final statement = ref.read(accountStatementProvider(customer.id));
      final file = await pdfService.generateAccountStatement(
        customer: customer,
        statement: statement,
        storeName: settings.storeName,
        storeLogoPath: settings.storeLogoPath,
        storePhone: settings.storePhone,
        printerType: settings.printerType,
      );
      if (context.mounted) {
        _showPdfActionsBottomSheet(context, file, customer.name);
      }
    } catch (e) {
      appLogger.error('exportAccountStatementPdf failed: $e');
      if (context.mounted) {
        await _showInvoiceErrorDialog(
          context,
          () => _exportAccountStatementPdf(context, ref, customer, debts),
        );
      }
    }
  }

  Widget _buildReliabilityBadge(BuildContext context, String customerId) {
    final reliability = HiveService.customerReliability(customerId);
    final badgeColor = HiveService.reliabilityColor(reliability);
    final label = HiveService.reliabilityLabel(reliability);
    final icon = switch (reliability) {
      'red' => Icons.warning_amber,
      'yellow' => Icons.help_outline,
      _ => Icons.verified,
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: badgeColor.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: badgeColor.withValues(alpha: 0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: badgeColor),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              color: badgeColor,
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
