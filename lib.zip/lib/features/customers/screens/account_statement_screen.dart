import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/local/hive_service.dart';
import '../../../data/models/customer.dart';
import '../../../data/models/settings.dart';
import '../../../shared/providers/pdf_service.dart';
import '../../../shared/providers/thermal_invoice_renderer.dart';
import '../../../shared/providers/thermal_printer_service.dart';
import '../../../shared/providers/thermal_statement_renderer.dart';
import '../../../shared/widgets/printer_disconnect_dialog.dart';
import '../providers/statement_provider.dart';

/// A professional customer account statement (كشف حساب) screen.
///
/// Shows all purchases (debt & cash) and payments with a running balance,
/// store name, customer name, summary cards, a transactions table, date-range
/// filtering, and PDF export/share — accessible from the customer profile.
class AccountStatementScreen extends ConsumerStatefulWidget {
  final String customerId;

  const AccountStatementScreen({super.key, required this.customerId});

  @override
  ConsumerState<AccountStatementScreen> createState() =>
      _AccountStatementScreenState();
}

class _AccountStatementScreenState
    extends ConsumerState<AccountStatementScreen> {
  DateTimeRange? _dateRange;
  bool _isExporting = false;

  @override
  Widget build(BuildContext context) {
    final statement = ref.watch(accountStatementProvider(widget.customerId));
    final customers = ref.watch(_customersProvider);
    final customer = customers.firstWhere(
      (c) => c.id == widget.customerId,
      orElse: () => Customer(
        id: '',
        name: '',
        userId: '',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
    );
    final settings = HiveService.getAppSettings();

    // Apply optional date-range filter
    final filtered = _filterByDateRange(statement.entries);

    return Scaffold(
      appBar: AppBar(
        title: const Text('كشف حساب'),
        actions: [
          IconButton(
            icon: const Icon(Icons.print),
            tooltip: 'طباعة',
            onPressed: _isExporting
                ? null
                : () => _printPdf(customer, statement, settings),
          ),
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            tooltip: 'تصدير PDF',
            onPressed: _isExporting
                ? null
                : () => _exportPdf(customer, statement, settings),
          ),
          IconButton(
            icon: const Icon(Icons.share),
            tooltip: 'مشاركة',
            onPressed: _isExporting
                ? null
                : () => _sharePdf(customer, statement, settings),
          ),
        ],
      ),
      body: statement.entries.isEmpty
          ? _buildEmptyState()
          : Column(
              children: [
                // Header: store + customer info
                _buildHeader(customer, settings.storeName, statement),
                // Summary cards
                _buildSummaryCards(statement),
                // Date-range filter
                _buildDateRangeFilter(),
                // Transactions table
                Expanded(child: _buildTransactionsTable(filtered, statement)),
                // Totals footer
                _buildTotalsFooter(statement),
              ],
            ),
      floatingActionButton: _isExporting
          ? const FloatingActionButton(
              onPressed: null,
              child: SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            )
          : null,
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.receipt_long,
            size: 80,
            color: Theme.of(context).hintColor,
          ),
          const SizedBox(height: AppDimensions.spacingMd),
          Text(
            'لا توجد عمليات لعرضها',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: AppDimensions.spacingXs),
          Text(
            'لم يتم تسجيل أي مشتريات أو تسديدات لهذا الزبون بعد.',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).hintColor,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(
    Customer customer,
    String storeName,
    AccountStatement statement,
  ) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppDimensions.paddingScreen),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.primary, AppColors.primary.withValues(alpha: 0.8)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  storeName,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Text(
                'كشف حساب',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Colors.white.withValues(alpha: 0.9),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppDimensions.spacingSm),
          Row(
            children: [
              const Icon(Icons.person, color: Colors.white70, size: 18),
              const SizedBox(width: 6),
              Text(
                customer.name,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (customer.phone != null) ...[
                const SizedBox(width: AppDimensions.spacingMd),
                const Icon(Icons.phone, color: Colors.white70, size: 16),
                const SizedBox(width: 4),
                Text(
                  customer.phone!,
                  style: const TextStyle(color: Colors.white70, fontSize: 14),
                ),
              ],
            ],
          ),
          const SizedBox(height: AppDimensions.spacingXs),
          Text(
            'تاريخ الإصدار: ${Formatters.formatDate(DateTime.now())}',
            style: const TextStyle(color: Colors.white60, fontSize: 12),
          ),
          if (statement.firstDate != null && statement.lastDate != null) ...[
            const SizedBox(height: 2),
            Text(
              'الفترة: ${Formatters.formatDate(statement.firstDate!)} — ${Formatters.formatDate(statement.lastDate!)}',
              style: const TextStyle(color: Colors.white60, fontSize: 12),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSummaryCards(AccountStatement statement) {
    return Padding(
      padding: const EdgeInsets.all(AppDimensions.paddingScreen),
      child: Row(
        children: [
          Expanded(
            child: _buildSummaryCard(
              'إجمالي المشتريات',
              Formatters.formatCurrency(statement.totalPurchases),
              AppColors.primary,
            ),
          ),
          const SizedBox(width: AppDimensions.spacingSm),
          Expanded(
            child: _buildSummaryCard(
              'مشتريات بالدين',
              Formatters.formatCurrency(statement.totalDebtPurchases),
              AppColors.error,
            ),
          ),
          const SizedBox(width: AppDimensions.spacingSm),
          Expanded(
            child: _buildSummaryCard(
              'مشتريات نقدية',
              Formatters.formatCurrency(statement.totalCashPurchases),
              AppColors.success,
            ),
          ),
          const SizedBox(width: AppDimensions.spacingSm),
          Expanded(
            child: _buildSummaryCard(
              'الرصيد الحالي',
              Formatters.formatCurrency(statement.currentBalance),
              statement.currentBalance > 0
                  ? AppColors.error
                  : AppColors.success,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryCard(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimensions.spacingSm,
        vertical: AppDimensions.spacingMd,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Column(
        children: [
          Text(
            label,
            style: Theme.of(
              context,
            ).textTheme.bodySmall?.copyWith(color: Theme.of(context).hintColor),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              value,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDateRangeFilter() {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimensions.paddingScreen,
      ),
      child: Row(
        children: [
          TextButton.icon(
            onPressed: _pickDateRange,
            icon: const Icon(Icons.date_range, size: 20),
            label: Text(
              _dateRange == null
                  ? 'كل الفترات'
                  : '${Formatters.formatDate(_dateRange!.start)} — ${Formatters.formatDate(_dateRange!.end)}',
            ),
          ),
          if (_dateRange != null)
            IconButton(
              icon: const Icon(Icons.clear, size: 20),
              onPressed: () => setState(() => _dateRange = null),
              tooltip: 'إزالة الفلتر',
            ),
          const Spacer(),
          Text(
            'العمليات: ${_filterByDateRange(ref.read(accountStatementProvider(widget.customerId)).entries).length}',
            style: Theme.of(
              context,
            ).textTheme.bodySmall?.copyWith(color: Theme.of(context).hintColor),
          ),
        ],
      ),
    );
  }

  Widget _buildTransactionsTable(
    List<StatementEntry> entries,
    AccountStatement statement,
  ) {
    if (entries.isEmpty) {
      return const Center(child: Text('لا توجد عمليات في هذه الفترة'));
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SingleChildScrollView(
        child: DataTable(
          headingRowColor: WidgetStateProperty.all(
            AppColors.primary.withValues(alpha: 0.08),
          ),
          columnSpacing: 20,
          columns: const [
            DataColumn(label: Text('#'), numeric: true),
            DataColumn(label: Text('التاريخ')),
            DataColumn(label: Text('البيان')),
            DataColumn(label: Text('النوع')),
            DataColumn(label: Text('المبلغ'), numeric: true),
            DataColumn(label: Text('الرصيد'), numeric: true),
          ],
          rows: entries.asMap().entries.map((mapEntry) {
            final idx = entries.length - mapEntry.key; // oldest = 1
            final e = mapEntry.value;
            final isDebt = e.type == StatementEntryType.debt;
            final isPayment = e.type == StatementEntryType.payment;
            final typeColor = isDebt
                ? AppColors.error
                : (isPayment ? AppColors.success : AppColors.primary);

            return DataRow(
              cells: [
                DataCell(Text('$idx')),
                DataCell(Text(Formatters.formatDate(e.date))),
                DataCell(Text(e.description)),
                DataCell(
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: typeColor.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      e.typeLabel,
                      style: TextStyle(
                        color: typeColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                DataCell(
                  Text(
                    Formatters.formatAmount(e.amount),
                    style: TextStyle(
                      color: typeColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                DataCell(
                  Text(
                    Formatters.formatAmount(e.runningBalance),
                    style: TextStyle(
                      color: e.runningBalance > 0
                          ? AppColors.error
                          : AppColors.success,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildTotalsFooter(AccountStatement statement) {
    return Container(
      padding: const EdgeInsets.all(AppDimensions.paddingScreen),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            Expanded(
              child: _buildFooterItem(
                'عدد العمليات',
                '${statement.transactionCount}',
              ),
            ),
            Expanded(
              child: _buildFooterItem(
                'إجمالي المدفوع',
                Formatters.formatCurrency(statement.totalPayments),
                color: AppColors.success,
              ),
            ),
            Expanded(
              child: _buildFooterItem(
                'الرصيد المستحق',
                Formatters.formatCurrency(statement.currentBalance),
                color: statement.currentBalance > 0
                    ? AppColors.error
                    : AppColors.success,
                isBold: true,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooterItem(
    String label,
    String value, {
    Color? color,
    bool isBold = false,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          label,
          style: Theme.of(
            context,
          ).textTheme.bodySmall?.copyWith(color: Theme.of(context).hintColor),
        ),
        const SizedBox(height: 4),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            value,
            style: TextStyle(
              color: color,
              fontWeight: isBold ? FontWeight.bold : FontWeight.w600,
              fontSize: 15,
            ),
          ),
        ),
      ],
    );
  }

  List<StatementEntry> _filterByDateRange(List<StatementEntry> entries) {
    if (_dateRange == null) return entries;
    return entries.where((e) {
      final d = DateTime(e.date.year, e.date.month, e.date.day);
      final start = DateTime(
        _dateRange!.start.year,
        _dateRange!.start.month,
        _dateRange!.start.day,
      );
      final end = DateTime(
        _dateRange!.end.year,
        _dateRange!.end.month,
        _dateRange!.end.day,
      );
      return !d.isBefore(start) && !d.isAfter(end);
    }).toList();
  }

  Future<void> _pickDateRange() async {
    final now = DateTime.now();
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(now.year, now.month, now.day),
      initialDateRange:
          _dateRange ??
          DateTimeRange(
            start: now.subtract(const Duration(days: 30)),
            end: now,
          ),
      helpText: 'اختر الفترة',
    );
    if (picked != null) {
      setState(() => _dateRange = picked);
    }
  }

  Future<void> _exportPdf(
    Customer customer,
    AccountStatement statement,
    AppSettings settings,
  ) async {
    setState(() => _isExporting = true);
    try {
      final pdfService = PdfService();
      final file = await pdfService.generateAccountStatement(
        customer: customer,
        statement: statement,
        storeName: settings.storeName,
        storeLogoPath: settings.storeLogoPath,
        storePhone: settings.storePhone,
        printerType: settings.printerType,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تم تصدير كشف الحساب: ${file.path}')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('حدث خطأ أثناء التصدير: $e')));
      }
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _sharePdf(
    Customer customer,
    AccountStatement statement,
    AppSettings settings,
  ) async {
    setState(() => _isExporting = true);
    try {
      final pdfService = PdfService();
      final file = await pdfService.generateAccountStatement(
        customer: customer,
        statement: statement,
        storeName: settings.storeName,
        storeLogoPath: settings.storeLogoPath,
        storePhone: settings.storePhone,
        printerType: settings.printerType,
      );
      await Share.shareXFiles([
        XFile(file.path),
      ], text: 'كشف حساب ${customer.name}');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('حدث خطأ أثناء المشاركة: $e')));
      }
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _printPdf(
    Customer customer,
    AccountStatement statement,
    AppSettings settings,
  ) async {
    setState(() => _isExporting = true);
    try {
      // Thermal ESC/POS path (58mm/80mm): render + send via Bluetooth.
      if (settings.printerType != 'a4') {
        await _printThermalStatement(
          context,
          ref,
          customer,
          statement,
          settings,
        );
        return;
      }
      // A4 path unchanged — system print dialog.
      final pdfService = PdfService();
      await pdfService.printAccountStatement(
        customer: customer,
        statement: statement,
        storeName: settings.storeName,
        storeLogoPath: settings.storeLogoPath,
        storePhone: settings.storePhone,
        printerType: settings.printerType,
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('حدث خطأ أثناء الطباعة: $e')));
      }
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  // ── Thermal Printing (F1 pattern) ─────────────────────────────────────────

  Future<void> _printThermalStatement(
    BuildContext context,
    WidgetRef ref,
    Customer customer,
    AccountStatement statement,
    AppSettings settings,
  ) async {
    final paperWidth = settings.printerType == 'thermal_58mm'
        ? ThermalPaperWidth.mm58
        : ThermalPaperWidth.mm80;

    // Connect if not already connected (auto-connect to saved MAC).
    final printerState = ref.read(thermalPrinterProvider);
    if (!printerState.isConnected) {
      if (settings.lastPrinterMac != null) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('جاري الاتصال بالطابعة...')),
          );
        }
        final ok = await ref
            .read(thermalPrinterProvider.notifier)
            .connect(
              settings.lastPrinterMac!,
              name: settings.lastPrinterName,
            );
        if (!ok) {
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  ref.read(thermalPrinterProvider).errorMessage ??
                      'فشل الاتصال بالطابعة',
                ),
                backgroundColor: AppColors.error,
              ),
            );
          }
          return;
        }
      } else {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'لا توجد طابعة مقترنة. يرجى اقتران طابعة من الإعدادات.',
              ),
              backgroundColor: AppColors.error,
            ),
          );
        }
        return;
      }
    }

    // Re-check connection before printing; prompt retry if dropped.
    if (!ref.read(thermalPrinterProvider).isConnected) {
      if (!context.mounted) return;
      final retry = await showPrinterDisconnectDialog(
        context,
        ref,
        settings,
        message: 'انقطع الاتصال بالطابعة. هل تريد إعادة المحاولة؟',
      );
      if (!context.mounted || !retry) return;
    }

    try {
      final bytes = await ThermalStatementRenderer.renderStatement(
        statement: statement,
        customer: customer,
        settings: settings,
        paperWidth: paperWidth,
      );
      var result = await ref
          .read(thermalPrinterProvider.notifier)
          .printBytes(bytes);

      // Drop during send → Arabic retry dialog, then one retry.
      if (!result.success && context.mounted) {
        final retry = await showPrinterDisconnectDialog(
          context,
          ref,
          settings,
          message: result.message,
        );
        if (context.mounted && retry) {
          result = await ref
              .read(thermalPrinterProvider.notifier)
              .printBytes(bytes);
        }
      }

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              result.success ? 'تمت طباعة الكشف بنجاح' : result.message,
            ),
            backgroundColor:
                result.success ? AppColors.success : AppColors.error,
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('حدث خطأ أثناء الطباعة: $e'),
            backgroundColor: AppColors.error,
          ),
        );
      }
    }
  }
}

/// Local provider to watch the customers list.
final _customersProvider = Provider<List<Customer>>((ref) {
  return HiveService.getAllCustomers();
});
