import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/constants/strings.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/local/hive_service.dart';
import '../../../data/models/debt.dart';
import '../../../shared/routes/fade_slide_route.dart';
import '../providers/customers_provider.dart';
import '../widgets/customer_card.dart';
import '../widgets/payment_sheet.dart';
import '../../../shared/widgets/loading_indicator.dart';
import 'customer_detail_screen.dart';

class CustomersListScreen extends ConsumerStatefulWidget {
  const CustomersListScreen({super.key});

  @override
  ConsumerState<CustomersListScreen> createState() =>
      _CustomersListScreenState();
}

class _CustomersListScreenState extends ConsumerState<CustomersListScreen> {
  final _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final customers = ref.watch(customersProvider);
    final notifier = ref.read(customersProvider.notifier);
    final unpaidDebtsByCustomer = <String, List<Debt>>{};
    for (final debt in HiveService.getAllDebts()) {
      if (debt.isPaid) continue;
      (unpaidDebtsByCustomer[debt.customerId] ??= []).add(debt);
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.customers),
        actions: [
          PopupMenuButton<CustomerFilter>(
            icon: const Icon(Icons.filter_list),
            onSelected: (filter) => notifier.setFilter(filter),
            itemBuilder: (context) => const [
              PopupMenuItem(
                value: CustomerFilter.all,
                child: ListTile(
                  leading: Icon(Icons.list),
                  title: Text('الكل'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: CustomerFilter.mostIndebted,
                child: ListTile(
                  leading: Icon(Icons.arrow_downward),
                  title: Text('الأكثر ديناً'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: CustomerFilter.top10Debts,
                child: ListTile(
                  leading: Icon(Icons.leaderboard),
                  title: Text('أعلى 10 ديوناً'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: CustomerFilter.alphabetical,
                child: ListTile(
                  leading: Icon(Icons.sort_by_alpha),
                  title: Text('أبجدي'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: CustomerFilter.recent,
                child: ListTile(
                  leading: Icon(Icons.access_time),
                  title: Text('الأحدث'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: CustomerFilter.paid,
                child: ListTile(
                  leading: Icon(Icons.check_circle_outline),
                  title: Text('تم التسديد'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: CustomerFilter.todayPayments,
                child: ListTile(
                  leading: Icon(Icons.today),
                  title: Text('سددوا اليوم'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: CustomerFilter.lateMoreThanMonth,
                child: ListTile(
                  leading: Icon(Icons.warning_amber),
                  title: Text('متأخرون أكثر من شهر'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: CustomerFilter.mostReliable,
                child: ListTile(
                  leading: Icon(Icons.verified_user),
                  title: Text('الأكثر موثوقية'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: CustomerFilter.leastReliable,
                child: ListTile(
                  leading: Icon(Icons.error_outline),
                  title: Text('الأقل موثوقية'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(AppDimensions.paddingScreen),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: '${AppStrings.search}...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          notifier.setSearchQuery('');
                        },
                      )
                    : null,
              ),
              onChanged: (value) => notifier.setSearchQuery(value),
            ),
          ),
          // Swipe hint
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppDimensions.paddingScreen,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.swipe_right,
                      size: 14,
                      color: AppColors.success,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      'تسديد',
                      style: Theme.of(
                        context,
                      ).textTheme.bodySmall?.copyWith(color: AppColors.success),
                    ),
                  ],
                ),
                Row(
                  children: [
                    const Icon(
                      Icons.swipe_left,
                      size: 14,
                      color: Colors.orange,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      'واتساب',
                      style: Theme.of(
                        context,
                      ).textTheme.bodySmall?.copyWith(color: Colors.orange),
                    ),
                  ],
                ),
                Row(
                  children: [
                    const Icon(
                      Icons.touch_app,
                      size: 14,
                      color: AppColors.primary,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      'ضغط مطول',
                      style: Theme.of(
                        context,
                      ).textTheme.bodySmall?.copyWith(color: AppColors.primary),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: AppDimensions.spacingSm),
          Expanded(
            child: customers.isEmpty
                ? EmptyState(
                    icon: Icons.people_outline,
                    title: AppStrings.noCustomers,
                    subtitle: 'اضغط على + لإضافة زبون جديد',
                  )
                : RefreshIndicator(
                    onRefresh: () async {
                      ref.invalidate(customersProvider);
                    },
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppDimensions.paddingScreen,
                      ),
                      itemCount: customers.length,
                      itemBuilder: (context, index) {
                        final customer = customers[index];
                        final unpaidDebts =
                            unpaidDebtsByCustomer[customer.id] ??
                            const <Debt>[];

                        return Dismissible(
                          key: ValueKey(customer.id),
                          direction: DismissDirection.horizontal,
                          // Left background: WhatsApp (orange)
                          background: Container(
                            alignment: Alignment.centerLeft,
                            padding: const EdgeInsets.only(left: 20),
                            decoration: BoxDecoration(
                              color: Colors.green[700],
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: const Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.chat, color: Colors.white, size: 28),
                                SizedBox(height: 4),
                                Text(
                                  'واتساب',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          // Right background: Quick payment (green)
                          secondaryBackground: Container(
                            alignment: Alignment.centerRight,
                            padding: const EdgeInsets.only(right: 20),
                            decoration: BoxDecoration(
                              color: AppColors.primary,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: const Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.payments,
                                  color: Colors.white,
                                  size: 28,
                                ),
                                SizedBox(height: 4),
                                Text(
                                  'تسديد',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          confirmDismiss: (direction) async {
                            if (direction == DismissDirection.endToStart) {
                              // Swipe right → quick payment
                              if (unpaidDebts.isEmpty) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('لا توجد ديون مستحقة'),
                                  ),
                                );
                                return false;
                              }
                              showModalBottomSheet(
                                context: context,
                                isScrollControlled: true,
                                backgroundColor: Colors.transparent,
                                builder: (_) => PaymentSheet(
                                  customer: customer,
                                  debts: unpaidDebts,
                                ),
                              );
                              return false; // Don't dismiss the card
                            } else {
                              // Swipe left → WhatsApp reminder
                              final totalDebt = unpaidDebts.fold<double>(
                                0,
                                (s, d) => s + d.remainingAmount,
                              );
                              _sendWhatsApp(customer, totalDebt);
                              return false; // Don't dismiss the card
                            }
                          },
                          child: GestureDetector(
                            onLongPress: () =>
                                _showLongPressMenu(context, customer, ref),
                            child: CustomerCard(
                              customer: customer,
                              onTap: () => Navigator.push(
                                context,
                                FadeSlideRoute(
                                  page: CustomerDetailScreen(
                                    customerId: customer.id,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  void _sendWhatsApp(customer, double totalDebt) {
    if (customer.phone == null || customer.phone!.toString().trim().isEmpty) {
      return;
    }
    final settings = HiveService.getAppSettings();
    final message =
        'السلام عليكم ${customer.name} 🙏\n'
        'نتمنى أنك بخير وعافية.\n\n'
        'نذكرّك بخصوص الحساب المتبقي عندك بـ ${settings.storeName}، المبلغ المتبقي '
        'هو ${Formatters.formatCurrency(totalDebt)} دينار عراقي.\n\n'
        'نكون ممنونين إذا تكدر تسدد المبلغ بأقرب وقت يناسبك، وإذا عندك '
        'أي استفسار احنا حاضرين.\n\n'
        'تحياتنا، ${settings.storeName} 🙏';
    final cleanPhone = Formatters.formatPhoneForWhatsApp(
      customer.phone.toString(),
    );
    final uri = Uri.parse(
      'https://wa.me/$cleanPhone?text=${Uri.encodeComponent(message)}',
    );
    launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  void _showLongPressMenu(BuildContext context, customer, WidgetRef ref) {
    final unpaidDebts = HiveService.getDebtsByCustomer(
      customer.id,
    ).where((d) => !d.isPaid).toList();
    final totalDebt = unpaidDebts.fold<double>(
      0,
      (s, d) => s + d.remainingAmount,
    );

    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.payments, color: AppColors.primary),
                title: const Text('تسديد دين'),
                onTap: () {
                  Navigator.pop(ctx);
                  if (unpaidDebts.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('لا توجد ديون مستحقة')),
                    );
                    return;
                  }
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (_) =>
                        PaymentSheet(customer: customer, debts: unpaidDebts),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.chat, color: Colors.green),
                title: const Text('تذكير واتساب'),
                onTap: () {
                  Navigator.pop(ctx);
                  _sendWhatsApp(customer, totalDebt);
                },
              ),
              ListTile(
                leading: const Icon(Icons.person, color: AppColors.primary),
                title: const Text('عرض الملف'),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.push(
                    context,
                    FadeSlideRoute(
                      page: CustomerDetailScreen(customerId: customer.id),
                    ),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.delete, color: AppColors.error),
                title: const Text(
                  'حذف الزبون',
                  style: TextStyle(color: AppColors.error),
                ),
                onTap: () {
                  Navigator.pop(ctx);
                  _confirmDelete(context, ref, customer);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context, WidgetRef ref, customer) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الزبون'),
        content: Text(
          'هل أنت متأكد من حذف ${customer.name}؟\nسيتم إخفاء جميع ديونه.\n\nيمكنك استرجاع البيانات لاحقاً من سلة المحذوفات.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              ref.read(customersProvider.notifier).deleteCustomer(customer.id);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('تم حذف ${customer.name}'),
                  backgroundColor: Colors.red,
                ),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
  }
}
