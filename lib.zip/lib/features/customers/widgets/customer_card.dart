import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/models/customer.dart';
import '../providers/customers_provider.dart';
import '../../../shared/widgets/customer_avatar.dart';

class CustomerCard extends ConsumerWidget {
  final Customer customer;
  final VoidCallback onTap;

  const CustomerCard({super.key, required this.customer, required this.onTap});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final totalDebt = ref.watch(customerDebtProvider(customer.id));
    final lastDebt = ref
        .read(customersProvider.notifier)
        .getLastDebt(customer.id);
    final reliabilities = ref.watch(customerReliabilitiesProvider);
    final reliability = reliabilities[customer.id] ?? 'new';

    return GestureDetector(
      onHorizontalDragStart: (_) => HapticFeedback.lightImpact(),
      child: Card(
        margin: const EdgeInsets.only(bottom: AppDimensions.spacingMd),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppDimensions.radiusLg),
          child: Padding(
            padding: const EdgeInsets.all(AppDimensions.paddingCard),
            child: Row(
              children: [
                Hero(
                  tag: 'customer_avatar_${customer.id}',
                  child: CustomerAvatar(
                    name: customer.name,
                    imageUrl: customer.imageUrl,
                    radius: 28,
                    reliability: reliability,
                  ),
                ),
                const SizedBox(width: AppDimensions.spacingMd),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        customer.name,
                        style: Theme.of(context).textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: AppDimensions.spacingXs),
                      Text(
                        lastDebt != null
                            ? 'آخر: ${Formatters.formatRelativeDate(lastDebt.createdAt)}'
                            : 'لا توجد معاملات',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      totalDebt > 0
                          ? Formatters.formatCurrency(totalDebt)
                          : '✓',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: totalDebt > 0
                            ? AppColors.error
                            : AppColors.success,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (totalDebt > 0)
                      Text(
                        'مستحق',
                        style: Theme.of(
                          context,
                        ).textTheme.bodySmall?.copyWith(color: AppColors.error),
                      )
                    else
                      Text(
                        'تم التسديد',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppColors.success,
                        ),
                      ),
                  ],
                ),
                const SizedBox(width: AppDimensions.spacingSm),
                Icon(
                  Icons.chevron_left,
                  color: Theme.of(context).textTheme.bodySmall?.color,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
