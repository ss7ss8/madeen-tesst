import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/constants/strings.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/models/customer.dart';
import '../../../data/models/debt.dart';
import '../providers/debts_provider.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/success_pulse_overlay.dart';

class PaymentSheet extends ConsumerStatefulWidget {
  final Customer customer;
  final List<Debt> debts;

  const PaymentSheet({super.key, required this.customer, required this.debts});

  @override
  ConsumerState<PaymentSheet> createState() => _PaymentSheetState();
}

class _PaymentSheetState extends ConsumerState<PaymentSheet> {
  final _amountController = TextEditingController();
  Debt? _selectedDebt;
  bool _isFullPayment = false;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.debts.isNotEmpty) {
      final unpaid = widget.debts.where((d) => !d.isPaid).toList();
      if (unpaid.isNotEmpty) {
        // Sort by createdAt ascending to get the oldest unpaid debt (FIFO)
        unpaid.sort((a, b) => a.createdAt.compareTo(b.createdAt));
        _selectedDebt = unpaid.first;
      } else {
        _selectedDebt = widget.debts.first;
      }
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final totalDebt = widget.debts.fold<double>(
      0,
      (sum, d) => sum + d.remainingAmount,
    );

    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(AppDimensions.paddingScreen),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  AppStrings.payDebt,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                  tooltip: 'إغلاق',
                ),
              ],
            ),
            const SizedBox(height: AppDimensions.spacingSm),
            Text(
              'الزبون: ${widget.customer.name}',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            Text(
              'الإجمالي المستحق: ${Formatters.formatCurrency(totalDebt)}',
              style: Theme.of(
                context,
              ).textTheme.titleMedium?.copyWith(color: AppColors.error),
            ),
            const SizedBox(height: AppDimensions.spacingLg),

            if (widget.debts.length > 1) ...[
              Text(
                'اختر الدين:',
                style: Theme.of(context).textTheme.titleSmall,
              ),
              const SizedBox(height: AppDimensions.spacingSm),
              ...widget.debts.map(
                (debt) => ListTile(
                  title: Text(debt.productName ?? 'دين عام'),
                  subtitle: Text(
                    '${Formatters.formatCurrency(debt.remainingAmount)} - ${Formatters.formatDate(debt.createdAt)}',
                  ),
                  leading: GestureDetector(
                    onTap: () => setState(() {
                      _selectedDebt = debt;
                      _isFullPayment = true;
                      _amountController.text = debt.remainingAmount
                          .toStringAsFixed(0);
                    }),
                    child: Icon(
                      _selectedDebt?.id == debt.id
                          ? Icons.radio_button_checked
                          : Icons.radio_button_unchecked,
                      color: _selectedDebt?.id == debt.id
                          ? AppColors.primary
                          : Colors.grey,
                    ),
                  ),
                  onTap: () => setState(() {
                    _selectedDebt = debt;
                    _isFullPayment = true;
                    _amountController.text = debt.remainingAmount
                        .toStringAsFixed(0);
                  }),
                ),
              ),
              const SizedBox(height: AppDimensions.spacingMd),
            ],

            // Payment Type Toggle
            Row(
              children: [
                Expanded(
                  child: _buildPaymentTypeButton(
                    context,
                    AppStrings.fullPayment,
                    _isFullPayment,
                    () {
                      setState(() {
                        _isFullPayment = true;
                        if (_selectedDebt != null) {
                          _amountController.text = _selectedDebt!
                              .remainingAmount
                              .toStringAsFixed(0);
                        } else {
                          _amountController.text = totalDebt.toStringAsFixed(0);
                        }
                      });
                    },
                  ),
                ),
                const SizedBox(width: AppDimensions.spacingMd),
                Expanded(
                  child: _buildPaymentTypeButton(
                    context,
                    AppStrings.partialPayment,
                    !_isFullPayment,
                    () {
                      setState(() {
                        _isFullPayment = false;
                        _amountController.clear();
                      });
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppDimensions.spacingLg),

            // Amount Input
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'\d')),
              ],
              decoration: InputDecoration(
                labelText: 'المبلغ',
                prefixIcon: const Icon(Icons.monetization_on),
                suffixText: 'د.ع',
                helperText: _isFullPayment && _selectedDebt != null
                    ? 'الحد الأقصى: ${Formatters.formatCurrency(_selectedDebt!.remainingAmount)}'
                    : null,
              ),
              onChanged: (value) {
                final amount = double.tryParse(value) ?? 0;
                if (_selectedDebt != null &&
                    amount >= _selectedDebt!.remainingAmount) {
                  setState(() => _isFullPayment = true);
                } else if (_isFullPayment) {
                  setState(() => _isFullPayment = false);
                }
              },
            ),
            const SizedBox(height: AppDimensions.spacingXl),

            AppButton(
              text: AppStrings.payDebt,
              isLoading: _isLoading,
              onPressed: _processPayment,
            ),
            const SizedBox(height: AppDimensions.spacingMd),
          ],
        ),
      ),
    );
  }

  Widget _buildPaymentTypeButton(
    BuildContext context,
    String label,
    bool isSelected,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppDimensions.spacingMd,
          vertical: AppDimensions.spacingMd,
        ),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.primary.withValues(alpha: 0.1)
              : Colors.transparent,
          border: Border.all(
            color: isSelected ? AppColors.primary : Colors.grey[300]!,
            width: isSelected ? 2 : 1,
          ),
          borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: isSelected ? AppColors.primary : null,
              fontWeight: isSelected ? FontWeight.bold : null,
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _processPayment() async {
    if (_selectedDebt == null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('يرجى اختيار دين أولاً')));
      return;
    }

    final amount = double.tryParse(_amountController.text);
    if (amount == null || amount <= 0) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('أدخل مبلغ صحيح')));
      return;
    }

    if (amount > _selectedDebt!.remainingAmount) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('المبلغ يتجاوز المتبقي')));
      return;
    }

    setState(() => _isLoading = true);

    try {
      await ref
          .read(debtsProvider.notifier)
          .payDebt(_selectedDebt!.id, amount);

      if (mounted) {
        HapticFeedback.mediumImpact();
        SuccessPulseOverlay.show(context);
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تم تسجيل الدفع بنجاح'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }
}
