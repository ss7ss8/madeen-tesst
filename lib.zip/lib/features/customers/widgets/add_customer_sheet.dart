import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/constants/strings.dart';
import '../../../core/services/contacts_service.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/models/product.dart';
import '../../../data/local/hive_service.dart';
import '../providers/customers_provider.dart';
import '../providers/debts_provider.dart';
import '../../installments/providers/installments_provider.dart';
import '../../dashboard/providers/dashboard_provider.dart';
import '../../reports/providers/reports_provider.dart';
import '../../inventory/providers/inventory_provider.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/barcode_scanner_sheet.dart';

enum TransactionType { cash, debt, installment }

class AddCustomerSheet extends ConsumerStatefulWidget {
  const AddCustomerSheet({super.key});

  @override
  ConsumerState<AddCustomerSheet> createState() => _AddCustomerSheetState();
}

class _AddCustomerSheetState extends ConsumerState<AddCustomerSheet> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _amountController = TextEditingController();
  final _productNameController = TextEditingController();
  final _installmentCountController = TextEditingController(text: '6');
  Product? _selectedProduct;
  int _productQuantity = 1;
  bool _isLoading = false;

  TransactionType _transactionType = TransactionType.debt;
  int _installmentCount = 6;
  String _interval = 'monthly';
  DateTime _startDate = DateTime.now();

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _amountController.dispose();
    _productNameController.dispose();
    _installmentCountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final products = ref.watch(productsProvider);
    final isInstallment = _transactionType == TransactionType.installment;

    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(AppDimensions.paddingScreen),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    AppStrings.addCustomer,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                    tooltip: 'إغلاق',
                  ),
                ],
              ),
              const SizedBox(height: AppDimensions.spacingLg),

              // Transaction type selector
              SizedBox(
                width: double.infinity,
                child: SegmentedButton<TransactionType>(
                  segments: const [
                    ButtonSegment(
                      value: TransactionType.cash,
                      label: Text('نقدي'),
                      icon: Icon(Icons.payments),
                    ),
                    ButtonSegment(
                      value: TransactionType.debt,
                      label: Text('دين'),
                      icon: Icon(Icons.account_balance_wallet),
                    ),
                    ButtonSegment(
                      value: TransactionType.installment,
                      label: Text('تقسيط'),
                      icon: Icon(Icons.receipt_long),
                    ),
                  ],
                  selected: {_transactionType},
                  onSelectionChanged: (selected) {
                    setState(() => _transactionType = selected.first);
                  },
                  style: ButtonStyle(
                    visualDensity: VisualDensity.compact,
                    textStyle: WidgetStateProperty.all(
                      const TextStyle(fontSize: 12),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: AppDimensions.spacingMd),

              Row(
                children: [
                  Expanded(
                    child: AppTextField(
                      controller: _nameController,
                      label: AppStrings.customerName,
                      hint: 'أدخل اسم الزبون',
                      prefixIcon: Icons.person,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return AppStrings.required;
                        }
                         return null;
                      },
                    ),
                  ),
                  const SizedBox(width: AppDimensions.spacingSm),
                  IconButton(
                    icon: const Icon(Icons.contact_page_outlined),
                    tooltip: 'استيراد من جهات الاتصال',
                    onPressed: _importContact,
                  ),
                ],
              ),
              const SizedBox(height: AppDimensions.spacingMd),

              AppTextField(
                controller: _phoneController,
                label: '${AppStrings.phoneNumber} (اختياري)',
                hint: '0770 123 4567',
                prefixIcon: Icons.phone,
                keyboardType: TextInputType.phone,
                textDirection: TextDirection.ltr,
                textAlign: TextAlign.left,
              ),
              const SizedBox(height: AppDimensions.spacingMd),

              AppTextField(
                controller: _amountController,
                label: isInstallment ? 'المبلغ الإجمالي *' : 'المبلغ (اختياري)',
                hint: '0',
                prefixIcon: Icons.monetization_on,
                keyboardType: TextInputType.number,
                validator: isInstallment
                    ? (value) {
                        if (value == null || value.isEmpty) {
                          return 'أدخل المبلغ';
                        }
                        final amount = double.tryParse(value);
                        if (amount == null || amount <= 0) {
                          return 'المبلغ غير صحيح';
                        }
                        return null;
                      }
                    : null,
              ),
              const SizedBox(height: AppDimensions.spacingMd),

              AppTextField(
                controller: _productNameController,
                label: 'السلعة (اختياري)',
                hint: 'أدخل اسم السلعة أو المنتج',
                prefixIcon: Icons.shopping_bag,
              ),
              const SizedBox(height: AppDimensions.spacingMd),

               // Product Selection
               DropdownButtonFormField<Product>(
                 isExpanded: true,
                 decoration: InputDecoration(
                   labelText: '${AppStrings.product} (اختياري)',
                   prefixIcon: const Icon(Icons.inventory),
                   suffixIcon: IconButton(
                     icon: const Icon(Icons.qr_code_scanner),
                     tooltip: 'مسح الباركود',
                     onPressed: _scanBarcode,
                   ),
                 ),
                 initialValue: _selectedProduct,
                 items: products.map((product) {
                   final isOutOfStock = product.quantity <= 0;
                   return DropdownMenuItem(
                     value: product,
                     enabled: !isOutOfStock,
                     child: Text(
                       isOutOfStock
                           ? '${product.name} - نفذ من المخزون'
                           : '${product.name} - ${product.quantity} متوفر',
                       style: TextStyle(
                         color: isOutOfStock ? Colors.grey : null,
                       ),
                     ),
                   );
                 }).toList(),
                 onChanged: (product) {
                   if (product == null || product.quantity <= 0) return;
                   setState(() {
                     _selectedProduct = product;
                     _productQuantity = 1;
                     final amount = product.salePrice * _productQuantity;
                     _amountController.text = amount.toStringAsFixed(0);
                     _productNameController.text = product.name;
                   });
                 },
               ),

              if (_selectedProduct != null) ...[
                Center(
                  child: _selectedProduct!.imageUrl != null
                      ? _buildProductImage(_selectedProduct!.imageUrl!)
                      : const Icon(Icons.inventory, size: 48, color: Colors.grey),
                ),
                const SizedBox(height: AppDimensions.spacingMd),
                Row(
                  children: [
                    Text(
                      'الكمية:',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    const SizedBox(width: AppDimensions.spacingMd),
                    IconButton(
                      onPressed: _productQuantity > 1
                          ? () => _updateQuantity(_productQuantity - 1)
                          : null,
                      icon: const Icon(Icons.remove_circle_outline),
                    ),
                    Text(
                      _productQuantity.toString(),
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    IconButton(
                      onPressed: _productQuantity < _selectedProduct!.quantity
                          ? () => _updateQuantity(_productQuantity + 1)
                          : null,
                      icon: const Icon(Icons.add_circle_outline),
                    ),
                    Expanded(
                      child: Text(
                        'المجموع: ${(_selectedProduct!.salePrice * _productQuantity).toStringAsFixed(0)} د.ع',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        textAlign: TextAlign.end,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],

              // Installment-specific fields
              if (isInstallment) ...[
                const SizedBox(height: AppDimensions.spacingMd),
                TextFormField(
                  controller: _installmentCountController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'عدد الأقساط *',
                    prefixIcon: Icon(Icons.numbers),
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    final count = int.tryParse(value);
                    if (count != null && count > 0) {
                      setState(() => _installmentCount = count);
                    }
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'أدخل عدد الأقساط';
                    }
                    final count = int.tryParse(value);
                    if (count == null || count < 2) return 'الحد الأدنى قسطين';
                    return null;
                  },
                ),
                const SizedBox(height: AppDimensions.spacingMd),

                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'فترة السداد',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: AppDimensions.spacingSm),
                    Row(
                      children: [
                        _intervalChip('weekly', 'أسبوعي'),
                        const SizedBox(width: AppDimensions.spacingSm),
                        _intervalChip('monthly', 'شهري'),
                        const SizedBox(width: AppDimensions.spacingSm),
                        _intervalChip('quarterly', 'ربع سنوي'),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: AppDimensions.spacingMd),

                ListTile(
                  leading: const Icon(Icons.calendar_today),
                  title: const Text('تاريخ بداية السداد'),
                  subtitle: Text(Formatters.formatDate(_startDate)),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppDimensions.radiusSm),
                    side: const BorderSide(color: AppColors.dividerLight),
                  ),
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: _startDate,
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (picked != null) {
                      setState(() => _startDate = picked);
                    }
                  },
                ),
              ],

              const SizedBox(height: AppDimensions.spacingXl),

              AppButton(
                text: AppStrings.save,
                isLoading: _isLoading,
                onPressed: _saveCustomer,
              ),

              const SizedBox(height: AppDimensions.spacingMd),
            ],
          ),
        ),
      ),
    );
  }

  Widget _intervalChip(String value, String label) {
    final isSelected = _interval == value;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _interval = value),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected
                ? AppColors.primary.withValues(alpha: 0.15)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(AppDimensions.radiusSm),
            border: Border.all(
              color: isSelected ? AppColors.primary : AppColors.dividerLight,
              width: isSelected ? 2 : 1,
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              color: isSelected
                  ? AppColors.primary
                  : AppColors.textSecondaryLight,
            ),
          ),
        ),
      ),
    );
  }

  List<DateTime> _generateDates() {
    final dates = <DateTime>[];
    for (int i = 0; i < _installmentCount; i++) {
      switch (_interval) {
        case 'weekly':
          dates.add(_startDate.add(Duration(days: 7 * i)));
          break;
        case 'monthly':
          dates.add(
            DateTime(_startDate.year, _startDate.month + i, _startDate.day),
          );
          break;
        case 'quarterly':
          dates.add(
            DateTime(
              _startDate.year,
              _startDate.month + (i * 3),
              _startDate.day,
            ),
          );
          break;
      }
    }
    return dates;
  }

  Future<void> _importContact() async {
    final contact = await ContactsService.pickContact();
    if (contact == null || !mounted) return;
    final firstName = contact.name?.first;
    final displayName = contact.displayName ?? firstName ?? '';
    if (displayName.isNotEmpty) {
      _nameController.text = displayName;
    }
    if (contact.phones.isNotEmpty) {
      _phoneController.text = contact.phones.first.number;
    }
  }

  void _updateQuantity(int newQuantity) {
    setState(() {
      _productQuantity = newQuantity;
      if (_selectedProduct != null) {
        final amount = _selectedProduct!.salePrice * _productQuantity;
        _amountController.text = amount.toStringAsFixed(0);
      }
    });
  }

  Future<void> _scanBarcode() async {
    final scanned = await showBarcodeScannerSheet(context);
    if (scanned == null || !mounted) return;

    final product = HiveService.getProductByBarcode(scanned);
    if (product == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('لم يُعثر على منتج بهذا الباركود'),
            backgroundColor: Colors.red,
          ),
        );
      }
      return;
    }

    if (product.quantity <= 0) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('هذا المنتج نفذ من المخزون'),
            backgroundColor: Colors.red,
          ),
        );
      }
      return;
    }

    setState(() {
      _selectedProduct = product;
      _productQuantity = 1;
      _amountController.text = product.salePrice.toStringAsFixed(0);
      _productNameController.text = product.name;
    });
  }

  Widget _buildProductImage(String imageUrl) {
    final uri = Uri.tryParse(imageUrl);
    final isNetwork =
        uri != null && uri.hasScheme && (uri.scheme == 'http' || uri.scheme == 'https');

    if (isNetwork) {
      return CachedNetworkImage(
        imageUrl: imageUrl,
        width: 80,
        height: 80,
        fit: BoxFit.cover,
        placeholder: (context, url) => const SizedBox(
          width: 80,
          height: 80,
          child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
        ),
        errorWidget: (context, url, error) =>
            const Icon(Icons.broken_image, size: 48, color: Colors.grey),
      );
    }

    if (imageUrl.startsWith('file://')) {
      final path = imageUrl.replaceFirst('file://', '');
      return Image.file(
        File(path),
        width: 80,
        height: 80,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) =>
            const Icon(Icons.broken_image, size: 48, color: Colors.grey),
      );
    }

    return Image.file(
      File(imageUrl),
      width: 80,
      height: 80,
      fit: BoxFit.cover,
      errorBuilder: (context, error, stackTrace) =>
          const Icon(Icons.broken_image, size: 48, color: Colors.grey),
    );
  }

  Future<void> _saveCustomer() async {
    if (!_formKey.currentState!.validate()) return;

    // Defense: reject out-of-stock or insufficient quantity
    if (_selectedProduct != null) {
      if (_selectedProduct!.quantity <= 0) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('هذا المنتج نفذ من المخزون، يرجى اختيار منتج آخر'),
              backgroundColor: Colors.red,
            ),
          );
        }
        setState(() => _isLoading = false);
        return;
      }
      if (_productQuantity > _selectedProduct!.quantity) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'الكمية المطلوبة ($_productQuantity) تتجاوز المتوفر (${_selectedProduct!.quantity})',
              ),
              backgroundColor: Colors.red,
            ),
          );
        }
        setState(() => _isLoading = false);
        return;
      }
    }

    setState(() => _isLoading = true);

    try {
      final amount = double.tryParse(
        _amountController.text.replaceAll(RegExp(r'[^\d]'), ''),
      );

      // Save customer first (no debt)
      final customerId = await ref
          .read(customersProvider.notifier)
          .addCustomer(
            name: _nameController.text,
            phone: _phoneController.text.isEmpty ? null : _phoneController.text,
            initialDebt: null,
            productId: null,
            productName: null,
            productQuantity: 1,
          );

      // Create transaction based on type
      if (amount != null && amount > 0) {
        if (_transactionType == TransactionType.cash) {
          await ref
              .read(debtsProvider.notifier)
              .addDebt(
                customerId: customerId,
                amount: amount,
                productId: _selectedProduct?.id,
                productName: _productNameController.text.isNotEmpty
                    ? _productNameController.text
                    : _selectedProduct?.name,
                productQuantity: _productQuantity,
                isCashSale: true,
              );
        } else if (_transactionType == TransactionType.debt) {
          await ref
              .read(debtsProvider.notifier)
              .addDebt(
                customerId: customerId,
                amount: amount,
                productId: _selectedProduct?.id,
                productName: _productNameController.text.isNotEmpty
                    ? _productNameController.text
                    : _selectedProduct?.name,
                productQuantity: _productQuantity,
              );
        } else if (_transactionType == TransactionType.installment) {
          final totalAmount = double.tryParse(
            _amountController.text.replaceAll(RegExp(r'[^\d.]'), ''),
          ) ?? 0.0;
          if (totalAmount <= 0) {
            throw Exception('Please enter a valid amount');
          }
          final installmentAmount = totalAmount / _installmentCount;
          final dates = _generateDates();
          final amounts = List.generate(
            _installmentCount,
            (_) => installmentAmount,
          );

          await ref
              .read(debtsProvider.notifier)
              .addDebt(
                customerId: customerId,
                amount: totalAmount,
                productId: _selectedProduct?.id,
                productName: _productNameController.text.isNotEmpty
                    ? _productNameController.text
                    : _selectedProduct?.name,
                productQuantity: _productQuantity,
                isInstallment: true,
                installmentCount: _installmentCount,
                installmentDates: dates,
                installmentAmounts: amounts,
              );
        }
      }

      // Invalidate providers to refresh data
      ref.invalidate(installmentsProvider);
      ref.invalidate(customersProvider);
      ref.invalidate(dashboardStatsProvider);
      ref.invalidate(reportDataProvider);

      // Close sheet first
      if (mounted) {
        Navigator.pop(context);
      }

      if (mounted) {
        HapticFeedback.lightImpact();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(AppStrings.successSaved),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        final message = e.toString()
            .replaceFirst('Exception:', '')
            .replaceFirst('FormatException:', 'Input error:');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(message),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }
}
