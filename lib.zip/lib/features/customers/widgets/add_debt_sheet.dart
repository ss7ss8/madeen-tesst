import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/dimensions.dart';
import '../../../core/constants/strings.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/services/notification_service.dart';
import '../../../data/models/customer.dart';
import '../../../data/models/product.dart';
import '../../../data/local/hive_service.dart';
import '../providers/debts_provider.dart';
import '../../inventory/providers/inventory_provider.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/barcode_scanner_sheet.dart';

class AddDebtSheet extends ConsumerStatefulWidget {
  final Customer customer;

  const AddDebtSheet({super.key, required this.customer});

  @override
  ConsumerState<AddDebtSheet> createState() => _AddDebtSheetState();
}

class _AddDebtSheetState extends ConsumerState<AddDebtSheet> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _productNameController = TextEditingController();
  final _notesController = TextEditingController();
  Product? _selectedProduct;
  int _productQuantity = 1;
  bool _isLoading = false;
  String? _limitWarning;
  String? _reliabilityWarning;

  // Installment fields
  bool _isInstallment = false;
  int _installmentCount = 2;
  bool _isCashSale = false;

  double get _currentTotalDebt {
    final debts = HiveService.getDebtsByCustomer(widget.customer.id);
    return debts.fold<double>(0, (sum, d) => sum + d.remainingAmount);
  }

  void _updateLimitWarning() {
    if (_isCashSale) {
      setState(() => _limitWarning = null);
      return;
    }
    final limit = widget.customer.maxDebtLimit;
    if (limit == null || limit <= 0) {
      setState(() => _limitWarning = null);
      return;
    }
    final newAmount = double.tryParse(
      _amountController.text.replaceAll(RegExp(r'[^\d.]'), ''),
    );
    if (newAmount == null || newAmount <= 0) {
      setState(() => _limitWarning = null);
      return;
    }
    final projectedTotal = _currentTotalDebt + newAmount;
    if (projectedTotal > limit) {
      setState(() {
        _limitWarning =
            'تنبيه: هذا الدين سيجعل رصيد الزبون يتجاوز الحد الأقصى المحدد (${Formatters.formatCurrency(limit)})';
      });
    } else {
      setState(() => _limitWarning = null);
    }
  }

  @override
  void initState() {
    super.initState();
    final rel = HiveService.customerReliability(widget.customer.id);
    if (rel == 'red') {
      _reliabilityWarning =
          'تنبيه: هذا الزبون يحتاج متابعة بناءً على سجل تسديده السابق';
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    _productNameController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final products = ref.watch(productsProvider);

    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(AppDimensions.paddingScreen),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _isCashSale ? 'عملية بيع نقدي' : AppStrings.addDebt,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                    tooltip: 'إغلاق',
                  ),
                ],
              ),
              const SizedBox(height: AppDimensions.spacingSm),
              Text(
                'الزبون: ${widget.customer.name}',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: AppDimensions.spacingLg),

              Center(
                child: SegmentedButton<bool>(
                  segments: const <ButtonSegment<bool>>[
                    ButtonSegment<bool>(
                      value: false,
                      label: Text('بيع بالآجل'),
                      icon: Icon(Icons.money_off),
                    ),
                    ButtonSegment<bool>(
                      value: true,
                      label: Text('بيع نقدي'),
                      icon: Icon(Icons.attach_money),
                    ),
                  ],
                  selected: <bool>{_isCashSale},
                  onSelectionChanged: (Set<bool> newSelection) {
                    setState(() {
                      _isCashSale = newSelection.first;
                      if (_isCashSale) {
                        _isInstallment = false;
                      }
                      _updateLimitWarning();
                    });
                  },
                ),
              ),
              const SizedBox(height: AppDimensions.spacingLg),

              DropdownButtonFormField<Product>(
                decoration: InputDecoration(
                  labelText: '${AppStrings.product} (اختياري)',
                  prefixIcon: const Icon(Icons.inventory),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.qr_code_scanner),
                    tooltip: 'مسح الباركود',
                    onPressed: _scanBarcode,
                  ),
                ),
                initialValue: _selectedProduct,
                items: products.map((product) {
                  final isOutOfStock = product.quantity <= 0;
                  return DropdownMenuItem(
                    value: product,
                    enabled: !isOutOfStock,
                    child: Text(
                      isOutOfStock
                          ? '${product.name} - نفذ من المخزون'
                          : '${product.name} - ${product.quantity} متوفر',
                      style: TextStyle(
                        color: isOutOfStock ? Colors.grey : null,
                      ),
                    ),
                  );
                }).toList(),
                onChanged: (product) {
                  if (product == null || product.quantity <= 0) return;
                  setState(() {
                    _selectedProduct = product;
                    _productQuantity = 1;
                    _amountController.text = product.salePrice
                        .toStringAsFixed(0);
                    _productNameController.text = product.name;
                  });
                },
              ),
              const SizedBox(height: AppDimensions.spacingMd),

              if (_selectedProduct != null) ...[
                Center(
                  child: _selectedProduct!.imageUrl != null
                      ? _buildProductImage(_selectedProduct!.imageUrl!)
                      : const Icon(Icons.inventory, size: 48, color: Colors.grey),
                ),
                const SizedBox(height: AppDimensions.spacingMd),
                Row(
                  children: [
                    Text(
                      'الكمية:',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    const SizedBox(width: AppDimensions.spacingMd),
                    IconButton(
                      onPressed: _productQuantity > 1
                          ? () => _updateQuantity(_productQuantity - 1)
                          : null,
                      icon: const Icon(Icons.remove_circle_outline),
                    ),
                    Text(
                      _productQuantity.toString(),
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    IconButton(
                      onPressed: _productQuantity < _selectedProduct!.quantity
                          ? () => _updateQuantity(_productQuantity + 1)
                          : null,
                      icon: const Icon(Icons.add_circle_outline),
                    ),
                  ],
                ),
                const SizedBox(height: AppDimensions.spacingMd),
              ],

              AppTextField(
                controller: _amountController,
                label: AppStrings.debtAmount,
                hint: '0',
                prefixIcon: Icons.monetization_on,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'\d')),
                ],
                onChanged: (_) => _updateLimitWarning(),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return AppStrings.required;
                  }
                  final amount = double.tryParse(
                    value.replaceAll(RegExp(r'[^\d]'), ''),
                  );
                  if (amount == null || amount <= 0) {
                    return AppStrings.invalidAmount;
                  }
                  return null;
                },
              ),
              const SizedBox(height: AppDimensions.spacingMd),

              AppTextField(
                controller: _productNameController,
                label: 'السلعة (اختياري)',
                hint: 'أدخل اسم السلعة أو المنتج',
                prefixIcon: Icons.shopping_bag,
              ),
              const SizedBox(height: AppDimensions.spacingMd),

              AppTextField(
                controller: _notesController,
                label: 'ملاحظات (اختياري)',
                hint: 'أضف ملاحظات...',
                prefixIcon: Icons.note,
                maxLines: 2,
              ),
              const SizedBox(height: AppDimensions.spacingMd),

              // ── Installment Toggle ─────────────────────────────────────
              if (!_isCashSale) ...[
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  secondary: const Icon(Icons.calendar_month),
                  title: const Text('تقسيط'),
                  subtitle: const Text('تقسيم المبلغ على دفعات شهرية'),
                  value: _isInstallment,
                  onChanged: (v) => setState(() => _isInstallment = v),
                ),

                if (_isInstallment) ...[
                  const SizedBox(height: AppDimensions.spacingSm),
                  Row(
                    children: [
                      const Text('عدد الأقساط:'),
                      const SizedBox(width: AppDimensions.spacingMd),
                      IconButton(
                        icon: const Icon(Icons.remove_circle_outline),
                        onPressed: _installmentCount > 2
                            ? () => setState(() => _installmentCount--)
                            : null,
                      ),
                      Text(
                        '$_installmentCount',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      IconButton(
                        icon: const Icon(Icons.add_circle_outline),
                        onPressed: _installmentCount < 24
                            ? () => setState(() => _installmentCount++)
                            : null,
                      ),
                      const Spacer(),
                      // Preview installment amount
                      Builder(
                        builder: (context) {
                          final amt =
                              double.tryParse(
                                _amountController.text.replaceAll(
                                  RegExp(r'[^\d.]'),
                                  '',
                                ),
                              ) ??
                              0;
                          if (amt <= 0) return const SizedBox.shrink();
                          final perInstallment = amt / _installmentCount;
                          return Text(
                            '${perInstallment.toStringAsFixed(0)} د.ع / قسط',
                            style: Theme.of(context).textTheme.bodySmall
                                ?.copyWith(
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                          );
                        },
                      ),
                    ],
                  ),
                ],
              ],

              if (!_isCashSale && _reliabilityWarning != null) ...[
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(AppDimensions.paddingCard),
                  margin: const EdgeInsets.only(bottom: AppDimensions.spacingMd),
                  decoration: BoxDecoration(
                    color: AppColors.error.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(AppDimensions.radiusSm),
                    border: Border.all(
                      color: AppColors.error.withValues(alpha: 0.5),
                    ),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline, color: AppColors.error, size: 20),
                      const SizedBox(width: AppDimensions.spacingSm),
                      Expanded(
                        child: Text(
                          _reliabilityWarning!,
                          style: const TextStyle(
                            color: AppColors.error,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],

              if (!_isCashSale && _limitWarning != null) ...[
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(AppDimensions.paddingCard),
                  margin: const EdgeInsets.only(bottom: AppDimensions.spacingMd),
                  decoration: BoxDecoration(
                    color: Colors.orange.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(AppDimensions.radiusSm),
                    border: Border.all(
                      color: Colors.orange.withValues(alpha: 0.5),
                    ),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.warning_amber, color: Colors.orange, size: 20),
                      const SizedBox(width: AppDimensions.spacingSm),
                      Expanded(
                        child: Text(
                          _limitWarning!,
                          style: const TextStyle(
                            color: Colors.orange,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],

              const SizedBox(height: AppDimensions.spacingXl),

              AppButton(
                text: AppStrings.save,
                isLoading: _isLoading,
                onPressed: _saveDebt,
              ),
              const SizedBox(height: AppDimensions.spacingMd),
            ],
          ),
        ),
      ),
    );
  }

  void _updateQuantity(int newQuantity) {
    setState(() {
      _productQuantity = newQuantity;
      if (_selectedProduct != null) {
        final amount = _selectedProduct!.salePrice * _productQuantity;
        _amountController.text = amount.toStringAsFixed(0);
      }
    });
    _updateLimitWarning();
  }

  DateTime _addMonths(DateTime from, int months) {
    final year = from.year + (from.month + months - 1) ~/ 12;
    final month = (from.month + months - 1) % 12 + 1;
    final lastDay = DateTime(year, month + 1, 0).day;
    final day = from.day > lastDay ? lastDay : from.day;
    return DateTime(year, month, day);
  }

  Future<void> _scanBarcode() async {
    final scanned = await showBarcodeScannerSheet(context);
    if (scanned == null || !mounted) return;

    final product = HiveService.getProductByBarcode(scanned);
    if (product == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('لم يُعثر على منتج بهذا الباركود'),
            backgroundColor: Colors.red,
          ),
        );
      }
      return;
    }

    if (product.quantity <= 0) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('هذا المنتج نفذ من المخزون'),
            backgroundColor: Colors.red,
          ),
        );
      }
      return;
    }

    setState(() {
      _selectedProduct = product;
      _productQuantity = 1;
      _amountController.text = product.salePrice.toStringAsFixed(0);
      _productNameController.text = product.name;
    });
  }

  Widget _buildProductImage(String imageUrl) {
    final uri = Uri.tryParse(imageUrl);
    final isNetwork =
        uri != null && uri.hasScheme && (uri.scheme == 'http' || uri.scheme == 'https');

    if (isNetwork) {
      return CachedNetworkImage(
        imageUrl: imageUrl,
        width: 80,
        height: 80,
        fit: BoxFit.cover,
        placeholder: (context, url) => const SizedBox(
          width: 80,
          height: 80,
          child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
        ),
        errorWidget: (context, url, error) =>
            const Icon(Icons.broken_image, size: 48, color: Colors.grey),
      );
    }

    if (imageUrl.startsWith('file://')) {
      final path = imageUrl.replaceFirst('file://', '');
      return Image.file(
        File(path),
        width: 80,
        height: 80,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) =>
            const Icon(Icons.broken_image, size: 48, color: Colors.grey),
      );
    }

    return Image.file(
      File(imageUrl),
      width: 80,
      height: 80,
      fit: BoxFit.cover,
      errorBuilder: (context, error, stackTrace) =>
          const Icon(Icons.broken_image, size: 48, color: Colors.grey),
    );
  }

  Future<void> _saveDebt() async {
    if (!_formKey.currentState!.validate()) return;

    // Defense: reject out-of-stock or insufficient quantity
    if (_selectedProduct != null) {
      if (_selectedProduct!.quantity <= 0) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('هذا المنتج نفذ من المخزون، يرجى اختيار منتج آخر'),
              backgroundColor: Colors.red,
            ),
          );
        }
        setState(() => _isLoading = false);
        return;
      }
      if (_productQuantity > _selectedProduct!.quantity) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('الكمية المطلوبة ($_productQuantity) تتجاوز المتوفر (${_selectedProduct!.quantity})'),
              backgroundColor: Colors.red,
            ),
          );
        }
        setState(() => _isLoading = false);
        return;
      }
    }

    setState(() => _isLoading = true);

    try {
      final amount = double.parse(
        _amountController.text.replaceAll(RegExp(r'[^\d.]'), ''),
      );

      // Build installment dates/amounts if applicable
      List<DateTime>? installmentDates;
      List<double>? installmentAmounts;
      if (_isInstallment && _installmentCount >= 2) {
        final perAmount = amount / _installmentCount;
        final now = DateTime.now();
        installmentDates = List.generate(
          _installmentCount,
          (i) => _addMonths(now, i + 1),
        );
        installmentAmounts = List.generate(_installmentCount, (_) => perAmount);
      }

      await ref
          .read(debtsProvider.notifier)
          .addDebt(
            customerId: widget.customer.id,
            amount: amount,
            productId: _selectedProduct?.id,
            productName: _productNameController.text.isNotEmpty
                ? _productNameController.text
                : _selectedProduct?.name,
            productQuantity: _productQuantity,
            notes: _notesController.text.isEmpty ? null : _notesController.text,
            isInstallment: _isInstallment,
            installmentCount: _isInstallment ? _installmentCount : 1,
            installmentDates: installmentDates,
            installmentAmounts: installmentAmounts,
            isCashSale: _isCashSale,
          );

      // Calculate totalDebt directly from Hive (after addDebt) for accurate limit check
      if (!_isCashSale) {
        final newTotalDebt = HiveService.getDebtsByCustomer(
          widget.customer.id,
        ).fold<double>(0, (sum, d) => sum + d.remainingAmount);
        final settings = HiveService.getAppSettings();
        await NotificationService.showLimitWarning(
          settings: settings,
          customer: widget.customer,
          totalDebt: newTotalDebt,
        );
      }

      if (mounted) {
        HapticFeedback.lightImpact();
        Navigator.pop(context);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text(AppStrings.successSaved)));
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }
}
