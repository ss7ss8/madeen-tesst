import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../data/local/hive_service.dart';
import '../../../data/models/debt.dart';
import '../../../data/models/payment.dart';
import 'debts_provider.dart';

sealed class CustomerActivityItem {
  DateTime get date;
  String get id;
}

class DebtActivity extends CustomerActivityItem {
  final Debt debt;
  DebtActivity(this.debt);
  @override
  DateTime get date => debt.createdAt;
  @override
  String get id => debt.id;
}

class PaymentActivity extends CustomerActivityItem {
  final Payment payment;
  PaymentActivity(this.payment);
  @override
  DateTime get date => payment.createdAt;
  @override
  String get id => payment.id;
}

final customerActivityProvider =
    Provider.family<List<CustomerActivityItem>, String>((ref, customerId) {
  ref.watch(debtsProvider);

  final debts = HiveService.getDebtsByCustomer(customerId);
  final activities = <CustomerActivityItem>[];

  for (final debt in debts) {
    activities.add(DebtActivity(debt));
    final payments = HiveService.getPaymentsByDebt(debt.id);
    for (final payment in payments) {
      activities.add(PaymentActivity(payment));
    }
  }

  activities.sort((a, b) => b.date.compareTo(a.date));
  return activities;
});
