import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../../../data/local/hive_service.dart';
import '../../../data/models/customer.dart';
import '../../../data/models/debt.dart';
import '../../../core/services/supabase_service.dart';
import '../../../core/services/sync_service.dart';
import '../../../core/services/notification_service.dart';

import '../../inventory/providers/inventory_provider.dart';
import '../../reports/providers/reports_provider.dart';
import 'debts_provider.dart';

const _uuid = Uuid();

final customersProvider =
    StateNotifierProvider<CustomersNotifier, List<Customer>>((ref) {
      return CustomersNotifier(ref);
    });

enum CustomerFilter {
  all,
  mostIndebted,
  recent,
  paid,
  top10Debts,
  todayPayments,
  lateMoreThanMonth,
  alphabetical,
  mostReliable,
  leastReliable,
}

class CustomersNotifier extends StateNotifier<List<Customer>> {
  final Ref _ref;
  CustomerFilter _filter = CustomerFilter.all;
  String _searchQuery = '';

  late final VoidCallback _syncListener;

  CustomersNotifier(this._ref) : super([]) {
    loadCustomers();
    _syncListener = () {
      final currentCount = HiveService.getAllCustomers().length;
      if (currentCount != state.length) {
        loadCustomers();
      }
    };
    syncCompletedVersion.addListener(_syncListener);
  }

  @override
  void dispose() {
    syncCompletedVersion.removeListener(_syncListener);
    super.dispose();
  }

  CustomerFilter get filter => _filter;
  String get searchQuery => _searchQuery;

  void loadCustomers() {
    var customers = HiveService.getAllCustomers();

    if (_searchQuery.isNotEmpty) {
      final query = _searchQuery.toLowerCase();
      final invoiceNumber = int.tryParse(query);

      // Precompute debts for search to avoid calling HiveService in a loop
      Map<String, List<Debt>>? searchDebtsMap;
      if (invoiceNumber != null) {
        searchDebtsMap = {
          for (final c in customers) c.id: HiveService.getDebtsByCustomer(c.id),
        };
      }

      customers = customers.where((c) {
        if (c.name.toLowerCase().contains(query) ||
            (c.phone?.contains(query) ?? false)) {
          return true;
        }
        // Search by invoice number if query is a number
        if (invoiceNumber != null && searchDebtsMap != null) {
          final debts = searchDebtsMap[c.id] ?? [];
          return debts.any((d) => d.invoiceNumber == invoiceNumber);
        }
        return false;
      }).toList();
    }

    switch (_filter) {
      case CustomerFilter.all:
        customers.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
        break;
      case CustomerFilter.mostIndebted:
        final debtMap = {
          for (final c in customers) c.id: getCustomerDebt(c.id),
        };
        customers.sort((a, b) => debtMap[b.id]!.compareTo(debtMap[a.id]!));
        break;
      case CustomerFilter.recent:
        customers.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        break;
      case CustomerFilter.paid:
        final debtMap = {
          for (final c in customers) c.id: getCustomerDebt(c.id),
        };
        customers = customers.where((c) => debtMap[c.id] == 0).toList();
        break;
      case CustomerFilter.top10Debts:
        final debtMap = {
          for (final c in customers) c.id: getCustomerDebt(c.id),
        };
        customers.sort((a, b) => debtMap[b.id]!.compareTo(debtMap[a.id]!));
        customers = customers.take(10).toList();
        break;
      case CustomerFilter.todayPayments:
        final today = DateTime.now();
        final todayCustomerIds = HiveService.getAllPayments()
            .where(
              (p) =>
                  p.createdAt.year == today.year &&
                  p.createdAt.month == today.month &&
                  p.createdAt.day == today.day,
            )
            .map((p) {
              final debt = HiveService.getAllDebts().firstWhere(
                (d) => d.id == p.debtId,
                orElse: () => Debt(
                  id: '',
                  customerId: '',
                  amount: 0,
                  userId: '',
                  createdAt: DateTime.now(),
                ),
              );
              return debt.customerId;
            })
            .where((id) => id.isNotEmpty)
            .toSet();
        customers = customers
            .where((c) => todayCustomerIds.contains(c.id))
            .toList();
        customers.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
        break;
      case CustomerFilter.lateMoreThanMonth:
        final now = DateTime.now();
        final customerDebtsMap = {
          for (final c in customers)
            c.id: HiveService.getDebtsByCustomer(
              c.id,
            ).where((d) => !d.isPaid).toList(),
        };
        final customerDebtAmounts = {
          for (final c in customers) c.id: getCustomerDebt(c.id),
        };

        customers = customers.where((c) {
          final debts = customerDebtsMap[c.id] ?? [];
          if (debts.isEmpty) return false;
          final maxOverdue = debts
              .map((d) {
                final due = d.dueDate ?? d.createdAt;
                return now.difference(due).inDays;
              })
              .reduce((a, b) => a > b ? a : b);
          return maxOverdue > 30;
        }).toList();

        customers.sort((a, b) {
          final aDebt = customerDebtAmounts[a.id] ?? 0.0;
          final bDebt = customerDebtAmounts[b.id] ?? 0.0;
          return bDebt.compareTo(aDebt);
        });
        break;
      case CustomerFilter.alphabetical:
        customers.sort((a, b) => a.name.compareTo(b.name));
        break;
      case CustomerFilter.mostReliable:
        final reliabilityMap = {
          for (final c in customers) c.id: _reliabilityScore(c.id),
        };
        customers.sort(
          (a, b) => reliabilityMap[b.id]!.compareTo(reliabilityMap[a.id]!),
        );
        break;
      case CustomerFilter.leastReliable:
        final reliabilityMap = {
          for (final c in customers) c.id: _reliabilityScore(c.id),
        };
        customers.sort(
          (a, b) => reliabilityMap[a.id]!.compareTo(reliabilityMap[b.id]!),
        );
        break;
    }

    state = customers;
  }

  double getCustomerDebt(String customerId) {
    final debts = HiveService.getDebtsByCustomer(customerId);
    return debts.fold<double>(0, (sum, d) => sum + d.remainingAmount);
  }

  void setFilter(CustomerFilter filter) {
    _filter = filter;
    loadCustomers();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    loadCustomers();
  }

  Future<String> addCustomer({
    required String name,
    String? phone,
    double? initialDebt,
    String? productId,
    String? productName,
    int productQuantity = 1,
    DateTime? date,
  }) async {
    final normalizedName = name.trim().toLowerCase();
    final normalizedPhone = phone?.replaceAll(RegExp(r'[\s+]'), '').trim();

    final allCustomers = HiveService.getAllCustomers();
    for (final existing in allCustomers) {
      if (existing.name.trim().toLowerCase() == normalizedName) {
        throw Exception('يوجد زبون مسجل بنفس الاسم: ${existing.name}');
      }
      if (normalizedPhone != null && normalizedPhone.isNotEmpty) {
        final existingPhone = existing.phone
            ?.replaceAll(RegExp(r'[\s+]'), '')
            .trim();
        if (existingPhone != null &&
            existingPhone.isNotEmpty &&
            existingPhone == normalizedPhone) {
          throw Exception('يوجد زبون مسجل بنفس رقم الهاتف: ${existing.name}');
        }
      }
    }

    final userId = SupabaseService.currentUser?.id ?? 'local';
    final now = DateTime.now();

    final customer = Customer(
      id: _uuid.v4(),
      name: name,
      phone: phone,
      userId: userId,
      createdAt: now,
      updatedAt: now,
    );

    await HiveService.saveCustomer(customer);

    if (initialDebt != null && initialDebt > 0) {
      await _addDebt(
        customerId: customer.id,
        amount: initialDebt,
        productId: productId,
        productName: productName,
        productQuantity: productQuantity,
        date: date,
      );
    }

    loadCustomers();
    // تزامن مؤجل بعد إضافة الزبون
    SyncService.syncAllDebounced();
    return customer.id;
  }

  Future<void> _addDebt({
    required String customerId,
    required double amount,
    String? productId,
    String? productName,
    int productQuantity = 1,
    DateTime? date,
    bool isInstallment = false,
    int installmentCount = 1,
    List<DateTime>? installmentDates,
    List<double>? installmentAmounts,
  }) async {
    final userId = SupabaseService.currentUser?.id ?? 'local';

    final List<String>? statuses = isInstallment && installmentCount >= 1
        ? List.generate(installmentCount, (_) => 'pending')
        : null;
    final List<DateTime>? paidAts = isInstallment && installmentCount >= 1
        ? List.generate(installmentCount, (_) => DateTime(0))
        : null;

    // Assign sequential invoice number
    final settings = HiveService.getAppSettings();
    final invoiceNumber = settings.lastInvoiceNumber + 1;
    await HiveService.saveAppSettings(
      settings.copyWith(lastInvoiceNumber: invoiceNumber),
    );

    // Capture product prices at the time of sale for profit calculation
    double? unitSalePrice;
    double? unitCostPrice;
    if (productId != null) {
      final product = HiveService.getProduct(productId);
      if (product != null) {
        unitSalePrice = product.salePrice;
        unitCostPrice = product.purchasePrice;
      }
    }

    final debt = Debt(
      id: _uuid.v4(),
      customerId: customerId,
      amount: amount,
      productId: productId,
      productName: productName,
      productQuantity: productQuantity,
      userId: userId,
      createdAt: date ?? DateTime.now(),
      isInstallment: isInstallment,
      installmentCount: installmentCount,
      installmentDates: installmentDates,
      installmentAmounts: installmentAmounts,
      installmentStatuses: statuses,
      installmentPaidAts: paidAts,
      installmentPaidCount: isInstallment ? 0 : null,
      invoiceNumber: invoiceNumber,
      unitSalePrice: unitSalePrice,
      unitCostPrice: unitCostPrice,
    );

    await HiveService.saveDebt(debt);

    if (productId != null) {
      final product = HiveService.getProduct(productId);
      if (product != null) {
        await HiveService.updateProductQuantity(
          productId,
          product.quantity - productQuantity,
        );
      }
    }

    // Schedule installment notifications — mirrors DebtsNotifier.addDebt.
    // Previously missing here, causing customers added with installment debts
    // to never receive payment reminders.
    if (debt.isInstallment) {
      final customer = HiveService.getCustomer(customerId);
      if (customer != null) {
        await NotificationService.scheduleAllInstallmentNotifications(
          settings: settings,
          debt: debt,
          customerName: customer.name,
        );
      }
    }

    _ref.invalidate(debtsProvider);
    _ref.invalidate(reportDataProvider);
    if (productId != null) {
      _ref.invalidate(productsProvider);
    }
  }

  Future<void> updateCustomer(Customer customer) async {
    final normalizedName = customer.name.trim().toLowerCase();
    final normalizedPhone = customer.phone
        ?.replaceAll(RegExp(r'[\s+]'), '')
        .trim();

    final allCustomers = HiveService.getAllCustomers();
    for (final existing in allCustomers) {
      if (existing.id == customer.id) continue;

      if (existing.name.trim().toLowerCase() == normalizedName) {
        throw Exception('يوجد زبون آخر مسجل بنفس الاسم: ${existing.name}');
      }
      if (normalizedPhone != null && normalizedPhone.isNotEmpty) {
        final existingPhone = existing.phone
            ?.replaceAll(RegExp(r'[\s+]'), '')
            .trim();
        if (existingPhone != null &&
            existingPhone.isNotEmpty &&
            existingPhone == normalizedPhone) {
          throw Exception(
            'يوجد زبون آخر مسجل بنفس رقم الهاتف: ${existing.name}',
          );
        }
      }
    }

    final updated = customer.copyWith(updatedAt: DateTime.now());
    await HiveService.saveCustomer(updated);
    loadCustomers();
    // تزامن مؤجل بعد تعديل الزبون
    SyncService.syncAllDebounced();
  }

  Future<String?> updateCustomerImage(
    String customerId,
    String filePath,
  ) async {
    final url = await SupabaseService.uploadCustomerImage(customerId, filePath);
    if (url == null) return null;

    final customers = HiveService.getAllCustomers();
    final idx = customers.indexWhere((c) => c.id == customerId);
    if (idx == -1) return null;

    final updated = customers[idx].copyWith(
      imageUrl: url,
      updatedAt: DateTime.now(),
    );
    await HiveService.saveCustomer(updated);
    loadCustomers();
    // تزامن مؤجل بعد تحديث صورة الزبون
    SyncService.syncAllDebounced();
    return url;
  }

  Future<void> deleteCustomer(String id) async {
    final debts = HiveService.getDebtsByCustomer(id, includeDeleted: true);
    bool stockChanged = false;
    for (final debt in debts) {
      // Restore product stock only for active (non-deleted) debts
      if (debt.productId != null && debt.deletedAt == null) {
        final product = HiveService.getProduct(debt.productId!);
        if (product != null) {
          await HiveService.updateProductQuantity(
            debt.productId!,
            product.quantity + debt.productQuantity,
          );
          stockChanged = true;
        }
      }
      await HiveService.deleteDebt(debt.id);
      await NotificationService.cancelAllDebtNotifications(debt.id);
    }
    await HiveService.deleteCustomer(id);
    loadCustomers();
    // تزامن مؤجل بعد حذف الزبون
    SyncService.syncAllDebounced();
    _ref.invalidate(reportDataProvider);
    if (stockChanged) {
      _ref.invalidate(productsProvider);
    }
  }

  Future<void> restoreCustomer(String id) async {
    final debts = HiveService.getDebtsByCustomer(id, includeDeleted: true);
    final customer = HiveService.getCustomer(id);
    final settings = HiveService.getAppSettings();
    bool stockChanged = false;
    for (final debt in debts) {
      // Re-deduct product stock for debts that were deleted (restoring them)
      if (debt.productId != null && debt.deletedAt != null) {
        final product = HiveService.getProduct(debt.productId!);
        if (product != null) {
          await HiveService.updateProductQuantity(
            debt.productId!,
            product.quantity - debt.productQuantity,
          );
          stockChanged = true;
        }
      }
      await HiveService.restoreDebt(debt.id);
      // Reschedule future installment notifications
      if (debt.isInstallment && customer != null) {
        await NotificationService.scheduleAllInstallmentNotifications(
          settings: settings,
          debt: debt,
          customerName: customer.name,
        );
      }
    }
    await HiveService.restoreCustomer(id);
    loadCustomers();
    // تزامن مؤجل بعد استعادة الزبون
    SyncService.syncAllDebounced();
    _ref.invalidate(reportDataProvider);
    if (stockChanged) {
      _ref.invalidate(productsProvider);
    }
  }

  Future<void> permanentDeleteCustomer(
    String id, {
    bool deleteDebts = true,
  }) async {
    if (deleteDebts) {
      final debts = HiveService.getDebtsByCustomer(id, includeDeleted: true);
      bool stockChanged = false;
      for (final debt in debts) {
        // Restore product stock only for active (non-deleted) debts
        if (debt.productId != null && debt.deletedAt == null) {
          final product = HiveService.getProduct(debt.productId!);
          if (product != null) {
            await HiveService.updateProductQuantity(
              debt.productId!,
              product.quantity + debt.productQuantity,
            );
            stockChanged = true;
          }
        }
        await NotificationService.cancelAllDebtNotifications(debt.id);
        await HiveService.permanentDeleteDebt(debt.id);
      }
      if (stockChanged) {
        _ref.invalidate(productsProvider);
      }
    }
    await HiveService.permanentDeleteCustomer(id);
    loadCustomers();
    // تزامن مؤجل بعد الحذف النهائي
    SyncService.syncAllDebounced();
    _ref.invalidate(reportDataProvider);
  }

  Debt? getLastDebt(String customerId) {
    final debts = HiveService.getDebtsByCustomer(customerId);
    if (debts.isEmpty) return null;
    return debts.reduce((a, b) => a.createdAt.isAfter(b.createdAt) ? a : b);
  }

  int _reliabilityScore(String customerId) =>
      HiveService.reliabilityRank(HiveService.customerReliability(customerId));
}

final customerDebtProvider = Provider.family<double, String>((ref, customerId) {
  ref.watch(customersProvider);
  ref.watch(debtsProvider);
  return HiveService.getDebtsByCustomer(
    customerId,
  ).fold<double>(0, (sum, d) => sum + d.remainingAmount);
});

/// Provider يحسب موثوقية جميع الزبائن دفعة واحدة من Hive
/// بدلاً من O(N×M) استدعاء منفصل لكل زبون
final customerReliabilitiesProvider = Provider<Map<String, String>>((ref) {
  ref.watch(customersProvider); // أعد الحساب عند تغيير الزبائن
  ref.watch(debtsProvider); // أعد الحساب عند تغيير الديون
  return HiveService.getAllCustomerReliabilities();
});
