import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/utils/logger.dart';
import 'package:uuid/uuid.dart';
import '../../../data/local/hive_service.dart';
import '../../../data/models/debt.dart';
import '../../../data/models/payment.dart';
import '../../../core/services/supabase_service.dart';
import '../../../core/services/sync_service.dart';
import '../../../core/services/notification_service.dart';

import '../../installments/providers/installments_provider.dart';
import '../../inventory/providers/inventory_provider.dart';
import '../../reports/providers/reports_provider.dart';

const _uuid = Uuid();

final debtsProvider = StateNotifierProvider<DebtsNotifier, List<Debt>>((ref) {
  return DebtsNotifier(ref);
});

class DebtsNotifier extends StateNotifier<List<Debt>> {
  final Ref _ref;

  late final VoidCallback _syncListener;

  DebtsNotifier(this._ref) : super([]) {
    loadDebts();
    _syncListener = () {
      final currentCount = HiveService.getAllDebts().length;
      if (currentCount != state.length) {
        loadDebts();
      }
    };
    syncCompletedVersion.addListener(_syncListener);
  }

  @override
  void dispose() {
    syncCompletedVersion.removeListener(_syncListener);
    super.dispose();
  }

  void loadDebts() {
    final allDebts = HiveService.getAllDebts();
    appLogger.debug('loadDebts called: ${allDebts.length} debts found');
    state = allDebts;
  }

  List<Debt> getDebtsByCustomer(String customerId) {
    return HiveService.getDebtsByCustomer(customerId);
  }

  Future<String> addDebt({
    required String customerId,
    required double amount,
    String? productId,
    String? productName,
    int productQuantity = 1,
    DateTime? date,
    String? notes,
    bool isInstallment = false,
    int installmentCount = 1,
    List<DateTime>? installmentDates,
    List<double>? installmentAmounts,
    bool isCashSale = false,
    DateTime? dueDate,
  }) async {
    final userId = SupabaseService.currentUser?.id ?? 'local';

    final List<String>? statuses = isInstallment && installmentCount > 1
        ? List.generate(installmentCount, (_) => 'pending')
        : null;
    final List<DateTime>? paidAts = isInstallment && installmentCount > 1
        ? List.generate(installmentCount, (_) => DateTime(0))
        : null;

    // Assign sequential invoice number
    final settings = HiveService.getAppSettings();
    final invoiceNumber = settings.lastInvoiceNumber + 1;
    await HiveService.saveAppSettings(
      settings.copyWith(lastInvoiceNumber: invoiceNumber),
    );

    // Capture product prices at the time of sale for profit calculation
    double? unitSalePrice;
    double? unitCostPrice;
    if (productId != null) {
      final product = HiveService.getProduct(productId);
      if (product != null) {
        unitSalePrice = product.salePrice;
        unitCostPrice = product.purchasePrice;
      }
    }

    final debt = Debt(
      id: _uuid.v4(),
      customerId: customerId,
      amount: amount,
      productId: productId,
      productName: productName,
      productQuantity: productQuantity,
      userId: userId,
      createdAt: date ?? DateTime.now(),
      isInstallment: isInstallment,
      installmentCount: installmentCount,
      installmentDates: installmentDates,
      installmentAmounts: installmentAmounts,
      installmentStatuses: statuses,
      installmentPaidAts: paidAts,
      invoiceNumber: invoiceNumber,
      paidAmount: isCashSale ? amount : 0.0,
      isPaid: isCashSale,
      isCashSale: isCashSale,
      dueDate: dueDate,
      notes: notes,
      unitSalePrice: unitSalePrice,
      unitCostPrice: unitCostPrice,
    );

    await HiveService.saveDebt(debt);

    if (isCashSale) {
      final payment = Payment(
        id: _uuid.v4(),
        debtId: debt.id,
        amount: amount,
        userId: userId,
        createdAt: date ?? DateTime.now(),
      );
      await HiveService.savePayment(payment);
    }

    if (productId != null) {
      final product = HiveService.getProduct(productId);
      if (product != null) {
        await HiveService.updateProductQuantity(
          productId,
          product.quantity - productQuantity,
        );
      }
    }

    final customer = HiveService.getCustomer(customerId);

    // Schedule notifications if applicable
    if (debt.isInstallment) {
      if (customer != null) {
        await NotificationService.scheduleAllInstallmentNotifications(
          settings: settings,
          debt: debt,
          customerName: customer.name,
        );
      }
    } else if (debt.dueDate != null) {
      // Schedule single reminder for regular debt with due date
      if (customer != null) {
        await NotificationService.scheduleRegularDebtNotification(
          settings: settings,
          debtId: debt.id,
          dueDate: debt.dueDate!,
          amount: debt.amount,
          customerName: customer.name,
        );
      }
    }

    loadDebts();
    _ref.invalidate(installmentsProvider);
    _ref.invalidate(reportDataProvider);
    if (productId != null) {
      _ref.invalidate(productsProvider);
    }
    // تزامن مؤجل — يدمج طلبات متعددة في مزامنة واحدة
    SyncService.syncAllDebounced();
    return debt.id;
  }

  Future<void> toggleInstallmentPaid({
    required String debtId,
    required int installmentIndex,
    required bool markAsPaid,
  }) async {
    final debts = HiveService.getAllDebts();
    final originalDebt = debts.firstWhere((d) => d.id == debtId);

    if (!originalDebt.isInstallment ||
        originalDebt.installmentStatuses == null ||
        originalDebt.installmentAmounts == null ||
        installmentIndex >= originalDebt.installmentStatuses!.length) {
      return;
    }

    final statuses = List<String>.from(originalDebt.installmentStatuses!);
    final paidAts = originalDebt.installmentPaidAts != null
        ? List<DateTime>.from(originalDebt.installmentPaidAts!)
        : List<DateTime>.generate(statuses.length, (_) => DateTime(0));
    final amounts = List<double>.from(originalDebt.installmentAmounts!);
    final dates = originalDebt.installmentDates != null
        ? List<DateTime>.from(originalDebt.installmentDates!)
        : <DateTime>[];

    final amount = amounts[installmentIndex];
    double newPaidAmount = originalDebt.paidAmount;
    int newPaidCount = originalDebt.installmentPaidCount ?? 0;

    if (markAsPaid) {
      statuses[installmentIndex] = 'paid';
      if (installmentIndex < paidAts.length) {
        paidAts[installmentIndex] = DateTime.now();
      }
      newPaidAmount += amount;
      newPaidCount += 1;
    } else {
      statuses[installmentIndex] = 'pending';
      if (installmentIndex < paidAts.length) {
        paidAts[installmentIndex] = DateTime(0);
      }
      newPaidAmount -= amount;
      newPaidCount -= 1;
    }

    newPaidAmount = newPaidAmount.clamp(0.0, originalDebt.amount);
    final isPaid = newPaidAmount >= originalDebt.amount;

    final debt = originalDebt.copyWith(
      installmentStatuses: statuses,
      installmentPaidAts: paidAts,
      paidAmount: newPaidAmount,
      installmentPaidCount: newPaidCount,
      isPaid: isPaid,
    );

    await HiveService.saveDebt(debt);

    // Cancel or reschedule installment notifications
    final settings = HiveService.getAppSettings();
    if (markAsPaid) {
      await NotificationService.cancelInstallmentNotifications(
        debtId,
        installmentIndex,
      );
    } else {
      // Re-schedule for this installment (it was reverted to pending)
      final customer = HiveService.getCustomer(debt.customerId);
      if (customer != null && installmentIndex < dates.length) {
        final amt = installmentIndex < amounts.length
            ? amounts[installmentIndex]
            : 0.0;
        await NotificationService.scheduleInstallmentNotification(
          settings: settings,
          debtId: debtId,
          installmentIndex: installmentIndex,
          dueDate: dates[installmentIndex],
          amount: amt,
          customerName: customer.name,
        );
      }
    }

    // Record or remove payment
    if (markAsPaid) {
      final userId = SupabaseService.currentUser?.id ?? 'local';
      final payment = Payment(
        id: _uuid.v4(),
        debtId: debtId,
        amount: amount,
        userId: userId,
        createdAt: DateTime.now(),
      );
      await HiveService.savePayment(payment);
    } else {
      // Find and remove the most recent payment matching this amount for this debt.
      // Using the most recent match (sorted descending by createdAt) is more accurate
      // than using firstWhere, which could delete an older payment from a different
      // installment that happens to have the same amount.
      final payments = HiveService.getPaymentsByDebt(debtId);
      final matchingPayments =
          payments.where((p) => p.amount == amount).toList()
            ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
      if (matchingPayments.isNotEmpty) {
        await HiveService.deletePayment(matchingPayments.first.id);
      }
    }

    loadDebts();
    _ref.invalidate(installmentsProvider);
    _ref.invalidate(reportDataProvider);
    // تزامن مؤجل — يدمج طلبات متعددة في مزامنة واحدة
    SyncService.syncAllDebounced();
  }

  Future<void> payDebt(String debtId, double amount) async {
    final debts = HiveService.getAllDebts();
    final originalDebt = debts.firstWhere((d) => d.id == debtId);

    final remaining = originalDebt.amount - originalDebt.paidAmount;
    final actualPayment = amount.clamp(0.0, remaining);

    if (actualPayment <= 0) return;

    double newPaidAmount = originalDebt.paidAmount + actualPayment;
    bool isPaid = newPaidAmount >= originalDebt.amount;

    List<String>? newStatuses;
    List<DateTime>? newPaidAts;
    int? newPaidCount = originalDebt.installmentPaidCount;

    if (originalDebt.isInstallment &&
        originalDebt.installmentStatuses != null &&
        originalDebt.installmentAmounts != null) {
      newStatuses = List<String>.from(originalDebt.installmentStatuses!);
      newPaidAts = originalDebt.installmentPaidAts != null
          ? List<DateTime>.from(originalDebt.installmentPaidAts!)
          : List<DateTime>.generate(newStatuses.length, (_) => DateTime(0));
      final amounts = originalDebt.installmentAmounts!;

      int paidCount = 0;
      double tempPaid = newPaidAmount;

      for (int i = 0; i < newStatuses.length; i++) {
        final instAmount = i < amounts.length ? amounts[i] : 0.0;
        if (tempPaid >= instAmount && instAmount > 0) {
          newStatuses[i] = 'paid';
          if (i < newPaidAts.length && newPaidAts[i] == DateTime(0)) {
            newPaidAts[i] = DateTime.now();
          }
          tempPaid -= instAmount;
          paidCount++;
        } else {
          newStatuses[i] = 'pending';
          if (i < newPaidAts.length) {
            newPaidAts[i] = DateTime(0);
          }
        }
      }
      newPaidCount = paidCount;
    }

    final debt = originalDebt.copyWith(
      paidAmount: newPaidAmount,
      isPaid: isPaid,
      installmentStatuses: newStatuses,
      installmentPaidAts: newPaidAts,
      installmentPaidCount: newPaidCount,
    );

    await HiveService.saveDebt(debt);

    final userId = SupabaseService.currentUser?.id ?? 'local';
    final payment = Payment(
      id: _uuid.v4(),
      debtId: debtId,
      amount: actualPayment,
      userId: userId,
      createdAt: DateTime.now(),
    );
    await HiveService.savePayment(payment);

    loadDebts();
    _ref.invalidate(installmentsProvider);
    _ref.invalidate(reportDataProvider);
    // تزامن مؤجل — يدمج طلبات متعددة في مزامنة واحدة
    SyncService.syncAllDebounced();
  }

  Future<void> deleteDebt(String id) async {
    final debt = HiveService.getDebt(id);

    await HiveService.deleteDebt(id);
    await NotificationService.cancelAllDebtNotifications(id);

    // Restore product stock if the debt had an associated product
    if (debt != null && debt.productId != null) {
      final product = HiveService.getProduct(debt.productId!);
      if (product != null) {
        await HiveService.updateProductQuantity(
          debt.productId!,
          product.quantity + debt.productQuantity,
        );
      }
    }

    loadDebts();
    _ref.invalidate(installmentsProvider);
    _ref.invalidate(reportDataProvider);
    if (debt != null && debt.productId != null) {
      _ref.invalidate(productsProvider);
    }
    // تزامن مؤجل — يدمج طلبات متعددة في مزامنة واحدة
    SyncService.syncAllDebounced();
  }
}
