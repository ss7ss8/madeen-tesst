import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../data/local/hive_service.dart';
import 'debts_provider.dart';

/// Type of a statement entry.
enum StatementEntryType {
  /// Purchase on credit (debt).
  debt,

  /// Purchase paid in cash.
  cash,

  /// Payment / settlement against a debt.
  payment,
}

/// A single line in a customer account statement.
class StatementEntry {
  final DateTime date;
  final String description;
  final StatementEntryType type;
  final double amount;
  final double runningBalance;
  final int? invoiceNumber;
  final String? sourceId;

  StatementEntry({
    required this.date,
    required this.description,
    required this.type,
    required this.amount,
    required this.runningBalance,
    this.invoiceNumber,
    this.sourceId,
  });

  String get typeLabel {
    switch (type) {
      case StatementEntryType.debt:
        return 'دين';
      case StatementEntryType.cash:
        return 'نقدي';
      case StatementEntryType.payment:
        return 'تسديد';
    }
  }
}

/// Aggregated statement data for a customer.
class AccountStatement {
  final List<StatementEntry> entries;
  final double totalDebtPurchases;
  final double totalCashPurchases;
  final double totalPayments;
  final double currentBalance;

  AccountStatement({
    required this.entries,
    required this.totalDebtPurchases,
    required this.totalCashPurchases,
    required this.totalPayments,
    required this.currentBalance,
  });

  /// Total of all purchases (debt + cash).
  double get totalPurchases => totalDebtPurchases + totalCashPurchases;

  /// Number of transactions.
  int get transactionCount => entries.length;

  /// Earliest transaction date, or null if empty.
  DateTime? get firstDate =>
      entries.isEmpty ? null : entries.last.date; // entries are newest-first

  /// Latest transaction date, or null if empty.
  DateTime? get lastDate =>
      entries.isEmpty ? null : entries.first.date; // entries are newest-first
}

/// Builds a full account statement for the given customer.
///
/// The statement merges:
/// - All debt records (purchases on credit → type `debt`).
/// - All cash-sale records (purchases paid in cash → type `cash`).
/// - All payments made against debts (→ type `payment`).
///
/// A running balance is computed chronologically: debt purchases increase
/// the balance, payments decrease it, and cash sales do not affect it.
final accountStatementProvider = Provider.family<AccountStatement, String>((
  ref,
  customerId,
) {
  ref.watch(debtsProvider);

  final debts = HiveService.getDebtsByCustomer(customerId);
  final entries = <StatementEntry>[];

  double totalDebtPurchases = 0;
  double totalCashPurchases = 0;
  double totalPayments = 0;

  for (final debt in debts) {
    if (debt.isCashSale) {
      totalCashPurchases += debt.amount;
      entries.add(
        StatementEntry(
          date: debt.createdAt,
          description: debt.productName ?? 'بيع نقدي',
          type: StatementEntryType.cash,
          amount: debt.amount,
          runningBalance: 0, // filled after sorting
          invoiceNumber: debt.invoiceNumber,
          sourceId: debt.id,
        ),
      );
    } else {
      totalDebtPurchases += debt.amount;
      entries.add(
        StatementEntry(
          date: debt.createdAt,
          description: debt.productName ?? 'دين',
          type: StatementEntryType.debt,
          amount: debt.amount,
          runningBalance: 0, // filled after sorting
          invoiceNumber: debt.invoiceNumber,
          sourceId: debt.id,
        ),
      );
    }

    // Add payments for this debt
    final payments = HiveService.getPaymentsByDebt(debt.id);
    for (final payment in payments) {
      totalPayments += payment.amount;
      entries.add(
        StatementEntry(
          date: payment.createdAt,
          description: 'تسديد',
          type: StatementEntryType.payment,
          amount: payment.amount,
          runningBalance: 0, // filled after sorting
          sourceId: payment.id,
        ),
      );
    }
  }

  // Sort chronologically (oldest first) to compute running balance
  entries.sort((a, b) => a.date.compareTo(b.date));

  // Compute running balance: debt purchases increase the balance,
  // payments decrease it, cash sales do not affect it.
  final withBalance = <StatementEntry>[];
  double balance = 0;
  for (final entry in entries) {
    if (entry.type == StatementEntryType.debt) {
      balance += entry.amount;
    } else if (entry.type == StatementEntryType.payment) {
      balance -= entry.amount;
    }
    withBalance.add(
      StatementEntry(
        date: entry.date,
        description: entry.description,
        type: entry.type,
        amount: entry.amount,
        runningBalance: balance,
        invoiceNumber: entry.invoiceNumber,
        sourceId: entry.sourceId,
      ),
    );
  }

  // Reverse to newest-first for display
  withBalance.sort((a, b) => b.date.compareTo(a.date));

  return AccountStatement(
    entries: withBalance,
    totalDebtPurchases: totalDebtPurchases,
    totalCashPurchases: totalCashPurchases,
    totalPayments: totalPayments,
    currentBalance: balance,
  );
});
