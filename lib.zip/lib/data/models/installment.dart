/// Represents a single installment row from the Supabase `installments` table.
///
/// In the local Hive store, installment data is embedded inside [Debt] as
/// parallel arrays (installmentDates, installmentAmounts, installmentStatuses,
/// installmentPaidAts). This class is used as a transport DTO when
/// pulling/pushing installment rows to/from Supabase, and is then mapped back
/// onto the parent [Debt] by [HiveService.saveInstallment].
class Installment {
  final String id;
  final String debtId;
  final String customerId;
  final String userId;
  final double amount;
  final DateTime dueDate;
  final String status; // 'pending', 'paid', 'overdue'
  final DateTime? paidAt;
  final int installmentNumber;
  final DateTime createdAt;
  final DateTime updatedAt;

  Installment({
    required this.id,
    required this.debtId,
    required this.customerId,
    required this.userId,
    required this.amount,
    required this.dueDate,
    required this.status,
    this.paidAt,
    required this.installmentNumber,
    required this.createdAt,
    required this.updatedAt,
  });

  bool get isPaid => status == 'paid';
  bool get isOverdue => status == 'overdue';

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'debt_id': debtId,
      'customer_id': customerId,
      'user_id': userId,
      'amount': amount,
      'due_date': dueDate.toIso8601String(),
      'status': status,
      'paid_at': paidAt?.toIso8601String(),
      'installment_number': installmentNumber,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory Installment.fromJson(Map<String, dynamic> json) {
    return Installment(
      id: json['id'] as String,
      debtId: json['debt_id'] as String,
      customerId: json['customer_id'] as String,
      userId: json['user_id'] as String,
      amount: (json['amount'] as num).toDouble(),
      dueDate: DateTime.parse(json['due_date'] as String),
      status: json['status'] as String? ?? 'pending',
      paidAt: json['paid_at'] != null
          ? DateTime.parse(json['paid_at'] as String)
          : null,
      installmentNumber: (json['installment_number'] as num?)?.toInt() ?? 1,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'] as String)
          : DateTime.now(),
    );
  }

  @override
  String toString() {
    return 'Installment(id: $id, debtId: $debtId, amount: $amount, '
        'status: $status, installmentNumber: $installmentNumber)';
  }
}
