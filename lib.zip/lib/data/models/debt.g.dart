// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'debt.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class DebtAdapter extends TypeAdapter<Debt> {
  @override
  final int typeId = 1;

  @override
  Debt read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Debt(
      id: fields[0] as String,
      customerId: fields[1] as String,
      amount: fields[2] as double,
      productId: fields[3] as String?,
      productName: fields[4] as String?,
      productQuantity: fields[5] as int,
      userId: fields[6] as String,
      createdAt: fields[7] as DateTime,
      dueDate: fields[8] as DateTime?,
      paidAmount: fields[9] as double,
      isPaid: fields[10] as bool,
      notes: fields[11] as String?,
      isSynced: fields[12] as bool,
      lastSyncedAt: fields[13] as DateTime?,
      isInstallment: fields[14] as bool? ?? false,
      installmentCount: fields[15] as int? ?? 1,
      installmentDates: (fields[16] as List?)?.cast<DateTime>(),
      installmentAmounts: (fields[17] as List?)?.cast<double>(),
      installmentPaidCount: fields[18] as int?,
      installmentStatuses: (fields[19] as List?)?.cast<String>(),
      installmentPaidAts: (fields[20] as List?)?.cast<DateTime>(),
      deletedAt: fields[21] as DateTime?,
      invoiceNumber: fields[22] as int?,
      isCashSale: fields[23] as bool,
      unitSalePrice: fields[24] as double?,
      unitCostPrice: fields[25] as double?,
    );
  }

  @override
  void write(BinaryWriter writer, Debt obj) {
    writer
      ..writeByte(26)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.customerId)
      ..writeByte(2)
      ..write(obj.amount)
      ..writeByte(3)
      ..write(obj.productId)
      ..writeByte(4)
      ..write(obj.productName)
      ..writeByte(5)
      ..write(obj.productQuantity)
      ..writeByte(6)
      ..write(obj.userId)
      ..writeByte(7)
      ..write(obj.createdAt)
      ..writeByte(8)
      ..write(obj.dueDate)
      ..writeByte(9)
      ..write(obj.paidAmount)
      ..writeByte(10)
      ..write(obj.isPaid)
      ..writeByte(11)
      ..write(obj.notes)
      ..writeByte(12)
      ..write(obj.isSynced)
      ..writeByte(13)
      ..write(obj.lastSyncedAt)
      ..writeByte(14)
      ..write(obj.isInstallment)
      ..writeByte(15)
      ..write(obj.installmentCount)
      ..writeByte(16)
      ..write(obj.installmentDates)
      ..writeByte(17)
      ..write(obj.installmentAmounts)
      ..writeByte(18)
      ..write(obj.installmentPaidCount)
      ..writeByte(19)
      ..write(obj.installmentStatuses)
      ..writeByte(20)
      ..write(obj.installmentPaidAts)
      ..writeByte(21)
      ..write(obj.deletedAt)
      ..writeByte(22)
      ..write(obj.invoiceNumber)
      ..writeByte(23)
      ..write(obj.isCashSale)
      ..writeByte(24)
      ..write(obj.unitSalePrice)
      ..writeByte(25)
      ..write(obj.unitCostPrice);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DebtAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
