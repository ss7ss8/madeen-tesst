// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'settings.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class AppSettingsAdapter extends TypeAdapter<AppSettings> {
  @override
  final int typeId = 4;

  @override
  AppSettings read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return AppSettings(
      storeName: fields[0] as String,
      storeLogoPath: fields[1] as String?,
      themeColorHex: fields[2] as String,
      fontFamily: fields[3] as String,
      darkMode: fields[4] as bool,
      backgroundType: fields[5] as String,
      backgroundColorHex: fields[6] as String?,
      backgroundGradientStartHex: fields[7] as String?,
      backgroundGradientEndHex: fields[8] as String?,
      backgroundImagePath: fields[9] as String?,
      autoBackup: fields[10] as bool,
      lastBackupAt: fields[11] as DateTime?,
      userId: fields[12] as String?,
      notificationsEnabled: fields[13] as bool,
      immediateNotificationsEnabled: fields[14] as bool,
      dailyNotificationsEnabled: fields[15] as bool,
      weeklyNotificationsEnabled: fields[16] as bool,
      lateThresholdDays: fields[17] as int,
      autoLockTimeoutSeconds: fields[18] as int,
      biometricEnabled: fields[19] as bool,
      pinEnabled: fields[20] as bool,
      pinCode: fields[21] as String?,
      printerType: fields[22] as String,
      storePhone: fields[23] as String?,
      notifyBeforeInstallment: fields[24] as bool,
      lastInvoiceNumber: fields[25] as int,
      lastPrinterMac: fields[26] as String?,
      lastPrinterName: fields[27] as String?,
      lowProfitMarginThreshold: fields[28] as double? ?? 0.10,
      amountDisplayFormat: fields[29] as String? ?? 'full',
    );
  }

  @override
  void write(BinaryWriter writer, AppSettings obj) {
    writer
      ..writeByte(30)
      ..writeByte(0)
      ..write(obj.storeName)
      ..writeByte(1)
      ..write(obj.storeLogoPath)
      ..writeByte(2)
      ..write(obj.themeColorHex)
      ..writeByte(3)
      ..write(obj.fontFamily)
      ..writeByte(4)
      ..write(obj.darkMode)
      ..writeByte(5)
      ..write(obj.backgroundType)
      ..writeByte(6)
      ..write(obj.backgroundColorHex)
      ..writeByte(7)
      ..write(obj.backgroundGradientStartHex)
      ..writeByte(8)
      ..write(obj.backgroundGradientEndHex)
      ..writeByte(9)
      ..write(obj.backgroundImagePath)
      ..writeByte(10)
      ..write(obj.autoBackup)
      ..writeByte(11)
      ..write(obj.lastBackupAt)
      ..writeByte(12)
      ..write(obj.userId)
      ..writeByte(13)
      ..write(obj.notificationsEnabled)
      ..writeByte(14)
      ..write(obj.immediateNotificationsEnabled)
      ..writeByte(15)
      ..write(obj.dailyNotificationsEnabled)
      ..writeByte(16)
      ..write(obj.weeklyNotificationsEnabled)
      ..writeByte(17)
      ..write(obj.lateThresholdDays)
      ..writeByte(18)
      ..write(obj.autoLockTimeoutSeconds)
      ..writeByte(19)
      ..write(obj.biometricEnabled)
      ..writeByte(20)
      ..write(obj.pinEnabled)
      ..writeByte(21)
      ..write(obj.pinCode)
      ..writeByte(22)
      ..write(obj.printerType)
      ..writeByte(23)
      ..write(obj.storePhone)
      ..writeByte(24)
      ..write(obj.notifyBeforeInstallment)
      ..writeByte(25)
      ..write(obj.lastInvoiceNumber)
      ..writeByte(26)
      ..write(obj.lastPrinterMac)
      ..writeByte(27)
      ..write(obj.lastPrinterName)
      ..writeByte(28)
      ..write(obj.lowProfitMarginThreshold)
      ..writeByte(29)
      ..write(obj.amountDisplayFormat);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AppSettingsAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
