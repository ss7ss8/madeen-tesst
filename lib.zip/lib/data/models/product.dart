import 'package:hive/hive.dart';

part 'product.g.dart';

@HiveType(typeId: 2)
class Product extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  double purchasePrice;

  @HiveField(3)
  double salePrice;

  @HiveField(4)
  int quantity;

  @HiveField(5)
  final String userId;

  @HiveField(6)
  final DateTime createdAt;

  @HiveField(7)
  DateTime updatedAt;

  @HiveField(8)
  String? imageUrl;

  @HiveField(9)
  String? category;

  @HiveField(10)
  bool isSynced;

  @HiveField(11)
  DateTime? lastSyncedAt;

  @HiveField(12)
  DateTime? deletedAt;

  @HiveField(13)
  String? barcode;

  Product({
    required this.id,
    required this.name,
    required this.purchasePrice,
    required this.salePrice,
    required this.quantity,
    required this.userId,
    required this.createdAt,
    required this.updatedAt,
    this.imageUrl,
    this.category,
    this.isSynced = false,
    this.lastSyncedAt,
    this.deletedAt,
    this.barcode,
  });

  double get profit => salePrice - purchasePrice;

  double get profitMargin => purchasePrice > 0 ? profit / purchasePrice : 0;

  bool get isInStock => quantity > 0;

  bool get isLowStock => quantity > 0 && quantity <= 5;

  Product copyWith({
    String? id,
    String? name,
    double? purchasePrice,
    double? salePrice,
    int? quantity,
    String? userId,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? imageUrl,
    String? category,
    bool? isSynced,
    DateTime? lastSyncedAt,
    DateTime? deletedAt,
    String? barcode,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      purchasePrice: purchasePrice ?? this.purchasePrice,
      salePrice: salePrice ?? this.salePrice,
      quantity: quantity ?? this.quantity,
      userId: userId ?? this.userId,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      imageUrl: imageUrl ?? this.imageUrl,
      category: category ?? this.category,
      isSynced: isSynced ?? this.isSynced,
      lastSyncedAt: lastSyncedAt ?? this.lastSyncedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      barcode: barcode ?? this.barcode,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'price_per_unit': purchasePrice,
      'sale_price': salePrice,
      'stock_quantity': quantity,
      'user_id': userId,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'image_url': imageUrl,
      'category': category,
      'barcode': barcode,
      'deleted_at': deletedAt?.toIso8601String(),
    };
  }

  factory Product.fromJson(Map<String, dynamic> json) {
    final priceRaw = json['price_per_unit'] ?? json['purchase_price'] ?? 0;
    final purchasePrice = (priceRaw as num).toDouble();
    final saleRaw = json.containsKey('sale_price')
        ? json['sale_price']
        : json['salePrice'] ?? priceRaw;
    final salePrice = (saleRaw as num).toDouble();
    final quantityRaw = json['stock_quantity'] ?? json['quantity'] ?? 0;

    return Product(
      id: json['id'] as String,
      name: json['name'] as String,
      purchasePrice: purchasePrice,
      salePrice: salePrice,
      quantity: (quantityRaw as num).toInt(),
      userId: json['user_id'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
      imageUrl: json['image_url'] as String?,
      category: json['category'] as String?,
      barcode: json['barcode'] as String?,
      deletedAt: json['deleted_at'] != null
          ? DateTime.parse(json['deleted_at'] as String)
          : null,
    );
  }

  @override
  String toString() {
    return 'Product(id: $id, name: $name, quantity: $quantity)';
  }
}
