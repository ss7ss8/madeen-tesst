import 'package:hive/hive.dart';

part 'audit_log.g.dart';

@HiveType(typeId: 5)
class AuditLog extends HiveObject {
  @HiveField(0)
  final String id;

  /// entity/table name: customers, debts, products, payments, settings, etc
  @HiveField(1)
  final String entity;

  /// affected record id (if any)
  @HiveField(2)
  final String? recordId;

  /// operation type: add_debt, pay_debt, delete_debt, add_customer, delete_customer, update_customer, ...
  @HiveField(3)
  final String actionType;

  /// arbitrary details
  @HiveField(4)
  final String payloadJson;

  @HiveField(5)
  final DateTime createdAt;

  @HiveField(6)
  final String userId;

  /// to make it easier to correlate with sync queue, optionally store operationId
  @HiveField(7)
  final String? operationId;

  AuditLog({
    required this.id,
    required this.entity,
    this.recordId,
    required this.actionType,
    required this.payloadJson,
    required this.createdAt,
    required this.userId,
    this.operationId,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'entity': entity,
      'record_id': recordId,
      'action_type': actionType,
      'payload_json': payloadJson,
      'created_at': createdAt.toIso8601String(),
      'user_id': userId,
      'operation_id': operationId,
    };
  }

  factory AuditLog.fromJson(Map<String, dynamic> json) {
    return AuditLog(
      id: json['id'] as String,
      entity: json['entity'] as String,
      recordId: json['record_id'] as String?,
      actionType: json['action_type'] as String,
      payloadJson: json['payload_json'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      userId: json['user_id'] as String,
      operationId: json['operation_id'] as String?,
    );
  }
}
