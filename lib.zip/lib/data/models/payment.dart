import 'package:hive/hive.dart';

part 'payment.g.dart';

@HiveType(typeId: 3)
class Payment extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String debtId;

  @HiveField(2)
  final double amount;

  @HiveField(3)
  final String userId;

  @HiveField(4)
  final DateTime createdAt;

  @HiveField(5)
  String? notes;

  @HiveField(6)
  bool isSynced;

  @HiveField(7)
  DateTime? lastSyncedAt;

  @HiveField(8)
  DateTime? deletedAt;

  Payment({
    required this.id,
    required this.debtId,
    required this.amount,
    required this.userId,
    required this.createdAt,
    this.notes,
    this.isSynced = false,
    this.lastSyncedAt,
    this.deletedAt,
  });

  Payment copyWith({
    String? id,
    String? debtId,
    double? amount,
    String? userId,
    DateTime? createdAt,
    String? notes,
    bool? isSynced,
    DateTime? lastSyncedAt,
    DateTime? deletedAt,
  }) {
    return Payment(
      id: id ?? this.id,
      debtId: debtId ?? this.debtId,
      amount: amount ?? this.amount,
      userId: userId ?? this.userId,
      createdAt: createdAt ?? this.createdAt,
      notes: notes ?? this.notes,
      isSynced: isSynced ?? this.isSynced,
      lastSyncedAt: lastSyncedAt ?? this.lastSyncedAt,
      deletedAt: deletedAt ?? this.deletedAt,
    );
  }

  Map<String, dynamic> toJson({String? customerId}) {
    return {
      'id': id,
      'debt_id': debtId,
      'customer_id': customerId,
      'amount': amount,
      'user_id': userId,
      'created_at': createdAt.toIso8601String(),
      'notes': notes,
      'deleted_at': deletedAt?.toIso8601String(),
    };
  }

  factory Payment.fromJson(Map<String, dynamic> json) {
    return Payment(
      id: json['id'] as String,
      debtId: json['debt_id'] as String,
      amount: (json['amount'] as num).toDouble(),
      userId: json['user_id'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      notes: json['notes'] as String?,
      deletedAt: json['deleted_at'] != null
          ? DateTime.parse(json['deleted_at'] as String)
          : null,
    );
  }

  @override
  String toString() {
    return 'Payment(id: $id, debtId: $debtId, amount: $amount)';
  }
}