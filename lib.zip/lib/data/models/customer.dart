import 'package:hive/hive.dart';

part 'customer.g.dart';

@HiveType(typeId: 0)
class Customer extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  String? phone;

  @HiveField(3)
  final String userId;

  @HiveField(4)
  final DateTime createdAt;

  @HiveField(5)
  DateTime updatedAt;

  @HiveField(6)
  String? imageUrl;

  @HiveField(7)
  bool isSynced;

  @HiveField(8)
  DateTime? lastSyncedAt;

  /// Optional: maximum allowed debt for this customer.
  /// Used for "limit warning" notifications.
  @HiveField(9)
  double? maxDebtLimit;

  @HiveField(10)
  DateTime? deletedAt;

  Customer({
    required this.id,
    required this.name,
    this.phone,
    required this.userId,
    required this.createdAt,
    required this.updatedAt,
    this.imageUrl,
    this.isSynced = false,
    this.lastSyncedAt,
    this.maxDebtLimit,
    this.deletedAt,
  });

  Customer copyWith({
    String? id,
    String? name,
    String? phone,
    String? userId,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? imageUrl,
    bool? isSynced,
    DateTime? lastSyncedAt,
    double? maxDebtLimit,
    DateTime? deletedAt,
  }) {
    return Customer(
      id: id ?? this.id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      userId: userId ?? this.userId,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      imageUrl: imageUrl ?? this.imageUrl,
      isSynced: isSynced ?? this.isSynced,
      lastSyncedAt: lastSyncedAt ?? this.lastSyncedAt,
      maxDebtLimit: maxDebtLimit ?? this.maxDebtLimit,
      deletedAt: deletedAt ?? this.deletedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'user_id': userId,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'image_url': imageUrl,
      'max_debt_limit': maxDebtLimit,
      'deleted_at': deletedAt?.toIso8601String(),
    };
  }

  factory Customer.fromJson(Map<String, dynamic> json) {
    return Customer(
      id: json['id'] as String,
      name: json['name'] as String,
      phone: json['phone'] as String?,
      userId: json['user_id'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
      imageUrl: json['image_url'] as String?,
      maxDebtLimit: json['max_debt_limit'] != null
          ? (json['max_debt_limit'] as num).toDouble()
          : null,
      deletedAt: json['deleted_at'] != null
          ? DateTime.parse(json['deleted_at'] as String)
          : null,
    );
  }

  @override
  String toString() {
    return 'Customer(id: $id, name: $name, phone: $phone)';
  }
}
