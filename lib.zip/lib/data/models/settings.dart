import 'package:hive/hive.dart';

part 'settings.g.dart';

@HiveType(typeId: 4)
class AppSettings extends HiveObject {
  @HiveField(0)
  String storeName;

  @HiveField(1)
  String? storeLogoPath;

  @HiveField(2)
  String themeColorHex;

  @HiveField(3)
  String fontFamily;

  @HiveField(4)
  bool darkMode;

  @HiveField(5)
  String backgroundType; // 'solid', 'gradient', 'image'

  @HiveField(6)
  String? backgroundColorHex;

  @HiveField(7)
  String? backgroundGradientStartHex;

  @HiveField(8)
  String? backgroundGradientEndHex;

  @HiveField(9)
  String? backgroundImagePath;

  @HiveField(10)
  bool autoBackup;

  @HiveField(11)
  DateTime? lastBackupAt;

  @HiveField(12)
  String? userId;

  @HiveField(13)
  bool notificationsEnabled;

  @HiveField(14)
  bool immediateNotificationsEnabled;

  @HiveField(15)
  bool dailyNotificationsEnabled;

  @HiveField(16)
  bool weeklyNotificationsEnabled;

  /// Days threshold to consider a customer late (7 / 14 / 30)
  @HiveField(17)
  int lateThresholdDays;

  /// Security: auto lock timeout in seconds (0 = immediate, -1 = never)
  @HiveField(18)
  int autoLockTimeoutSeconds;

  /// Whether biometric auth is enabled
  @HiveField(19)
  bool biometricEnabled;

  /// Whether PIN fallback is enabled
  @HiveField(20)
  bool pinEnabled;

  /// Encrypted PIN stored securely (managed by flutter_secure_storage)
  @HiveField(21)
  String? pinCode;

  /// Printer type: 'a4', 'thermal_80mm', 'thermal_58mm'
  @HiveField(22)
  String printerType;

  /// Store phone number for invoices
  @HiveField(23)
  String? storePhone;

  /// Notify 1 day before installment due date
  @HiveField(24)
  bool notifyBeforeInstallment;

  /// Last used invoice number (incremented for each new debt)
  @HiveField(25)
  int lastInvoiceNumber;

  /// MAC address of the last connected Bluetooth thermal printer (auto-reconnect)
  @HiveField(26)
  String? lastPrinterMac;

  /// Display name of the last connected Bluetooth thermal printer
  @HiveField(27)
  String? lastPrinterName;

  /// Low profit margin threshold (0.0 to 1.0, default 0.10 = 10%)
  /// Products below this margin will show warning indicator
  @HiveField(28)
  double lowProfitMarginThreshold;

  /// Amount display format: 'full' | 'thousands_short'
  /// 'full' shows full number with commas, 'thousands_short' shows e.g. "55 ألف"
  @HiveField(29)
  String amountDisplayFormat;

  AppSettings({
    this.storeName = 'متجري',
    this.storeLogoPath,
    this.themeColorHex = '0xFF2563EB',
    this.fontFamily = 'IBM Plex Sans Arabic',
    this.darkMode = false,
    this.backgroundType = 'solid',
    this.backgroundColorHex = '0xFFF8FAFC',
    this.backgroundGradientStartHex = '0xFF667EEA',
    this.backgroundGradientEndHex = '0xFF764BA2',
    this.backgroundImagePath,
    this.autoBackup = true,
    this.lastBackupAt,
    this.userId,
    this.notificationsEnabled = false,
    this.immediateNotificationsEnabled = true,
    this.dailyNotificationsEnabled = true,
    this.weeklyNotificationsEnabled = true,
    this.lateThresholdDays = 30,
    this.autoLockTimeoutSeconds = 60,
    this.biometricEnabled = false,
    this.pinEnabled = false,
    this.pinCode,
    this.printerType = 'a4',
    this.storePhone,
    this.notifyBeforeInstallment = true,
    this.lastInvoiceNumber = 1000,
    this.lastPrinterMac,
    this.lastPrinterName,
    this.lowProfitMarginThreshold = 0.10,
    this.amountDisplayFormat = 'full',
  });

  AppSettings copyWith({
    String? storeName,
    String? storeLogoPath,
    String? themeColorHex,
    String? fontFamily,
    bool? darkMode,
    String? backgroundType,
    String? backgroundColorHex,
    String? backgroundGradientStartHex,
    String? backgroundGradientEndHex,
    String? backgroundImagePath,
    bool? autoBackup,
    DateTime? lastBackupAt,
    String? userId,
    bool? notificationsEnabled,
    bool? immediateNotificationsEnabled,
    bool? dailyNotificationsEnabled,
    bool? weeklyNotificationsEnabled,
    int? lateThresholdDays,
    int? autoLockTimeoutSeconds,
    bool? biometricEnabled,
    bool? pinEnabled,
    String? pinCode,
    String? printerType,
    String? storePhone,
    bool? notifyBeforeInstallment,
    int? lastInvoiceNumber,
    String? lastPrinterMac,
    String? lastPrinterName,
    double? lowProfitMarginThreshold,
    String? amountDisplayFormat,
  }) {
    return AppSettings(
      storeName: storeName ?? this.storeName,
      storeLogoPath: storeLogoPath ?? this.storeLogoPath,
      themeColorHex: themeColorHex ?? this.themeColorHex,
      fontFamily: fontFamily ?? this.fontFamily,
      darkMode: darkMode ?? this.darkMode,
      backgroundType: backgroundType ?? this.backgroundType,
      backgroundColorHex: backgroundColorHex ?? this.backgroundColorHex,
      backgroundGradientStartHex:
          backgroundGradientStartHex ?? this.backgroundGradientStartHex,
      backgroundGradientEndHex:
          backgroundGradientEndHex ?? this.backgroundGradientEndHex,
      backgroundImagePath: backgroundImagePath ?? this.backgroundImagePath,
      autoBackup: autoBackup ?? this.autoBackup,
      lastBackupAt: lastBackupAt ?? this.lastBackupAt,
      userId: userId ?? this.userId,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      immediateNotificationsEnabled:
          immediateNotificationsEnabled ?? this.immediateNotificationsEnabled,
      dailyNotificationsEnabled:
          dailyNotificationsEnabled ?? this.dailyNotificationsEnabled,
      weeklyNotificationsEnabled:
          weeklyNotificationsEnabled ?? this.weeklyNotificationsEnabled,
      lateThresholdDays: lateThresholdDays ?? this.lateThresholdDays,
      autoLockTimeoutSeconds:
          autoLockTimeoutSeconds ?? this.autoLockTimeoutSeconds,
      biometricEnabled: biometricEnabled ?? this.biometricEnabled,
      pinEnabled: pinEnabled ?? this.pinEnabled,
      pinCode: pinCode ?? this.pinCode,
      printerType: printerType ?? this.printerType,
      storePhone: storePhone ?? this.storePhone,
      notifyBeforeInstallment:
          notifyBeforeInstallment ?? this.notifyBeforeInstallment,
      lastInvoiceNumber: lastInvoiceNumber ?? this.lastInvoiceNumber,
      lastPrinterMac: lastPrinterMac ?? this.lastPrinterMac,
      lastPrinterName: lastPrinterName ?? this.lastPrinterName,
      lowProfitMarginThreshold:
          lowProfitMarginThreshold ?? this.lowProfitMarginThreshold,
      amountDisplayFormat:
          amountDisplayFormat ?? this.amountDisplayFormat,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'store_name': storeName,
      'store_logo_path': storeLogoPath,
      'theme_color_hex': themeColorHex,
      'font_family': fontFamily,
      'dark_mode': darkMode,
      'background_type': backgroundType,
      'background_color_hex': backgroundColorHex,
      'background_gradient_start_hex': backgroundGradientStartHex,
      'background_gradient_end_hex': backgroundGradientEndHex,
      'background_image_path': backgroundImagePath,
      'auto_backup': autoBackup,
      'last_backup_at': lastBackupAt?.toIso8601String(),
      'user_id': userId,
      'notifications_enabled': notificationsEnabled,
      'immediate_notifications_enabled': immediateNotificationsEnabled,
      'daily_notifications_enabled': dailyNotificationsEnabled,
      'weekly_notifications_enabled': weeklyNotificationsEnabled,
      'late_threshold_days': lateThresholdDays,
      'auto_lock_timeout_seconds': autoLockTimeoutSeconds,
      'biometric_enabled': biometricEnabled,
      'pin_enabled': pinEnabled,
      'pin_code': pinCode,
      'printer_type': printerType,
      'store_phone': storePhone,
      'notify_before_installment': notifyBeforeInstallment,
      'last_invoice_number': lastInvoiceNumber,
      'last_printer_mac': lastPrinterMac,
      'last_printer_name': lastPrinterName,
      'low_profit_margin_threshold': lowProfitMarginThreshold,
      'amount_display_format': amountDisplayFormat,
    };
  }

  factory AppSettings.fromJson(Map<String, dynamic> json) {
    return AppSettings(
      storeName: json['store_name'] as String? ?? 'متجري',
      storeLogoPath: json['store_logo_path'] as String?,
      themeColorHex: json['theme_color_hex'] as String? ?? '0xFF2563EB',
      fontFamily: json['font_family'] as String? ?? 'IBM Plex Sans Arabic',
      darkMode: json['dark_mode'] as bool? ?? false,
      backgroundType: json['background_type'] as String? ?? 'solid',
      backgroundColorHex: json['background_color_hex'] as String?,
      backgroundGradientStartHex:
          json['background_gradient_start_hex'] as String?,
      backgroundGradientEndHex: json['background_gradient_end_hex'] as String?,
      backgroundImagePath: json['background_image_path'] as String?,
      autoBackup: json['auto_backup'] as bool? ?? true,
      lastBackupAt: json['last_backup_at'] != null
          ? DateTime.parse(json['last_backup_at'] as String)
          : null,
      userId: json['user_id'] as String?,
      notificationsEnabled: json['notifications_enabled'] as bool? ?? false,
      immediateNotificationsEnabled:
          json['immediate_notifications_enabled'] as bool? ?? true,
      dailyNotificationsEnabled:
          json['daily_notifications_enabled'] as bool? ?? true,
      weeklyNotificationsEnabled:
          json['weekly_notifications_enabled'] as bool? ?? true,
      lateThresholdDays: (json['late_threshold_days'] as num?)?.toInt() ?? 30,
      autoLockTimeoutSeconds:
          (json['auto_lock_timeout_seconds'] as num?)?.toInt() ?? 60,
      biometricEnabled: json['biometric_enabled'] as bool? ?? false,
      pinEnabled: json['pin_enabled'] as bool? ?? false,
      pinCode: json['pin_code'] as String?,
      printerType: json['printer_type'] as String? ?? 'a4',
      storePhone: json['store_phone'] as String?,
      notifyBeforeInstallment:
          json['notify_before_installment'] as bool? ?? true,
      lastInvoiceNumber: (json['last_invoice_number'] as num?)?.toInt() ?? 1000,
      lastPrinterMac: json['last_printer_mac'] as String?,
      lastPrinterName: json['last_printer_name'] as String?,
      lowProfitMarginThreshold:
          (json['low_profit_margin_threshold'] as num?)?.toDouble() ?? 0.10,
      amountDisplayFormat:
          json['amount_display_format'] as String? ?? 'full',
    );
  }

  @override
  String toString() {
    return 'AppSettings(storeName: $storeName, darkMode: $darkMode, amountDisplayFormat: $amountDisplayFormat)';
  }
}
