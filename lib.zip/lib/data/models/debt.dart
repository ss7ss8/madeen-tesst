import 'package:hive/hive.dart';

part 'debt.g.dart';

@HiveType(typeId: 1)
class Debt extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String customerId;

  @HiveField(2)
  final double amount;

  @HiveField(3)
  String? productId;

  @HiveField(4)
  String? productName;

  @HiveField(5)
  int productQuantity;

  @HiveField(6)
  final String userId;

  @HiveField(7)
  final DateTime createdAt;

  @HiveField(8)
  DateTime? dueDate;

  @HiveField(9)
  double paidAmount;

  @HiveField(10)
  bool isPaid;

  @HiveField(11)
  String? notes;

  @HiveField(12)
  bool isSynced;

  @HiveField(13)
  DateTime? lastSyncedAt;

  @HiveField(14)
  bool isInstallment;

  @HiveField(15)
  int installmentCount;

  @HiveField(16)
  List<DateTime>? installmentDates;

  @HiveField(17)
  List<double>? installmentAmounts;

  @HiveField(18)
  int? installmentPaidCount;

  @HiveField(19)
  List<String>? installmentStatuses;

  @HiveField(20)
  List<DateTime>? installmentPaidAts;

  @HiveField(21)
  DateTime? deletedAt;

  /// Sequential invoice number (e.g., 1001, 1002...) for user-friendly search
  @HiveField(22)
  int? invoiceNumber;

  @HiveField(23)
  bool isCashSale;

  /// Unit sale price at the time of sale (for profit calculation)
  @HiveField(24)
  double? unitSalePrice;

  /// Unit cost/purchase price at the time of sale (for profit calculation)
  @HiveField(25)
  double? unitCostPrice;

  Debt({
    required this.id,
    required this.customerId,
    required this.amount,
    this.productId,
    this.productName,
    this.productQuantity = 1,
    required this.userId,
    required this.createdAt,
    this.dueDate,
    this.paidAmount = 0,
    this.isPaid = false,
    this.notes,
    this.isSynced = false,
    this.lastSyncedAt,
    this.isInstallment = false,
    this.installmentCount = 1,
    this.installmentDates,
    this.installmentAmounts,
    this.installmentPaidCount,
    this.installmentStatuses,
    this.installmentPaidAts,
    this.deletedAt,
    this.invoiceNumber,
    this.isCashSale = false,
    this.unitSalePrice,
    this.unitCostPrice,
  });

  double get remainingAmount => amount - paidAmount;

  double get paidPercentage => amount > 0 ? paidAmount / amount : 0;

  bool get isPartialPaid => paidAmount > 0 && paidAmount < amount;

  /// Total profit from this sale (only valid if prices were captured)
  double get totalProfit {
    if (unitSalePrice == null || unitCostPrice == null) return 0;
    return (unitSalePrice! - unitCostPrice!) * productQuantity;
  }

  /// Profit margin percentage (0.0 to 1.0+)
  double get profitMargin {
    if (unitCostPrice == null || unitCostPrice == 0) return 0;
    if (unitSalePrice == null) return 0;
    return (unitSalePrice! - unitCostPrice!) / unitCostPrice!;
  }

  /// Whether this debt has valid price data for profit calculations
  bool get hasPriceData => unitSalePrice != null && unitCostPrice != null;

  Debt copyWith({
    String? id,
    String? customerId,
    double? amount,
    String? productId,
    String? productName,
    int? productQuantity,
    String? userId,
    DateTime? createdAt,
    DateTime? dueDate,
    double? paidAmount,
    bool? isPaid,
    String? notes,
    bool? isSynced,
    DateTime? lastSyncedAt,
    bool? isInstallment,
    int? installmentCount,
    List<DateTime>? installmentDates,
    List<double>? installmentAmounts,
    int? installmentPaidCount,
    List<String>? installmentStatuses,
    List<DateTime>? installmentPaidAts,
    DateTime? deletedAt,
    int? invoiceNumber,
    bool? isCashSale,
    double? unitSalePrice,
    double? unitCostPrice,
  }) {
    return Debt(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      amount: amount ?? this.amount,
      productId: productId ?? this.productId,
      productName: productName ?? this.productName,
      productQuantity: productQuantity ?? this.productQuantity,
      userId: userId ?? this.userId,
      createdAt: createdAt ?? this.createdAt,
      dueDate: dueDate ?? this.dueDate,
      paidAmount: paidAmount ?? this.paidAmount,
      isPaid: isPaid ?? this.isPaid,
      notes: notes ?? this.notes,
      isSynced: isSynced ?? this.isSynced,
      lastSyncedAt: lastSyncedAt ?? this.lastSyncedAt,
      isInstallment: isInstallment ?? this.isInstallment,
      installmentCount: installmentCount ?? this.installmentCount,
      installmentDates: installmentDates ?? this.installmentDates,
      installmentAmounts: installmentAmounts ?? this.installmentAmounts,
      installmentPaidCount: installmentPaidCount ?? this.installmentPaidCount,
      installmentStatuses: installmentStatuses ?? this.installmentStatuses,
      installmentPaidAts: installmentPaidAts ?? this.installmentPaidAts,
      deletedAt: deletedAt ?? this.deletedAt,
      invoiceNumber: invoiceNumber ?? this.invoiceNumber,
      isCashSale: isCashSale ?? this.isCashSale,
      unitSalePrice: unitSalePrice ?? this.unitSalePrice,
      unitCostPrice: unitCostPrice ?? this.unitCostPrice,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': userId,
      'customer_id': customerId,
      'total_amount': amount,
      'paid_amount': paidAmount,
      'status': isPaid ? 'paid' : (paidAmount > 0 ? 'partial' : 'active'),
      'is_installment': isInstallment,
      'installment_count': installmentCount,
      'installment_paid_count': installmentPaidCount,
      // Installment arrays — serialized as ISO strings / numbers so they
      // round-trip through the JSONB columns added by restore_fix_migration.sql.
      'installment_dates': installmentDates
          ?.map((d) => d.toIso8601String())
          .toList(),
      'installment_amounts': installmentAmounts,
      'installment_statuses': installmentStatuses,
      'installment_paid_ats': installmentPaidAts
          ?.map((d) => d.toIso8601String())
          .toList(),
      // Product info (for debts linked to inventory products)
      'product_id': productId,
      'product_name': productName,
      'product_quantity': productQuantity,
      'invoice_number': invoiceNumber,
      'due_date': dueDate?.toIso8601String(),
      'notes': notes,
      'last_synced_at': lastSyncedAt?.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
      'deleted_at': deletedAt?.toIso8601String(),
      'is_cash_sale': isCashSale,
      'unit_sale_price': unitSalePrice,
      'unit_cost_price': unitCostPrice,
    };
  }

  factory Debt.fromJson(Map<String, dynamic> json) {
    final amount = ((json['total_amount'] ?? json['amount']) as num).toDouble();
    final paidAmount = (json['paid_amount'] as num?)?.toDouble() ?? 0;
    final status = json['status'] as String?;
    final isPaid =
        json['is_paid'] as bool? ??
        status == 'paid' || (paidAmount >= amount && amount > 0);

    return Debt(
      id: json['id'] as String,
      customerId: json['customer_id'] as String,
      amount: amount,
      productId: json['product_id'] as String?,
      productName: json['product_name'] as String?,
      productQuantity: json['product_quantity'] as int? ?? 1,
      userId: json['user_id'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      dueDate: json['due_date'] != null
          ? DateTime.parse(json['due_date'] as String)
          : null,
      paidAmount: paidAmount,
      isPaid: isPaid,
      notes: json['notes'] as String?,
      isInstallment: json['is_installment'] as bool? ?? false,
      installmentCount: json['installment_count'] as int? ?? 1,
      installmentDates: (json['installment_dates'] as List<dynamic>?)
          ?.map((e) => DateTime.parse(e as String))
          .toList(),
      installmentAmounts: (json['installment_amounts'] as List<dynamic>?)
          ?.map((e) => (e as num).toDouble())
          .toList(),
      installmentPaidCount: json['installment_paid_count'] as int?,
      installmentStatuses: (json['installment_statuses'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
      installmentPaidAts: (json['installment_paid_ats'] as List<dynamic>?)
          ?.map((e) => DateTime.parse(e as String))
          .toList(),
      deletedAt: json['deleted_at'] != null
          ? DateTime.parse(json['deleted_at'] as String)
          : null,
      invoiceNumber: json['invoice_number'] as int?,
      isCashSale: json['is_cash_sale'] as bool? ?? false,
      unitSalePrice: (json['unit_sale_price'] as num?)?.toDouble(),
      unitCostPrice: (json['unit_cost_price'] as num?)?.toDouble(),
    );
  }

  @override
  String toString() {
    return 'Debt(id: $id, amount: $amount, customerId: $customerId, isPaid: $isPaid)';
  }
}
