import 'package:flutter/material.dart';
import '../../core/constants/colors.dart';
import 'dart:convert';
import 'dart:math';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../../core/utils/logger.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/customer.dart';
import '../models/debt.dart';
import '../models/product.dart';
import '../models/payment.dart';
import '../models/settings.dart';
import '../models/audit_log.dart';
import '../models/installment.dart';

class HiveService {
  static String _userId = '';
  static bool _boxesOpen = false;

  /// Mutex: prevents concurrent [switchUser] calls from racing.
  static bool _switching = false;

  static const String _settingsBoxName = 'settings';
  static const String _syncQueueBoxName = 'sync_queue';

  static String get _suffix => _userId.isEmpty ? '' : _userId.toLowerCase();
  static String get customersBox => 'customers$_suffix';
  static String get debtsBox => 'debts$_suffix';
  static String get productsBox => 'products$_suffix';
  static String get paymentsBox => 'payments$_suffix';
  static String get auditLogBox => 'audit_log$_suffix';

  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static const _encryptionKeyName = 'hive_encryption_key';

  /// Cache in-memory لـ cipher — يمنع قراءة Keystore في كل استدعاء.
  /// لا يُصفّر عند switchUser لأن المفتاح لا يتغير بتغيير المستخدم.
  static HiveCipher? _cipherCache;

  /// In-memory index for the sync queue: maps the compound dedup key
  /// `'${table}_$recordId'` → the Hive key of the corresponding queue
  /// entry. This replaces the old O(N) per-save scan that iterated over
  /// every key in the sync-queue box and called `.get(key)` for each —
  /// the root cause of the multi-second UI freezes (51–53s) reported
  /// when the queue grew to hundreds/thousands of entries.
  ///
  /// Lazily built on first use and kept in sync on every add/update/
  /// delete so dedup lookups are O(1) instead of O(N) Hive reads.
  static Map<String, dynamic>? _syncQueueIndex;
  static bool _syncQueueIndexReady = false;

  /// Returns the in-memory dedup index, building it once from the Hive
  /// box on first access. Subsequent calls are free.
  static Map<String, dynamic> _getSyncQueueIndex() {
    if (_syncQueueIndexReady && _syncQueueIndex != null) {
      return _syncQueueIndex!;
    }
    _syncQueueIndex = <String, dynamic>{};
    try {
      for (final key in _syncQueueBox.keys) {
        final item = _syncQueueBox.get(key);
        if (item == null) continue;
        final table = item['table']?.toString() ?? '';
        final recordId = item['record_id']?.toString() ?? '';
        if (table.isEmpty || recordId.isEmpty) continue;
        _syncQueueIndex!['${table}_$recordId'] = key;
      }
    } catch (_) {
      // Best-effort — an empty index just means no dedup, never a crash.
    }
    _syncQueueIndexReady = true;
    return _syncQueueIndex!;
  }

  /// Returns a 32-byte AES key, generating and storing one on first run.
  static Future<HiveCipher> _getCipher() async {
    if (_cipherCache != null) return _cipherCache!; // ← رجوع فوري بدون Keystore

    String? keyBase64 = await _storage.read(key: _encryptionKeyName);
    if (keyBase64 == null) {
      final key = List<int>.generate(32, (_) => Random.secure().nextInt(256));
      keyBase64 = base64UrlEncode(key);
      await _storage.write(key: _encryptionKeyName, value: keyBase64);
    }
    final keyBytes = base64Url.decode(keyBase64);
    _cipherCache = HiveAesCipher(keyBytes);
    return _cipherCache!;
  }

  /// Opens a Hive box with encryption, migrating old unencrypted data if needed.
  static Future<Box<T>> _openBoxWithMigration<T>({
    required String boxName,
    required HiveCipher cipher,
  }) async {
    final flagKey = '${boxName}_encrypted_v2';
    final migratingKey = '${boxName}_migrating';
    final migrated = await _storage.read(key: flagKey);

    if (migrated == 'true') {
      return Hive.openBox<T>(boxName, encryptionCipher: cipher);
    }

    try {
      final box = await Hive.openBox<T>(boxName, encryptionCipher: cipher);
      await _storage.write(key: flagKey, value: 'true');
      return box;
    } catch (_) {}

    try {
      final oldBox = await Hive.openBox<T>(boxName);
      final data = oldBox.toMap();
      final keys = oldBox.keys.toList();
      await oldBox.close();
      await _storage.write(key: migratingKey, value: 'true');
      await Hive.deleteBoxFromDisk(boxName);
      final newBox = await Hive.openBox<T>(boxName, encryptionCipher: cipher);
      for (final key in keys) {
        final value = data[key];
        if (value != null) {
          await newBox.put(key, value);
        }
      }
      await newBox.flush();
      await _storage.write(key: flagKey, value: 'true');
      await _storage.delete(key: migratingKey);
      return newBox;
    } catch (_) {
      final wasMigrating = await _storage.read(key: migratingKey);
      if (wasMigrating == 'true') {
        await _storage.delete(key: migratingKey);
      }
      await _storage.write(key: flagKey, value: 'true');
      return Hive.openBox<T>(boxName, encryptionCipher: cipher);
    }
  }

  static Future<void> init() async {
    await Hive.initFlutter();

    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(CustomerAdapter());
    }
    if (!Hive.isAdapterRegistered(1)) {
      Hive.registerAdapter(DebtAdapter());
    }
    if (!Hive.isAdapterRegistered(2)) {
      Hive.registerAdapter(ProductAdapter());
    }
    if (!Hive.isAdapterRegistered(3)) {
      Hive.registerAdapter(PaymentAdapter());
    }
    if (!Hive.isAdapterRegistered(4)) {
      Hive.registerAdapter(AppSettingsAdapter());
    }
    if (!Hive.isAdapterRegistered(5)) {
      Hive.registerAdapter(AuditLogAdapter());
    }

    final cipher = await _getCipher();

    // Shared boxes only — data boxes opened lazily by switchUser()
    await _openBoxWithMigration<AppSettings>(
      boxName: _settingsBoxName,
      cipher: cipher,
    );
    await Hive.openBox<Map>(_syncQueueBoxName);

    // CRITICAL: Reset _userId on every fresh init(). _userId is a static
    // field, so it survives Hive.close() (which only closes box handles,
    // not the Dart process). After a process restart, main() calls
    // HiveService.init() again — at that point _userId must be empty so
    // that the subsequent switchUser(currentUser.id) call actually opens
    // the user's boxes instead of being short-circuited by a stale
    // _userId from the previous process.
    _userId = '';

    _boxesOpen = true;
  }

  /// Migrates data from old shared box files (no userId suffix) to the
  /// current user's box names. Deletes shared files after migration.
  static Future<void> _migrateSharedDataBoxes(HiveCipher cipher) async {
    if (_userId.isEmpty) return;

    await _migrateSingleBox<Customer>('customers', customersBox, cipher);
    await _migrateSingleBox<Debt>('debts', debtsBox, cipher);
    await _migrateSingleBox<Product>('products', productsBox, cipher);
    await _migrateSingleBox<Payment>('payments', paymentsBox, cipher);
    await _migrateSingleBox<AuditLog>('audit_log', auditLogBox, cipher);
  }

  static Future<void> _migrateSingleBox<T>(
    String oldName,
    String newName,
    HiveCipher cipher,
  ) async {
    try {
      // Try opening with encryption first (all boxes use encryption since v2),
      // fall back to unencrypted for legacy migration.
      late Box<T> oldBox;
      try {
        oldBox = await Hive.openBox<T>(oldName, encryptionCipher: cipher);
      } catch (_) {
        try {
          oldBox = await Hive.openBox<T>(oldName);
        } catch (_) {
          return; // Box doesn't exist — nothing to migrate
        }
      }

      if (oldBox.isEmpty) {
        await oldBox.close();
        await Hive.deleteBoxFromDisk(oldName);
        return;
      }

      final data = oldBox.toMap();
      await oldBox.close();

      await Hive.deleteBoxFromDisk(oldName);

      // Write into new user-specific box
      final newBox = await Hive.openBox<T>(newName, encryptionCipher: cipher);
      for (final entry in data.entries) {
        await newBox.put(entry.key, entry.value);
      }
      await newBox.flush();

      appLogger.info('Migrated $oldName → $newName (${data.length} items)');
    } catch (_) {
      // Box doesn't exist or is already migrated — fine
    }
  }

  /// Switches Hive to a specific user's data boxes.
  /// Closes and deletes the previous user's boxes, opens the new user's boxes.
  /// Call this AFTER auth resolves and BEFORE any provider reads data.
  /// This method is mutex-protected: concurrent calls are serialized.
  static Future<void> switchUser(String? userId) async {
    if (!_boxesOpen) return;

    // Serialize concurrent calls: wait if another switch is in progress.
    while (_switching) {
      await Future.delayed(const Duration(milliseconds: 10));
    }

    // Normalize the incoming userId once. Comparison and storage both use
    // this normalized form so the early-return guard is case-insensitive
    // and matches the suffix used for box names. This prevents the
    // "delete-on-second-call" bug where a raw userId (e.g. mixed case)
    // would not match the already-lowercased _userId, causing the
    // previous user's boxes to be wiped on a duplicate auth event.
    final normalizedNewUserId = (userId ?? '').toLowerCase();
    if (_userId == normalizedNewUserId) return;

    _switching = true;
    try {
      // Invalidate settings cache — boxes are about to be swapped.
      // لا تُصفّر _cipherCache — المفتاح لا يتغير بتغيير المستخدم
      _settingsCache = null;

      // Close current user's data boxes
      await _closeBox('customers$_suffix');
      await _closeBox('debts$_suffix');
      await _closeBox('products$_suffix');
      await _closeBox('payments$_suffix');
      await _closeBox('audit_log$_suffix');

      // Delete previous user's box files from disk
      if (_userId.isNotEmpty) {
        await Hive.deleteBoxFromDisk('customers$_suffix');
        await Hive.deleteBoxFromDisk('debts$_suffix');
        await Hive.deleteBoxFromDisk('products$_suffix');
        await Hive.deleteBoxFromDisk('payments$_suffix');
        await Hive.deleteBoxFromDisk('audit_log$_suffix');
      }

      _userId = normalizedNewUserId;

      if (_userId.isNotEmpty) {
        final cipher = await _getCipher();
        await Hive.openBox<Customer>(customersBox, encryptionCipher: cipher);
        await Hive.openBox<Debt>(debtsBox, encryptionCipher: cipher);
        await _openBoxWithMigration<Product>(
          boxName: productsBox,
          cipher: cipher,
        );
        await Hive.openBox<Payment>(paymentsBox, encryptionCipher: cipher);
        await Hive.openBox<AuditLog>(auditLogBox, encryptionCipher: cipher);

        // Migrate old shared data to user-specific on first run
        await _migrateSharedDataBoxes(cipher);

        // CRITICAL: Fix records that were created offline with userId='local'.
        // These records will be rejected by Supabase RLS policies which require
        // user_id = auth.uid(). Reassign them to the real authenticated user ID
        // so they can be successfully upserted during the next sync.
        await _reassignLocalUserIds(_userId);
      }
    } finally {
      _switching = false;
    }
  }

  /// Updates the userId field of any record that still carries the placeholder
  /// value 'local' (set when the user was not signed in). These records are
  /// otherwise unreachable via Supabase RLS, so we must fix them before the
  /// first sync after sign-in.
  static Future<void> _reassignLocalUserIds(String realUserId) async {
    // Customers
    if (_customersReady) {
      final box = Hive.box<Customer>(customersBox);
      for (final customer in box.values.toList()) {
        if (customer.userId == 'local') {
          final updated = customer.copyWith(userId: realUserId);
          await saveCustomer(updated, addToSync: false);
          await _addToSyncQueue('customers', updated.id, 'upsert');
          appLogger.info(
            '  ✓ reassigned customer ${updated.id} userId → $realUserId',
          );
        }
      }
    }

    // Debts
    if (_debtsReady) {
      final box = Hive.box<Debt>(debtsBox);
      for (final debt in box.values.toList()) {
        if (debt.userId == 'local') {
          final updated = debt.copyWith(userId: realUserId);
          await saveDebt(updated, addToSync: false);
          await _addToSyncQueue('debts', updated.id, 'upsert');
          appLogger.info(
            '  ✓ reassigned debt ${updated.id} userId → $realUserId',
          );
        }
      }
    }

    // Products
    if (_productsReady) {
      final box = Hive.box<Product>(productsBox);
      for (final product in box.values.toList()) {
        if (product.userId == 'local') {
          final updated = product.copyWith(userId: realUserId);
          await saveProduct(updated, addToSync: false);
          await _addToSyncQueue('products', updated.id, 'upsert');
          appLogger.info(
            '  ✓ reassigned product ${updated.id} userId → $realUserId',
          );
        }
      }
    }

    // Payments
    if (_paymentsReady) {
      final box = Hive.box<Payment>(paymentsBox);
      for (final payment in box.values.toList()) {
        if (payment.userId == 'local') {
          final updated = payment.copyWith(userId: realUserId);
          await savePayment(updated, addToSync: false);
          await _addToSyncQueue('payments', updated.id, 'upsert');
          appLogger.info(
            '  ✓ reassigned payment ${updated.id} userId → $realUserId',
          );
        }
      }
    }

    // Audit logs
    final isAuditLogReady = Hive.isBoxOpen(auditLogBox);
    if (isAuditLogReady) {
      final box = Hive.box<AuditLog>(auditLogBox);
      for (final log in box.values.toList()) {
        if (log.userId == 'local') {
          final fixed = AuditLog(
            id: log.id,
            entity: log.entity,
            recordId: log.recordId,
            actionType: log.actionType,
            payloadJson: log.payloadJson,
            createdAt: log.createdAt,
            userId: realUserId,
            operationId: log.operationId,
          );
          await box.put(fixed.id, fixed);
          await _addToSyncQueue('audit_logs', fixed.id, 'upsert');
          appLogger.info(
            '  ✓ reassigned audit log ${fixed.id} userId → $realUserId',
          );
        }
      }
    }
  }

  static Future<void> _closeBox(String name) async {
    try {
      final box = Hive.box(name);
      await box.close();
    } catch (_) {}
  }

  static String get currentUserId => _userId;

  // ── Safe box access helpers ──────────────────────────────────────────
  static Box<Customer> get _customersBox => Hive.box<Customer>(customersBox);
  static Box<Debt> get _debtsBox => Hive.box<Debt>(debtsBox);
  static Box<Product> get _productsBox => Hive.box<Product>(productsBox);
  static Box<Payment> get _paymentsBox => Hive.box<Payment>(paymentsBox);
  static Box<AppSettings> get _settingsBox =>
      Hive.box<AppSettings>(_settingsBoxName);
  static Box<Map> get _syncQueueBox => Hive.box<Map>(_syncQueueBoxName);
  static Box<AuditLog> get _auditLogsBox => Hive.box<AuditLog>(auditLogBox);

  static bool get _customersReady => Hive.isBoxOpen(customersBox);
  static bool get _debtsReady => Hive.isBoxOpen(debtsBox);
  static bool get _productsReady => Hive.isBoxOpen(productsBox);
  static bool get _paymentsReady => Hive.isBoxOpen(paymentsBox);
  static bool get _settingsReady => Hive.isBoxOpen(_settingsBoxName);

  /// In-memory cache for [getAppSettings] to avoid repeated Hive reads.
  /// Invalidated on [switchUser] and [clearAll]; refreshed on save.
  static AppSettings? _settingsCache;

  // Customers
  static Future<void> saveCustomer(
    Customer customer, {
    bool addToSync = true,
  }) async {
    if (!_customersReady) return;
    await _customersBox.put(customer.id, customer);
    if (addToSync) await _addToSyncQueue('customers', customer.id, 'upsert');
  }

  static Future<void> deleteCustomer(String id) async {
    if (!_customersReady) return;
    final customer = _customersBox.get(id);
    if (customer != null) {
      customer.deletedAt = DateTime.now();
      await _customersBox.put(id, customer);
      await _addToSyncQueue('customers', id, 'upsert');
    }
  }

  static List<Customer> getAllCustomers({bool includeDeleted = false}) {
    if (!_customersReady) return [];
    if (includeDeleted) return _customersBox.values.toList();
    return _customersBox.values.where((c) => c.deletedAt == null).toList();
  }

  static List<Customer> getDeletedCustomers() {
    if (!_customersReady) return [];
    return _customersBox.values.where((c) => c.deletedAt != null).toList();
  }

  static Future<void> restoreCustomer(String id) async {
    if (!_customersReady) return;
    final customer = _customersBox.get(id);
    if (customer != null) {
      customer.deletedAt = null;
      await _customersBox.put(id, customer);
      await _addToSyncQueue('customers', id, 'upsert');
    }
  }

  static Future<void> permanentDeleteCustomer(String id) async {
    if (!_customersReady) return;
    await _customersBox.delete(id);
    await _addToSyncQueue('customers', id, 'delete');
  }

  static Customer? getCustomer(String id) {
    if (!_customersReady) return null;
    return _customersBox.get(id);
  }

  // Debts
  static Future<void> saveDebt(
    Debt debt, {
    bool addToSync = true,
    bool audit = true,
  }) async {
    if (!_debtsReady) return;
    await _debtsBox.put(debt.id, debt);
    if (addToSync) await _addToSyncQueue('debts', debt.id, 'upsert');

    // Audit (best-effort): record that a debt was added/updated locally.
    // Note: "add_debt" semantics depend on usage; current app uses saveDebt for addDebt.
    // Skipped during bulk restore/import to avoid N×2 extra Hive writes.
    if (audit) {
      final userId = debt.userId;
      await _addAuditLog(
        entity: 'debts',
        recordId: debt.id,
        actionType: 'add_debt',
        payload: {
          'customer_id': debt.customerId,
          'amount': debt.amount,
          'product_id': debt.productId,
          'product_name': debt.productName,
          'product_quantity': debt.productQuantity,
          'due_date': debt.dueDate?.toIso8601String(),
          'notes': debt.notes,
          'created_at': debt.createdAt.toIso8601String(),
        },
        userId: userId,
      );
    }
  }

  static Future<void> deleteDebt(String id) async {
    if (!_debtsReady) return;
    final debt = _debtsBox.get(id);
    if (debt != null) {
      debt.deletedAt = DateTime.now();
      await _debtsBox.put(id, debt);
      await _addToSyncQueue('debts', id, 'upsert');
    }

    await _addAuditLog(
      entity: 'debts',
      recordId: id,
      actionType: 'delete_debt',
      payload: {},
      userId: _userId.isNotEmpty ? _userId : 'local',
    );
  }

  static Future<void> restoreDebt(String id) async {
    if (!_debtsReady) return;
    final debt = _debtsBox.get(id);
    if (debt != null) {
      debt.deletedAt = null;
      await _debtsBox.put(id, debt);
      await _addToSyncQueue('debts', id, 'upsert');
    }
  }

  static Future<void> permanentDeleteDebt(String id) async {
    if (!_debtsReady) return;
    await _debtsBox.delete(id);
    await _addToSyncQueue('debts', id, 'delete');
  }

  static List<Debt> getAllDebts({bool includeDeleted = false}) {
    if (!_debtsReady) return [];
    if (includeDeleted) return _debtsBox.values.toList();
    return _debtsBox.values.where((d) => d.deletedAt == null).toList();
  }

  static List<Debt> getDeletedDebts() {
    if (!_debtsReady) return [];
    return _debtsBox.values.where((d) => d.deletedAt != null).toList();
  }

  static List<Debt> getDebtsByCustomer(
    String customerId, {
    bool includeDeleted = false,
  }) {
    if (!_debtsReady) return [];
    var result = _debtsBox.values.where((d) => d.customerId == customerId);
    if (!includeDeleted) {
      result = result.where((d) => d.deletedAt == null);
    }
    return result.toList();
  }

  static List<Debt> getUnpaidDebts() {
    if (!_debtsReady) return [];
    return _debtsBox.values
        .where((d) => d.deletedAt == null && !d.isPaid)
        .toList();
  }

  static Debt? getDebt(String id) {
    if (!_debtsReady) return null;
    return _debtsBox.get(id);
  }

  // Products
  static Future<void> saveProduct(
    Product product, {
    bool addToSync = true,
  }) async {
    if (!_productsReady) return;
    await _productsBox.put(product.id, product);
    if (addToSync) await _addToSyncQueue('products', product.id, 'upsert');
  }

  static Future<void> deleteProduct(String id) async {
    if (!_productsReady) return;
    final product = _productsBox.get(id);
    if (product != null) {
      product.deletedAt = DateTime.now();
      await _productsBox.put(id, product);
      await _addToSyncQueue('products', id, 'upsert');
    }
  }

  static Future<void> restoreProduct(String id) async {
    if (!_productsReady) return;
    final product = _productsBox.get(id);
    if (product != null) {
      product.deletedAt = null;
      await _productsBox.put(id, product);
      await _addToSyncQueue('products', id, 'upsert');
    }
  }

  static Future<void> permanentDeleteProduct(String id) async {
    if (!_productsReady) return;
    await _productsBox.delete(id);
    await _addToSyncQueue('products', id, 'delete');
  }

  static List<Product> getAllProducts({bool includeDeleted = false}) {
    if (!_productsReady) return [];
    if (includeDeleted) return _productsBox.values.toList();
    return _productsBox.values.where((p) => p.deletedAt == null).toList();
  }

  static List<Product> getDeletedProducts() {
    if (!_productsReady) return [];
    return _productsBox.values.where((p) => p.deletedAt != null).toList();
  }

  static Product? getProduct(String id) {
    if (!_productsReady) return null;
    return _productsBox.get(id);
  }

  /// Finds a product by its exact barcode (non-deleted only).
  /// Returns null when no product matches or the box is closed.
  static Product? getProductByBarcode(String barcode) {
    if (!_productsReady) return null;
    final normalized = barcode.trim();
    if (normalized.isEmpty) return null;
    return _productsBox.values
        .where((p) => p.deletedAt == null && p.barcode == normalized)
        .firstOrNull;
  }

  static Future<void> updateProductQuantity(String id, int quantity) async {
    if (!_productsReady) return;
    final product = _productsBox.get(id);
    if (product != null) {
      product.quantity = max(0, quantity);
      await saveProduct(product);
    }
  }

  // Payments
  static Future<void> savePayment(
    Payment payment, {
    bool addToSync = true,
    bool audit = true,
  }) async {
    if (!_paymentsReady) return;
    await _paymentsBox.put(payment.id, payment);
    if (addToSync) await _addToSyncQueue('payments', payment.id, 'upsert');

    // Audit: payment will also be recorded from provider (where we compute remaining).
    // Here we keep minimal info.
    // Skipped during bulk restore/import to avoid N×2 extra Hive writes.
    if (audit) {
      await _addAuditLog(
        entity: 'payments',
        recordId: payment.id,
        actionType: 'add_payment',
        payload: {
          'debt_id': payment.debtId,
          'amount': payment.amount,
          'created_at': payment.createdAt.toIso8601String(),
        },
        userId: payment.userId,
      );
    }
  }

  static List<Payment> getAllPayments({bool includeDeleted = false}) {
    if (!_paymentsReady) return [];
    if (includeDeleted) return _paymentsBox.values.toList();
    return _paymentsBox.values.where((p) => p.deletedAt == null).toList();
  }

  static List<Payment> getPaymentsByDebt(String debtId) {
    if (!_paymentsReady) return [];
    return _paymentsBox.values
        .where((p) => p.debtId == debtId && p.deletedAt == null)
        .toList();
  }

  static Future<void> deletePayment(String id) async {
    if (!_paymentsReady) return;
    final payment = _paymentsBox.get(id);
    if (payment != null) {
      payment.deletedAt = DateTime.now();
      await _paymentsBox.put(id, payment);
      await _addToSyncQueue('payments', id, 'upsert');
    }
  }

  static Future<void> permanentDeletePayment(String id) async {
    if (!_paymentsReady) return;
    await _paymentsBox.delete(id);
    await _addToSyncQueue('payments', id, 'delete');
  }

  // Settings (shared — no userId suffix)
  // Cached in-memory: [getAppSettings] serves from [_settingsCache] after the
  // first read, and both setters keep the cache in sync with Hive.
  static AppSettings getAppSettings() {
    if (_settingsCache != null) return _settingsCache!;
    if (!_settingsReady) return AppSettings();
    try {
      _settingsCache = _settingsBox.get('app_settings') ?? AppSettings();
    } on TypeError catch (_) {
      _settingsCache = AppSettings();
    }
    return _settingsCache!;
  }

  static Future<void> saveAppSettings(AppSettings newSettings) async {
    _settingsCache = newSettings;
    await _settingsBox.put('app_settings', newSettings);
  }

  /// Saves user settings restored from Supabase into the shared settings box.
  /// Mirrors [saveAppSettings] — same key, same box, no sync queue (settings
  /// are synced separately via [SupabaseService.upsertUserSettings]).
  static Future<void> saveSettings(AppSettings settings) async {
    _settingsCache = settings;
    await _settingsBox.put('app_settings', settings);
  }

  /// Maps an [Installment] DTO (a row from the Supabase `installments`
  /// table) back onto its parent [Debt]'s parallel arrays
  /// (installmentDates, installmentAmounts, installmentStatuses,
  /// installmentPaidAts). Installment data is NOT stored in its own Hive
  /// box — it is embedded inside the parent Debt. This follows the same
  /// ready-check + box.put + sync-queue pattern as [saveDebt].
  ///
  /// The Debt model stores these arrays with non-nullable element types
  /// (e.g. `List<DateTime>?`, not `List<DateTime?>?`). For unpaid
  /// installments we use the same sentinel values as the rest of the app:
  ///   - paidAts: `DateTime(0)` (see debts_provider.dart)
  ///   - statuses: `'pending'`
  ///   - amounts: `0.0`
  ///   - dates: `DateTime(0)` (only used as padding; overwritten below)
  static Future<void> saveInstallment(
    Installment installment, {
    bool addToSync = true,
  }) async {
    if (!_debtsReady) return;
    final debt = _debtsBox.get(installment.debtId);
    if (debt == null) return;

    // Ensure the parallel arrays exist and are long enough to hold this
    // installment's slot (index = installmentNumber - 1). The Debt model
    // uses non-nullable element types, so we pad with sentinel values
    // rather than nulls.
    final index = installment.installmentNumber - 1;
    final dates = List<DateTime>.from(debt.installmentDates ?? []);
    final amounts = List<double>.from(debt.installmentAmounts ?? []);
    final statuses = List<String>.from(debt.installmentStatuses ?? []);
    final paidAts = List<DateTime>.from(debt.installmentPaidAts ?? []);

    while (dates.length <= index) {
      dates.add(DateTime(0));
      amounts.add(0.0);
      statuses.add('pending');
      paidAts.add(DateTime(0));
    }

    dates[index] = installment.dueDate;
    amounts[index] = installment.amount;
    statuses[index] = installment.status;
    paidAts[index] = installment.paidAt ?? DateTime(0);

    debt.installmentDates = dates;
    debt.installmentAmounts = amounts;
    debt.installmentStatuses = statuses;
    debt.installmentPaidAts = paidAts;
    debt.isInstallment = true;
    if (debt.installmentCount < installment.installmentNumber) {
      debt.installmentCount = installment.installmentNumber;
    }

    await _debtsBox.put(debt.id, debt);
    if (addToSync) await _addToSyncQueue('debts', debt.id, 'upsert');
  }

  // Direct public box access for legacy/utility code
  static Box<Debt> get debts => _debtsBox;
  static Box<Payment> get payments => _paymentsBox;
  static Box<AuditLog> get auditLogs => _auditLogsBox;

  // Sync Queue (shared — no userId suffix)
  static Box<Map> get syncQueue => _syncQueueBox;
  static Future<void> _addToSyncQueue(
    String table,
    String recordId,
    String operation,
  ) async {
    // Dedup check — if an entry for the same (table, record_id) already
    // exists, just update it in place instead of appending a new one.
    // This prevents the queue from ballooning when many rapid updates hit
    // the same record (e.g. a debt being saved repeatedly with the same id).
    //
    // PERFORMANCE: previously this looped over every key in the sync-queue
    // box and called `.get(key)` for each — an O(N) Hive read on the UI
    // thread on EVERY save. With a large queue this was the root cause of
    // the 51–53 second UI freezes. We now use an in-memory index
    // ([_syncQueueIndex]) for an O(1) lookup with zero Hive reads.
    final dedupKey = '${table}_$recordId';
    try {
      final index = _getSyncQueueIndex();
      final existingKey = index[dedupKey];

      if (existingKey != null) {
        // Same record already queued — update in place (refresh timestamp
        // and operation) instead of appending a duplicate.
        await _syncQueueBox.put(existingKey, {
          'table': table,
          'record_id': recordId,
          'operation': operation,
          'timestamp': DateTime.now().toIso8601String(),
        });
        return; // index key unchanged — still points to existingKey
      }
    } catch (_) {
      // If anything goes wrong during dedup lookup, fall through and
      // append normally — never block enqueueing on an internal error.
    }

    // New item — add it. Hive auto-increments the key for `.add()`.
    final newKey = await _syncQueueBox.add({
      'table': table,
      'record_id': recordId,
      'operation': operation,
      'timestamp': DateTime.now().toIso8601String(),
    });
    // Keep the in-memory index in sync so future dedup hits are O(1).
    _syncQueueIndex?[dedupKey] = newKey;
  }

  static Future<void> addToSyncQueue(
    String table,
    String recordId,
    String operation,
  ) async {
    await _addToSyncQueue(table, recordId, operation);
  }

  static List<Map> getSyncQueue() {
    return _syncQueueBox.values.toList();
  }

  static List<MapEntry<dynamic, Map>> getSyncQueueWithKeys() {
    if (!_boxesOpen) return [];
    return _syncQueueBox.toMap().entries.toList();
  }

  static Future<void> clearSyncQueue() async {
    await _syncQueueBox.clear();
    // Invalidate the in-memory dedup index — the box is now empty.
    _syncQueueIndex?.clear();
  }

  /// Deletes a single sync-queue item by its Hive key. Used by
  /// [SyncService] to remove only the items that were successfully
  /// synced, preserving any items that were added to the queue while
  /// the sync was in progress.
  ///
  /// Keeps the in-memory dedup index ([_syncQueueIndex]) in sync by
  /// removing the entry that pointed to [key]. We do a reverse lookup
  /// over the small in-memory map (not the Hive box) so this stays cheap.
  static Future<void> removeSyncQueueItemByKey(dynamic key) async {
    await _syncQueueBox.delete(key);
    final index = _syncQueueIndex;
    if (index == null || index.isEmpty) return;
    index.removeWhere((_, v) => v == key);
  }

  static Future<void> _addAuditLog({
    required String entity,
    String? recordId,
    required String actionType,
    required Map<String, dynamic> payload,
    required String userId,
    String? operationId,
  }) async {
    if (!Hive.isBoxOpen(auditLogBox)) return;
    final log = AuditLog(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      entity: entity,
      recordId: recordId,
      actionType: actionType,
      payloadJson: jsonEncode(payload),
      createdAt: DateTime.now(),
      userId: userId,
      operationId: operationId,
    );
    await _auditLogsBox.put(log.id, log);
    await _addToSyncQueue('audit_logs', log.id, 'upsert');
  }

  // Clear all data for current user (keeps settings & sync queue)
  static Future<void> clearAll() async {
    _settingsCache = null;
    if (_customersReady) await _customersBox.clear();
    if (_debtsReady) await _debtsBox.clear();
    if (_productsReady) await _productsBox.clear();
    if (_paymentsReady) await _paymentsBox.clear();
    // Keep settings & sync queue
  }

  // ── Reliability ────────────────────────────────────────────────────────────
  /// Returns 'green', 'yellow', or 'red' based on actual payment behaviour.
  ///
  /// Criteria (based on existing debts + payments data only):
  ///   green  = "موثوق" — average settlement ≤ 7 days late AND no overdue debts
  ///   yellow = "عادي"  — average settlement 8–30 days OR 1 overdue debt OR no history
  ///   red    = "محفوف بالمخاطر" — average settlement > 30 days OR ≥ 2 overdue debts
  ///
  /// New customers with no debts → yellow (عادي), never red.
  ///
  /// Pass [preloadedDebts] and [preloadedPayments] to avoid re-reading the
  /// entire Hive boxes on every call (e.g. when computing reliability for a
  /// list of customers via [getAllCustomerReliabilities]). When omitted, the
  /// method falls back to per-customer/per-debt Hive reads for backwards
  /// compatibility with existing callers such as [CustomerCard].
  static String customerReliability(
    String customerId, {
    List<Debt>? preloadedDebts,
    List<Payment>? preloadedPayments,
  }) {
    final customerDebts = preloadedDebts != null
        ? preloadedDebts.where((d) => d.customerId == customerId).toList()
        : getDebtsByCustomer(customerId);
    if (customerDebts.isEmpty) return 'yellow';

    final now = DateTime.now();

    // ── 1. Average settlement days (from fully-paid debts) ─────────────
    int totalSettlementDays = 0;
    int settledDebtCount = 0;

    for (final debt in customerDebts) {
      if (!debt.isPaid) continue;
      final payments = preloadedPayments != null
          ? preloadedPayments.where((p) => p.debtId == debt.id).toList()
          : getPaymentsByDebt(debt.id);
      if (payments.isEmpty) continue;

      // Use the latest payment date as settlement date.
      // Only measure lateness against debts that had an explicit dueDate;
      // open-ended debts (dueDate == null) have no agreed deadline to compare.
      if (debt.dueDate == null) continue;
      final lastPayment = payments.reduce(
        (a, b) => a.createdAt.isAfter(b.createdAt) ? a : b,
      );
      final daysLate = lastPayment.createdAt.difference(debt.dueDate!).inDays;
      if (daysLate >= 0) {
        totalSettlementDays += daysLate;
        settledDebtCount++;
      }
    }

    final avgSettlementDays = settledDebtCount > 0
        ? totalSettlementDays / settledDebtCount
        : -1.0;

    // ── 2. Count overdue debts ─────────────────────────────────────────
    int overdueCount = 0;
    for (final debt in customerDebts) {
      if (debt.isPaid) continue;
      // A debt with no dueDate has no agreed deadline — never overdue.
      if (debt.dueDate == null) continue;
      if (now.difference(debt.dueDate!).inDays > 0) {
        overdueCount++;
      }
    }

    // ── 3. Classification ──────────────────────────────────────────────
    // No fully paid debts yet — rely on overdue count only
    if (settledDebtCount == 0) {
      if (overdueCount >= 2) return 'red';
      if (overdueCount == 1) return 'yellow';
      return 'yellow'; // new customer or all debts current (no history to judge)
    }

    // Has settlement history
    if (avgSettlementDays <= 7 && overdueCount == 0) return 'green';
    if (avgSettlementDays > 30 || overdueCount >= 2) return 'red';
    return 'yellow';
  }

  /// Computes reliability for every customer in a single pass — O(N+M)
  /// instead of O(N×M) when [customerReliability] is called once per
  /// customer in a list. Reads each data box exactly once and returns a
  /// map of `customerId → reliability`. Returns an empty map if the debts
  /// or payments boxes are not open yet.
  static Map<String, String> getAllCustomerReliabilities() {
    if (!_debtsReady || !_paymentsReady) return {};

    // Single read of all data
    final allDebts = _debtsBox.values
        .where((d) => d.deletedAt == null)
        .toList();
    final allPayments = _paymentsBox.values
        .where((p) => p.deletedAt == null)
        .toList();

    // Compute reliability per customer
    final customerIds = allDebts.map((d) => d.customerId).toSet();
    return {
      for (final id in customerIds)
        id: customerReliability(
          id,
          preloadedDebts: allDebts,
          preloadedPayments: allPayments,
        ),
    };
  }

  // ── Reliability display helpers ──────────────────────────────────────────
  // Single source of truth for mapping a reliability string to a UI color,
  // a human-readable Arabic label, and a sort rank.  All callers must use
  // these helpers instead of inline switch statements.

  /// Returns the badge colour for a reliability string ('red'|'yellow'|'green').
  static Color reliabilityColor(String? rel) {
    switch (rel) {
      case 'red':
        return AppColors.error;
      case 'yellow':
        return AppColors.accent;
      default:
        return AppColors.success;
    }
  }

  /// Returns the Arabic label for a reliability string.
  static String reliabilityLabel(String? rel) {
    switch (rel) {
      case 'red':
        return 'يحتاج متابعة';
      case 'yellow':
        return 'زبون عادي';
      default:
        return 'زبون موثوق';
    }
  }

  /// Returns a sort rank: 0 = red (worst), 1 = yellow, 2 = green (best).
  static int reliabilityRank(String? rel) {
    switch (rel) {
      case 'red':
        return 0;
      case 'yellow':
        return 1;
      default:
        return 2;
    }
  }

  // Close all boxes
  static Future<void> close() async {
    await Hive.close();
  }
}
