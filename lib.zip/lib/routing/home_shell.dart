import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/constants/colors.dart';
import '../shared/widgets/glass_sheet.dart';
import '../core/constants/strings.dart';
import '../core/constants/dimensions.dart';
import '../core/services/sync_service.dart';
import '../features/dashboard/screens/dashboard_screen.dart';
import '../features/customers/screens/customers_list_screen.dart';
import '../features/customers/widgets/add_customer_sheet.dart';
import '../features/installments/screens/installments_screen.dart';
import '../features/installments/widgets/add_installment_sheet.dart';
import '../features/inventory/screens/inventory_screen.dart';
import '../features/inventory/widgets/add_product_sheet.dart';
import '../features/reports/screens/reports_screen.dart';
import '../features/settings/screens/settings_screen.dart';
import '../features/customers/providers/customers_provider.dart';
import '../features/customers/providers/debts_provider.dart';
import '../features/inventory/providers/inventory_provider.dart';
import '../features/dashboard/providers/dashboard_provider.dart';
import '../features/installments/providers/installments_provider.dart';
import '../shared/providers/sync_provider.dart';

class HomeShell extends ConsumerStatefulWidget {
  const HomeShell({super.key});

  @override
  ConsumerState<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends ConsumerState<HomeShell> {
  int _currentIndex = 0;
  Timer? _statusTimer;
  Timer? _syncTimer;
  int _pendingCount = 0;
  bool _isSyncing = false;

  final List<Widget> _screens = const [
    DashboardScreen(),
    CustomersListScreen(),
    InstallmentsScreen(),
    InventoryScreen(),
    ReportsScreen(),
    SettingsScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _refreshStatus();

    // Timer to update the UI every 3 seconds
    _statusTimer = Timer.periodic(
      const Duration(seconds: 3),
      (_) => _refreshStatus(),
    );

    // Timer for automatic synchronization every 30 seconds
    // It only works if there are pending changes
    _syncTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (SyncService.pendingCount() > 0 && !SyncService.isSyncing) {
        SyncService.syncAll().catchError((e) {
          debugPrint('Auto-sync error: $e');
        });
      }
    });

    // Instant synchronization when opening the application if there are pending changes
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (SyncService.pendingCount() > 0) {
        SyncService.syncAllDebounced();
      }
    });
  }

  @override
  void dispose() {
    _statusTimer?.cancel();
    _syncTimer?.cancel();
    super.dispose();
  }

  void _refreshStatus() {
    if (mounted) {
      setState(() {
        _pendingCount = SyncService.pendingCount();
        _isSyncing = SyncService.isSyncing;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isRestoring = ref.watch(isRestoringProvider);

    // لا تحجب المحتوى — فقط أضف progress indicator صغير في الأعلى عند الاسترجاع
    return Stack(
      children: [
        Scaffold(
          body: Stack(
            children: [
              _screens[_currentIndex],
              if (_isSyncing)
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  child: LinearProgressIndicator(
                    backgroundColor: AppColors.primary.withValues(alpha: 0.15),
                    color: AppColors.primary,
                    minHeight: 3,
                  ),
                ),
            ],
          ),
          floatingActionButton: _buildFAB(),
          floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
          bottomNavigationBar: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildSyncStatusBar(),
              NavigationBar(
                selectedIndex: _currentIndex,
                onDestinationSelected: (index) {
                  setState(() => _currentIndex = index);
                },
                destinations: const [
                  NavigationDestination(
                    icon: Icon(Icons.home_outlined),
                    selectedIcon: Icon(Icons.home),
                    label: AppStrings.dashboard,
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.people_outline),
                    selectedIcon: Icon(Icons.people),
                    label: AppStrings.customers,
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.calendar_month_outlined),
                    selectedIcon: Icon(Icons.calendar_month),
                    label: 'أقساط',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.inventory_2_outlined),
                    selectedIcon: Icon(Icons.inventory_2),
                    label: AppStrings.inventory,
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.analytics_outlined),
                    selectedIcon: Icon(Icons.analytics),
                    label: AppStrings.reports,
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.settings_outlined),
                    selectedIcon: Icon(Icons.settings),
                    label: AppStrings.settings,
                  ),
                ],
              ),
            ],
          ),
        ),
        // شريط تحميل شفاف في الأعلى فقط عند الاسترجاع
        if (isRestoring)
          const Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: LinearProgressIndicator(),
          ),
      ],
    );
  }

  Widget _buildSyncStatusBar() {
    // Completely disappear when there is nothing pending and no sync in progress
    if (_pendingCount == 0 && !_isSyncing) {
      return const SizedBox.shrink();
    }

    // Thin bar (4px) at the top while syncing
    if (_isSyncing) {
      return SizedBox(
        height: 4,
        child: LinearProgressIndicator(
          minHeight: 4,
          backgroundColor: Colors.transparent,
          valueColor: AlwaysStoppedAnimation<Color>(AppColors.primary),
        ),
      );
    }

    // Pending changes count — a small tappable bar at the bottom
    return GestureDetector(
      onTap: () async {
        _refreshStatus();
        await SyncService.syncAll();
        ref.invalidate(customersProvider);
        ref.invalidate(debtsProvider);
        ref.invalidate(productsProvider);
        ref.invalidate(dashboardStatsProvider);
        ref.invalidate(installmentsProvider);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        color: AppColors.primary.withValues(alpha: 0.1),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.sync, size: 14, color: AppColors.primary),
            const SizedBox(width: 6),
            Text(
              '$_pendingCount تغيير في انتظار المزامنة — اضغط للمزامنة',
              style: TextStyle(fontSize: 12, color: AppColors.primary),
            ),
          ],
        ),
      ),
    );
  }

  Widget? _buildFAB() {
    if (_currentIndex <= 3) {
      return FloatingActionButton(
        onPressed: _showAddSheet,
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.add, size: AppDimensions.iconLg),
      );
    }
    return null;
  }

  void _showAddSheet() {
    GlassSheet.show(context, (context) {
      if (_currentIndex == 0) {
        return const AddCustomerSheet();
      } else if (_currentIndex == 1) {
        return const AddCustomerSheet();
      } else if (_currentIndex == 2) {
        return const AddInstallmentSheet();
      } else if (_currentIndex == 3) {
        return const AddProductSheet();
      }
      return const SizedBox.shrink();
    });
  }
}
