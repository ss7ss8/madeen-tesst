import 'package:flutter/material.dart';
import 'dart:async';
import '../data/local/hive_service.dart';
import '../features/auth/screens/lock_screen.dart';
import 'home_shell.dart';

/// Wraps HomeShell with auto-lock behavior.
/// Listens to app lifecycle and locks after the configured timeout.
class AppLockWrapper extends StatefulWidget {
  const AppLockWrapper({super.key});

  @override
  State<AppLockWrapper> createState() => _AppLockWrapperState();
}

class _AppLockWrapperState extends State<AppLockWrapper>
    with WidgetsBindingObserver {
  bool _isLocked = false;
  DateTime? _backgroundedAt;
  Timer? _lockTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkIfShouldLockOnStart();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _lockTimer?.cancel();
    super.dispose();
  }

  /// Lock immediately if biometric or PIN is enabled on cold start.
  void _checkIfShouldLockOnStart() {
    final settings = HiveService.getAppSettings();
    if (settings.biometricEnabled || settings.pinEnabled) {
      // Lock with a tiny delay so the widget tree is built first
      Future.microtask(() {
        if (mounted) setState(() => _isLocked = true);
      });
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final settings = HiveService.getAppSettings();
    final timeoutSeconds = settings.autoLockTimeoutSeconds;
    final shouldLock = settings.biometricEnabled || settings.pinEnabled;

    if (!shouldLock) return;

    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      _backgroundedAt = DateTime.now();
      if (timeoutSeconds == 0) {
        // Lock immediately
        if (mounted) setState(() => _isLocked = true);
      } else if (timeoutSeconds > 0) {
        _lockTimer?.cancel();
        _lockTimer = Timer(Duration(seconds: timeoutSeconds), () {
          if (mounted) setState(() => _isLocked = true);
        });
      }
      // timeoutSeconds == -1 means never lock
    } else if (state == AppLifecycleState.resumed) {
      _lockTimer?.cancel();
      // If we set a timer-based lock that already triggered, stay locked
      if (timeoutSeconds > 0 && _backgroundedAt != null) {
        final elapsed = DateTime.now().difference(_backgroundedAt!).inSeconds;
        if (elapsed >= timeoutSeconds) {
          if (mounted) setState(() => _isLocked = true);
        }
      }
    }
  }

  void _onUnlocked() {
    setState(() => _isLocked = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_isLocked) {
      return LockScreen(onUnlocked: _onUnlocked);
    }
    return const HomeShell();
  }
}
