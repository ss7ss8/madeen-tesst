import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;

import '../../core/utils/formatters.dart';
import '../../data/models/customer.dart';
import '../../data/models/settings.dart';
import '../../features/customers/providers/statement_provider.dart';
import 'thermal_invoice_renderer.dart';
import 'thermal_isolate.dart';
import 'thermal_render_primitives.dart';

/// Modern thermal statement renderer with emoji icons and professional layout.
///
/// Enhanced Layout (RTL, Arabic - Modern Design):
///
///  ┌──────────────────────────────────┐
///  │   [اسم المحل]  [logo]            │  ← header band
///  │   📱 هاتف: ...                   │
///  ├══════════════════════════════════╡
///  │        📊 كشف حساب               │  ← with icon
///  ├══════════════════════════════════╡
///  │ 📅 التاريخ:        DD/MM/YYYY    │
///  │ 📆 الفترة:        XX - XX        │
///  ├ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┤
///  │ 👤 الزبون:         اسم الزبون   │
///  │ 📞 الهاتف:         XXXXXXXXX     │
///  ├ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┤
///  │ التاريخ | النوع | المبلغ | الرصيد│ ← table (80mm)
///  │   ...                            │
///  ├ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┤
///  │ ┌────────────────────────────┐   │
///  │ │ 📋 عدد العمليات:   X       │   │
///  │ │ 💰 إجمالي الدين:   X د.ع  │   │
///  │ │ ✅ إجمالي المدفوع: X د.ع  │   │
///  │ │ 🔴 المستحق:        X د.ع  │   │  ← highlighted
///  │ └────────────────────────────┘   │
///  ├══════════════════════════════════╡
///  │    ✨ شكراً لتعاملكم معنا ✨    │
///  │       🔒 احتفظ بالكشف          │
///  └──────────────────────────────────┘
class ThermalStatementRenderer {
  ThermalStatementRenderer._();

  /// Builds the full statement (58mm/80mm), rasterizes it, and returns
  /// ESC/POS bytes ready to send via [PrintBluetoothThermal.writeBytes].
  static Future<Uint8List> renderStatement({
    required AccountStatement statement,
    required Customer customer,
    required AppSettings settings,
    required ThermalPaperWidth paperWidth,
  }) async {
    final widthPx = paperWidth.pixels;

    // 1. Draw canvas
    final rendered = await _drawStatementCanvas(
      statement: statement,
      customer: customer,
      settings: settings,
      widthPx: widthPx,
    );

    // 2. Convert ui.Image → PNG (must run on the main isolate — the
    //    Flutter rendering / toByteData API is not available in a
    //    background isolate).
    final byteData = await rendered.toByteData(format: ui.ImageByteFormat.png);
    if (byteData == null) throw Exception('فشل تحويل الصورة');
    final pngBytes = byteData.buffer.asUint8List();

    // 3. + 4. Decode PNG and rasterize to ESC/POS bytes in a background
    //    isolate. These two steps (img.decodePng + Generator.image) are
    //    the CPU-heavy part of the pipeline — running them on the main
    //    isolate was the root cause of the "49 dropped frames" UI freeze
    //    when printing a statement. CapabilityProfile is loaded here on
    //    the main isolate (it reads a bundled asset via rootBundle,
    //    which is a platform channel unavailable in a background
    //    isolate) and then sent across to the worker; it is fully
    //    sendable (String name + List<CodePage> of int/String).
    final profile = await CapabilityProfile.load();
    return pngBytesToEscPos(
      pngBytes: pngBytes,
      paperWidth: paperWidth,
      profile: profile,
    );
  }

  // ===========================================================================
  // Canvas Drawing
  // ===========================================================================

  static Future<ui.Image> _drawStatementCanvas({
    required AccountStatement statement,
    required Customer customer,
    required AppSettings settings,
    required int widthPx,
  }) async {
    const fontFamily = 'IBMPlexSansArabic';
    final is58mm = widthPx <= 384;

    // ── Modern Font sizes with better spacing ────────────────────────────────
    final storeNameSize = is58mm ? 22.0 : 28.0;
    final titleSize = is58mm ? 17.0 : 21.0;
    final bodySize = is58mm ? 14.0 : 16.0;
    final tableSize = is58mm ? 12.0 : 13.0;
    final amountSize = is58mm ? 13.0 : 15.0;
    final footerSize = is58mm ? 12.0 : 14.0;

    final padding = is58mm ? 14.0 : 18.0;
    final contentWidth = widthPx - padding * 2;

    final logo = await renderStoreLogo(
      storeName: settings.storeName,
      storeLogoPath: settings.storeLogoPath,
      size: is58mm ? 52 : 68,
    );

    final lines = <RenderLine>[];

    // 1. Header band
    lines.add(
      RenderLine.logoBand(
        logo: logo,
        text: settings.storeName,
        logoSize: is58mm ? 52 : 68,
        fontSize: storeNameSize,
        fontWeight: FontWeight.bold,
        fontFamily: fontFamily,
        marginTop: 0,
      ),
    );

    if ((settings.storePhone ?? '').isNotEmpty) {
      lines.add(
        RenderLine.text(
          'هاتف: ${settings.storePhone}',
          fontSize: bodySize - 1,
          fontWeight: FontWeight.normal,
          align: TextAlign.center,
          fontFamily: fontFamily,
          marginTop: 4,
        ),
      );
    }

    // 2. Title with icon
    lines.add(RenderLine.doubleDivider());
    lines.add(
      RenderLine.text(
        '📊 ── كشف حساب ──',
        fontSize: titleSize,
        fontWeight: FontWeight.bold,
        align: TextAlign.center,
        fontFamily: fontFamily,
        marginTop: 6,
      ),
    );
    lines.add(RenderLine.doubleDivider());

    // 3. Date with icons
    lines.add(
      RenderLine.twoColumnRow(
        '📅 التاريخ:',
        Formatters.formatDate(DateTime.now()),
        fontSize: bodySize,
        marginTop: 8,
        fontFamily: fontFamily,
      ),
    );

    // Period
    if (statement.firstDate != null && statement.lastDate != null) {
      lines.add(
        RenderLine.twoColumnRow(
          '📆 الفترة:',
          '${Formatters.formatDate(statement.firstDate!)} — ${Formatters.formatDate(statement.lastDate!)}',
          fontSize: bodySize - 1,
          marginTop: 3,
          fontFamily: fontFamily,
        ),
      );
    }

    lines.add(RenderLine.divider());

    // 4. Customer info with icons
    lines.add(
      RenderLine.twoColumnRow(
        '👤 الزبون:',
        customer.name,
        fontSize: bodySize,
        marginTop: 4,
        isTwoColBold: true,
        fontFamily: fontFamily,
      ),
    );
    if ((customer.phone ?? '').isNotEmpty) {
      lines.add(
        RenderLine.twoColumnRow(
          '📞 الهاتف:',
          customer.phone!,
          fontSize: bodySize,
          marginTop: 4,
          fontFamily: fontFamily,
        ),
      );
    }

    lines.add(RenderLine.divider());

    // 5. Transactions
    if (is58mm) {
      // 58mm: each entry as stacked text rows
      for (var idx = 0; idx < statement.entries.length; idx++) {
        final e = statement.entries[idx];

        lines.add(
          RenderLine.text(
            '${idx + 1}. ${e.typeLabel} — ${e.description}',
            fontSize: tableSize + 1,
            fontWeight: FontWeight.bold,
            align: TextAlign.right,
            fontFamily: fontFamily,
            marginTop: 6,
          ),
        );
        lines.add(
          RenderLine.twoColumnRow(
            'المبلغ:',
            Formatters.formatAmount(e.amount),
            fontSize: tableSize,
            marginTop: 2,
            fontFamily: fontFamily,
          ),
        );
        lines.add(
          RenderLine.twoColumnRow(
            'الرصيد:',
            Formatters.formatAmount(e.runningBalance),
            fontSize: tableSize,
            marginTop: 2,
            fontFamily: fontFamily,
          ),
        );
        lines.add(
          RenderLine.twoColumnRow(
            'التاريخ:',
            Formatters.formatDate(e.date),
            fontSize: tableSize - 1,
            marginTop: 2,
            fontFamily: fontFamily,
          ),
        );
        // Thin separator between entries
        if (idx < statement.entries.length - 1) {
          lines.add(RenderLine.divider());
        }
      }
    } else {
      // 80mm: table with 4 columns (date | type | amount | balance)
      lines.add(
        RenderLine.tableRow(const [
          StatementCell('التاريخ', isHeader: true),
          StatementCell('النوع', isHeader: true),
          StatementCell('المبلغ', isHeader: true),
          StatementCell('الرصيد', isHeader: true),
        ], fontSize: tableSize),
      );
      for (final e in statement.entries) {
        lines.add(
          RenderLine.tableRow([
            StatementCell(Formatters.formatDate(e.date)),
            StatementCell(e.typeLabel),
            StatementCell(Formatters.formatAmount(e.amount), isTotal: true),
            StatementCell(
              Formatters.formatAmount(e.runningBalance),
              isTotal: true,
            ),
          ], fontSize: tableSize),
        );
      }
    }

    lines.add(RenderLine.divider());

    // 6. Modern Summary box with icons
    final due = statement.totalDebtPurchases - statement.totalPayments;
    lines.add(
      RenderLine.summaryBox(
        [
          SummaryRow('📋 عدد العمليات:', '${statement.transactionCount}'),
          SummaryRow(
            '💰 إجمالي الدين:',
            Formatters.formatCurrency(statement.totalDebtPurchases),
          ),
          SummaryRow(
            '✅ إجمالي المدفوع:',
            Formatters.formatCurrency(statement.totalPayments),
          ),
          SummaryRow(
            due > 0 ? '🔴 المستحق:' : '✅ مسدد كاملاً:',
            Formatters.formatCurrency(due),
            isTotal: true,
          ),
        ],
        fontSize: amountSize,
        marginTop: 8,
      ),
    );

    // 7. Modern footer with icons
    lines.add(RenderLine.doubleDivider());
    lines.add(
      RenderLine.text(
        '✨ شكراً لتعاملكم معنا ✨',
        fontSize: footerSize,
        fontWeight: FontWeight.bold,
        align: TextAlign.center,
        fontFamily: fontFamily,
        marginTop: 6,
      ),
    );
    lines.add(
      RenderLine.text(
        '🔒 يُرجى الاحتفاظ بهذا الكشف',
        fontSize: footerSize - 2,
        fontWeight: FontWeight.normal,
        align: TextAlign.center,
        fontFamily: fontFamily,
        marginTop: 3,
      ),
    );

    // ── Layout pass ───────────────────────────────────────────────────────────
    double totalHeight = padding;
    for (final line in lines) {
      line.layout(contentWidth);
      totalHeight += line.marginTop + line.height;
    }
    totalHeight += padding * 1.5;
    final heightPx = totalHeight.round();

    // ── Draw pass ─────────────────────────────────────────────────────────────
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder);

    canvas.drawRect(
      ui.Rect.fromLTWH(0, 0, widthPx.toDouble(), heightPx.toDouble()),
      ui.Paint()..color = const ui.Color(0xFFF8F9FA),
    );

    double y = padding;
    for (final line in lines) {
      y += line.marginTop;
      line.paint(canvas, padding, y, contentWidth);
      y += line.height;
    }

    final picture = recorder.endRecording();
    return picture.toImage(widthPx, heightPx);
  }

  // ===========================================================================
  // Logo helpers (shared with ThermalInvoiceRenderer pattern)
  // ===========================================================================

  /// Loads and prepares the store logo for monochrome thermal printing.
  /// Falls back to a white circle with the first letter of the store name.
  static Future<ui.Image> renderStoreLogo({
    required String storeName,
    String? storeLogoPath,
    int size = 96,
    int threshold = 160,
  }) async {
    final logoBytes = await _fetchLogoBytes(storeLogoPath);
    if (logoBytes != null) {
      final monochrome = _toBlackAndWhite(logoBytes, threshold: threshold);
      if (monochrome != null) {
        return _decodeUiImage(monochrome);
      }
    }
    return _drawStoreInitial(storeName, size);
  }

  static Future<Uint8List?> _fetchLogoBytes(String? logoPath) async {
    if (logoPath == null || logoPath.isEmpty) return null;
    HttpClient? client;
    try {
      if (logoPath.startsWith('http://') || logoPath.startsWith('https://')) {
        client = HttpClient();
        final request = await client.getUrl(Uri.parse(logoPath));
        final response = await request.close();
        if (response.statusCode < 200 || response.statusCode >= 300) {
          return null;
        }
        final bytes = <int>[];
        await for (final chunk in response) {
          bytes.addAll(chunk);
        }
        return Uint8List.fromList(bytes);
      }
      final file = File(logoPath);
      return await file.exists() ? file.readAsBytes() : null;
    } catch (_) {
      return null;
    } finally {
      client?.close(force: true);
    }
  }

  static Uint8List? _toBlackAndWhite(
    Uint8List bytes, {
    required int threshold,
  }) {
    final source = img.decodeImage(bytes);
    if (source == null) return null;
    final t = threshold.clamp(0, 255);
    for (final pixel in source) {
      final alpha = pixel.a.toInt();
      final luminance =
          (pixel.r.toInt() * 299 +
              pixel.g.toInt() * 587 +
              pixel.b.toInt() * 114) ~/
          1000;
      final value = alpha < 128 || luminance >= t ? 255 : 0;
      pixel
        ..r = value
        ..g = value
        ..b = value
        ..a = 255;
    }
    return Uint8List.fromList(img.encodePng(source));
  }

  static Future<ui.Image> _decodeUiImage(Uint8List bytes) {
    final completer = Completer<ui.Image>();
    ui.decodeImageFromList(bytes, completer.complete);
    return completer.future;
  }

  static Future<ui.Image> _drawStoreInitial(String storeName, int size) async {
    final safeSize = size.clamp(1, 1024);
    final dimension = safeSize.toDouble();
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder);
    final center = ui.Offset(dimension / 2, dimension / 2);
    final radius = dimension / 2 - 1;

    canvas.drawCircle(
      center,
      radius,
      ui.Paint()..color = const ui.Color(0xFFFFFFFF),
    );
    canvas.drawCircle(
      center,
      radius,
      ui.Paint()
        ..color = const ui.Color(0xFF000000)
        ..style = ui.PaintingStyle.stroke
        ..strokeWidth = (dimension * 0.04).clamp(1.0, 4.0),
    );

    final name = storeName.trim();
    final initial = name.isEmpty ? '?' : String.fromCharCode(name.runes.first);
    final painter = TextPainter(
      text: TextSpan(
        text: initial,
        style: TextStyle(
          color: const ui.Color(0xFF000000),
          fontSize: dimension * 0.5,
          fontWeight: FontWeight.bold,
          fontFamily: 'IBMPlexSansArabic',
        ),
      ),
      textDirection: ui.TextDirection.rtl,
      textAlign: TextAlign.center,
    )..layout(maxWidth: dimension);
    painter.paint(
      canvas,
      ui.Offset(
        (dimension - painter.width) / 2,
        (dimension - painter.height) / 2,
      ),
    );

    return recorder.endRecording().toImage(safeSize, safeSize);
  }
}
