import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;

import 'thermal_invoice_renderer.dart';

/// Message payload sent to [_pngToEscPos] via [compute].
///
/// Carries:
///   * [pngBytes] — the raw PNG bytes produced on the main isolate from a
///     [ui.Image] via `toByteData(format: ui.ImageByteFormat.png)`.
///   * [paperWidth] — selects the ESC/POS [PaperSize] (58mm vs 80mm).
///   * [profile] — a pre-loaded [CapabilityProfile]. This MUST be loaded
///     on the main isolate (via `CapabilityProfile.load()`) because that
///     call reads a bundled JSON asset through `rootBundle`, which is a
///     Flutter platform channel unavailable inside a background isolate.
///     [CapabilityProfile] only holds a [String] name and a `List` of
///     [CodePage] (each an `int` id + `String` name), so it is fully
///     sendable across isolate ports.
///
/// This must be a plain class whose fields are all sendable — [compute]
/// copies it to the worker isolate via a SendPort, so it cannot hold
/// unserializable handles (e.g. [ui.Image]).
class _EscPosJob {
  final Uint8List pngBytes;
  final ThermalPaperWidth paperWidth;
  final CapabilityProfile profile;

  const _EscPosJob({
    required this.pngBytes,
    required this.paperWidth,
    required this.profile,
  });
}

/// Top-level worker function executed inside a background isolate by
/// [compute].
///
/// It performs the two heaviest, pure-CPU steps of the thermal pipeline:
///   1. PNG decode ([img.decodePng]) — parses the rasterized canvas image.
///   2. ESC/POS rasterization ([Generator.image]) — converts the decoded
///      bitmap into the 1-bit-per-pixel ESC/POS byte stream the printer
///      expects.
///
/// Both steps are synchronous and CPU-bound; running them on the main
/// isolate was the root cause of the "49 dropped frames" UI freeze
/// reported when printing an invoice or statement. Moving them off the
/// UI thread keeps the UI responsive (spinners animate, the screen stays
/// interactive) while the printer bytes are being prepared.
///
/// The [CapabilityProfile] is passed in already loaded from the main
/// isolate (see [_EscPosJob] docs for why), so this worker performs no
/// platform-channel / asset-bundle access.
///
/// Returns the full ESC/POS byte stream (reset + image + feed + cut).
Uint8List _pngToEscPos(_EscPosJob job) {
  // 1. Decode the PNG produced from the ui.Image on the main isolate.
  final decoded = img.decodePng(job.pngBytes);
  if (decoded == null) {
    throw StateError('thermal_isolate: failed to decode PNG');
  }

  // 2. Build the ESC/POS generator for the target paper width using the
  //    pre-loaded capability profile.
  final generator = Generator(job.paperWidth.paperSize, job.profile);

  final List<int> bytes = <int>[];
  bytes.addAll(generator.reset());
  bytes.addAll(generator.image(decoded));
  bytes.addAll(generator.feed(3));
  bytes.addAll(generator.cut());

  return Uint8List.fromList(bytes);
}

/// Converts a rasterized [ui.Image] (already encoded to PNG bytes on the
/// main isolate) into ESC/POS printer bytes by offloading the CPU-heavy
/// PNG decode + rasterization to a background isolate via [compute].
///
/// The caller is expected to have already produced [pngBytes] via
/// `image.toByteData(format: ui.ImageByteFormat.png)` on the main
/// isolate (the Flutter rendering API is not available in background
/// isolates). Everything after that — the expensive part — happens here
/// off the UI thread.
///
/// [paperWidth] selects the ESC/POS [PaperSize] (58mm vs 80mm) used to
/// build the [Generator].
///
/// [profile] must be loaded on the main isolate via
/// `CapabilityProfile.load()` before calling this; it is sent across to
/// the worker isolate (it is fully sendable — see [_EscPosJob]).
///
/// Returns the full ESC/POS byte stream (reset + image + feed + cut).
Future<Uint8List> pngBytesToEscPos({
  required Uint8List pngBytes,
  required ThermalPaperWidth paperWidth,
  required CapabilityProfile profile,
}) {
  return compute(
    _pngToEscPos,
    _EscPosJob(
      pngBytes: pngBytes,
      paperWidth: paperWidth,
      profile: profile,
    ),
  );
}
