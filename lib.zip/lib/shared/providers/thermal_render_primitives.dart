import 'dart:ui' as ui;

import 'package:flutter/material.dart';

/// Type of a renderable line on a thermal canvas.
enum RenderLineKind {
  text,
  divider,
  doubleDivider,
  logoBand,
  gradientBand,
  tableRow,
  summaryBox,
  modernSummaryBox,
  twoColumnRow,
  iconText,
  iconRow,
}

/// A single cell inside a horizontal [RenderLine.tableRow].
class StatementCell {
  final String text;
  final bool isHeader;
  final bool isTotal;
  final bool alignRight;

  const StatementCell(
    this.text, {
    this.isHeader = false,
    this.isTotal = false,
    this.alignRight = true,
  });
}

/// A label/value pair inside the gray [RenderLine.summaryBox].
class SummaryRow {
  final String label;
  final String value;
  final bool isTotal;

  const SummaryRow(this.label, this.value, {this.isTotal = false});
}

/// A single renderable line on a thermal canvas.
class RenderLine {
  final RenderLineKind kind;
  final String text;
  final double fontSize;
  final FontWeight fontWeight;
  final TextAlign align;
  final String fontFamily;
  final bool isDivider;
  final double marginTop;

  // logoBand extras
  final ui.Image? logo;
  final double logoSize;

  // tableRow extras
  final List<StatementCell>? cells;

  // summaryBox extras
  final List<SummaryRow>? summaryRows;

  // twoColumnRow extras
  final String? rightText;
  final String? leftText;
  final bool isTwoColBold;

  TextPainter? _painter;

  // ─── Constructors ───────────────────────────────────────────────────────────

  RenderLine.text(
    this.text, {
    required this.fontSize,
    required this.fontWeight,
    required this.align,
    required this.fontFamily,
    this.marginTop = 3,
  }) : kind = RenderLineKind.text,
       isDivider = false,
       logo = null,
       logoSize = 0,
       cells = null,
       summaryRows = null,
       rightText = null,
       leftText = null,
       isTwoColBold = false;

  RenderLine.divider()
    : kind = RenderLineKind.divider,
      text = '',
      marginTop = 8,
      fontSize = 0,
      fontWeight = FontWeight.normal,
      align = TextAlign.center,
      fontFamily = '',
      isDivider = true,
      logo = null,
      logoSize = 0,
      cells = null,
      summaryRows = null,
      rightText = null,
      leftText = null,
      isTwoColBold = false;

  RenderLine.doubleDivider()
    : kind = RenderLineKind.doubleDivider,
      text = '',
      marginTop = 8,
      fontSize = 0,
      fontWeight = FontWeight.normal,
      align = TextAlign.center,
      fontFamily = '',
      isDivider = true,
      logo = null,
      logoSize = 0,
      cells = null,
      summaryRows = null,
      rightText = null,
      leftText = null,
      isTwoColBold = false;

  RenderLine.logoBand({
    required this.logo,
    required this.text,
    this.logoSize = 60,
    required this.fontSize,
    required this.fontWeight,
    required this.fontFamily,
    this.marginTop = 0,
  }) : kind = RenderLineKind.logoBand,
       isDivider = false,
       align = TextAlign.right,
       cells = null,
       summaryRows = null,
       rightText = null,
       leftText = null,
       isTwoColBold = false;

  RenderLine.tableRow(this.cells, {this.fontSize = 12, this.marginTop = 2})
    : kind = RenderLineKind.tableRow,
      text = '',
      fontWeight = FontWeight.normal,
      align = TextAlign.center,
      fontFamily = '',
      isDivider = false,
      logo = null,
      logoSize = 0,
      summaryRows = null,
      rightText = null,
      leftText = null,
      isTwoColBold = false;

  RenderLine.summaryBox(
    this.summaryRows, {
    this.fontSize = 12,
    this.marginTop = 6,
  }) : kind = RenderLineKind.summaryBox,
       text = '',
       fontWeight = FontWeight.normal,
       align = TextAlign.center,
       fontFamily = '',
       isDivider = false,
       logo = null,
       logoSize = 0,
       cells = null,
       rightText = null,
       leftText = null,
       isTwoColBold = false;

  /// Two-column row: right = label, left = value.
  RenderLine.twoColumnRow(
    this.rightText,
    this.leftText, {
    this.fontSize = 12,
    this.marginTop = 3,
    this.isTwoColBold = false,
    this.fontFamily = 'IBMPlexSansArabic',
  }) : kind = RenderLineKind.twoColumnRow,
       text = '',
       fontWeight = FontWeight.normal,
       align = TextAlign.right,
       isDivider = false,
       logo = null,
       logoSize = 0,
       cells = null,
       summaryRows = null;

  // ─── Layout ─────────────────────────────────────────────────────────────────

  double get height {
    switch (kind) {
      case RenderLineKind.divider:
        return 2;
      case RenderLineKind.doubleDivider:
        return 8;
      case RenderLineKind.text:
        return _painter?.height ?? fontSize * 1.5;
      case RenderLineKind.logoBand:
      case RenderLineKind.gradientBand:
        final nameH = _painter?.height ?? fontSize * 1.5;
        return (logoSize > nameH ? logoSize : nameH) + 16;
      case RenderLineKind.tableRow:
        return fontSize * 1.8 + 6;
      case RenderLineKind.summaryBox:
      case RenderLineKind.modernSummaryBox:
        return (summaryRows?.length ?? 0) * (fontSize * 2.0) + 18;
      case RenderLineKind.twoColumnRow:
      case RenderLineKind.iconRow:
        return fontSize * 1.7;
      case RenderLineKind.iconText:
        return _painter?.height ?? fontSize * 1.5;
    }
  }

  void layout(double contentWidth) {
    switch (kind) {
      case RenderLineKind.divider:
      case RenderLineKind.doubleDivider:
      case RenderLineKind.tableRow:
      case RenderLineKind.summaryBox:
      case RenderLineKind.modernSummaryBox:
      case RenderLineKind.twoColumnRow:
      case RenderLineKind.iconRow:
      case RenderLineKind.iconText:
        return;
      case RenderLineKind.text:
        _painter = _buildPainter(
          text,
          fontSize: fontSize,
          fontWeight: fontWeight,
          fontFamily: fontFamily,
          color: const ui.Color(0xFF000000),
          align: align,
          maxWidth: contentWidth,
        );
        return;
      case RenderLineKind.logoBand:
      case RenderLineKind.gradientBand:
        _painter = _buildPainter(
          text,
          fontSize: fontSize,
          fontWeight: fontWeight,
          fontFamily: fontFamily,
          color: const ui.Color(0xFFFFFFFF),
          align: TextAlign.right,
          maxWidth: contentWidth - logoSize - 12,
        );
        return;
    }
  }

  void paint(ui.Canvas canvas, double x, double y, double contentWidth) {
    switch (kind) {
      case RenderLineKind.divider:
        _paintDivider(canvas, x, y, contentWidth);
        return;
      case RenderLineKind.doubleDivider:
        _paintDoubleDivider(canvas, x, y, contentWidth);
        return;
      case RenderLineKind.text:
      case RenderLineKind.iconText:
        _painter?.paint(canvas, ui.Offset(x, y));
        return;
      case RenderLineKind.logoBand:
      case RenderLineKind.gradientBand:
        _paintLogoBand(canvas, x, y, contentWidth);
        return;
      case RenderLineKind.tableRow:
        _paintTableRow(canvas, x, y, contentWidth);
        return;
      case RenderLineKind.summaryBox:
      case RenderLineKind.modernSummaryBox:
        _paintSummaryBox(canvas, x, y, contentWidth);
        return;
      case RenderLineKind.twoColumnRow:
      case RenderLineKind.iconRow:
        _paintTwoColumnRow(canvas, x, y, contentWidth);
        return;
    }
  }

  // ─── Private painters ────────────────────────────────────────────────────

  void _paintDivider(
    ui.Canvas canvas,
    double x,
    double y,
    double contentWidth,
  ) {
    final paint = ui.Paint()
      ..color = const ui.Color(0xFF999999)
      ..strokeWidth = 0.8;
    const dashWidth = 5.0;
    const dashSpace = 3.0;
    double dx = x;
    while (dx < x + contentWidth) {
      canvas.drawLine(ui.Offset(dx, y), ui.Offset(dx + dashWidth, y), paint);
      dx += dashWidth + dashSpace;
    }
  }

  void _paintDoubleDivider(
    ui.Canvas canvas,
    double x,
    double y,
    double contentWidth,
  ) {
    final paint = ui.Paint()
      ..color = const ui.Color(0xFF000000)
      ..strokeWidth = 1.0;
    canvas.drawLine(ui.Offset(x, y), ui.Offset(x + contentWidth, y), paint);
    canvas.drawLine(
      ui.Offset(x, y + 4),
      ui.Offset(x + contentWidth, y + 4),
      paint,
    );
  }

  void _paintLogoBand(
    ui.Canvas canvas,
    double x,
    double y,
    double contentWidth,
  ) {
    final bandH = height;
    final fullX = x - x; // start from canvas edge 0
    final fullW = contentWidth + x * 2; // full width

    // Black background band (full width)
    canvas.drawRect(
      ui.Rect.fromLTWH(fullX, y, fullW, bandH),
      ui.Paint()..color = const ui.Color(0xFF111111),
    );

    // Logo on the right
    final logoY = y + (bandH - logoSize) / 2;
    if (logo != null) {
      canvas.drawImageRect(
        logo!,
        ui.Rect.fromLTWH(0, 0, logo!.width.toDouble(), logo!.height.toDouble()),
        ui.Rect.fromLTWH(
          x + contentWidth - logoSize,
          logoY,
          logoSize,
          logoSize,
        ),
        ui.Paint(),
      );
    }

    // Store name (white text), vertically centered
    final nameH = _painter?.height ?? fontSize * 1.5;
    final textY = y + (bandH - nameH) / 2;
    _painter?.paint(canvas, ui.Offset(x, textY));
  }

  void _paintTwoColumnRow(
    ui.Canvas canvas,
    double x,
    double y,
    double contentWidth,
  ) {
    final rowH = fontSize * 1.7;
    final halfW = contentWidth / 2;
    final ff = fontFamily.isNotEmpty ? fontFamily : 'IBMPlexSansArabic';

    // Right label
    if (rightText != null && rightText!.isNotEmpty) {
      final p = _buildPainter(
        rightText!,
        fontSize: fontSize,
        fontWeight: FontWeight.normal,
        fontFamily: ff,
        color: const ui.Color(0xFF333333),
        align: TextAlign.right,
        maxWidth: halfW,
      );
      p.paint(
        canvas,
        ui.Offset(x + contentWidth - p.width, y + (rowH - p.height) / 2),
      );
    }

    // Left value (bold)
    if (leftText != null && leftText!.isNotEmpty) {
      final p = _buildPainter(
        leftText!,
        fontSize: fontSize,
        fontWeight: isTwoColBold ? FontWeight.bold : FontWeight.normal,
        fontFamily: ff,
        color: const ui.Color(0xFF000000),
        align: TextAlign.left,
        maxWidth: halfW,
      );
      p.paint(canvas, ui.Offset(x, y + (rowH - p.height) / 2));
    }
  }

  void _paintTableRow(
    ui.Canvas canvas,
    double x,
    double y,
    double contentWidth,
  ) {
    final cellsList = cells;
    if (cellsList == null || cellsList.isEmpty) return;

    final colW = contentWidth / cellsList.length;
    final rowH = fontSize * 1.8 + 6;
    final isHeader = cellsList.any((c) => c.isHeader);

    // Header: dark fill
    if (isHeader) {
      canvas.drawRect(
        ui.Rect.fromLTWH(x, y, contentWidth, rowH),
        ui.Paint()..color = const ui.Color(0xFF1A1A1A),
      );
    }

    for (var i = 0; i < cellsList.length; i++) {
      final cell = cellsList[i];
      final textColor = isHeader
          ? const ui.Color(0xFFFFFFFF)
          : (cell.isTotal
                ? const ui.Color(0xFF000000)
                : const ui.Color(0xFF222222));

      final p = _buildPainter(
        cell.text,
        fontSize: fontSize * (cell.isTotal ? 1.05 : 1.0),
        fontWeight: (cell.isHeader || cell.isTotal)
            ? FontWeight.bold
            : FontWeight.normal,
        fontFamily: 'IBMPlexSansArabic',
        color: textColor,
        align: TextAlign.center,
        maxWidth: colW,
      );
      final cx = x + i * colW + (colW - p.width) / 2;
      p.paint(canvas, ui.Offset(cx, y + (rowH - p.height) / 2));
    }

    // Row separator
    canvas.drawLine(
      ui.Offset(x, y + rowH),
      ui.Offset(x + contentWidth, y + rowH),
      ui.Paint()
        ..color = const ui.Color(0xFFCCCCCC)
        ..strokeWidth = 0.5,
    );

    // Column separators
    for (var i = 1; i < cellsList.length; i++) {
      canvas.drawLine(
        ui.Offset(x + i * colW, y),
        ui.Offset(x + i * colW, y + rowH),
        ui.Paint()
          ..color = const ui.Color(0xFFCCCCCC)
          ..strokeWidth = 0.5,
      );
    }
  }

  void _paintSummaryBox(
    ui.Canvas canvas,
    double x,
    double y,
    double contentWidth,
  ) {
    final rows = summaryRows;
    if (rows == null || rows.isEmpty) return;

    final boxH = height;

    // Outer border
    canvas.drawRect(
      ui.Rect.fromLTWH(x, y, contentWidth, boxH),
      ui.Paint()
        ..style = ui.PaintingStyle.stroke
        ..color = const ui.Color(0xFF000000)
        ..strokeWidth = 1.5,
    );

    final rowH = fontSize * 2.0;

    for (var i = 0; i < rows.length; i++) {
      final r = rows[i];
      final ry = y + 9 + i * rowH;

      // Highlight total row
      if (r.isTotal) {
        canvas.drawRect(
          ui.Rect.fromLTWH(x + 1.5, ry - 2, contentWidth - 3, rowH),
          ui.Paint()..color = const ui.Color(0xFFEEEEEE),
        );
        // Divider above total
        canvas.drawLine(
          ui.Offset(x, ry - 3),
          ui.Offset(x + contentWidth, ry - 3),
          ui.Paint()
            ..color = const ui.Color(0xFF000000)
            ..strokeWidth = 0.8,
        );
      }

      final halfW = contentWidth / 2;
      final fw = r.isTotal ? FontWeight.bold : FontWeight.normal;

      // Label (right side)
      final labelP = _buildPainter(
        r.label,
        fontSize: r.isTotal ? fontSize * 1.05 : fontSize,
        fontWeight: fw,
        fontFamily: 'IBMPlexSansArabic',
        color: const ui.Color(0xFF000000),
        align: TextAlign.right,
        maxWidth: halfW - 8,
      );
      labelP.paint(canvas, ui.Offset(x + contentWidth - labelP.width - 6, ry));

      // Value (left side)
      final valP = _buildPainter(
        r.value,
        fontSize: r.isTotal ? fontSize * 1.1 : fontSize,
        fontWeight: fw,
        fontFamily: 'IBMPlexSansArabic',
        color: const ui.Color(0xFF000000),
        align: TextAlign.left,
        maxWidth: halfW - 8,
      );
      valP.paint(canvas, ui.Offset(x + 6, ry));
    }
  }

  // ─── Text painter helper ─────────────────────────────────────────────────

  static TextPainter _buildPainter(
    String text, {
    required double fontSize,
    required FontWeight fontWeight,
    required String fontFamily,
    required ui.Color color,
    required TextAlign align,
    required double maxWidth,
  }) {
    final p = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          fontSize: fontSize,
          fontWeight: fontWeight,
          fontFamily: fontFamily,
          color: color,
        ),
      ),
      textDirection: ui.TextDirection.rtl,
      textAlign: align,
    )..layout(maxWidth: maxWidth.clamp(1.0, double.infinity));
    return p;
  }
}
