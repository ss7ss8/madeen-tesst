import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants/colors.dart';
import '../../core/services/notification_service.dart';
import '../../core/utils/logger.dart';
import '../../core/services/supabase_service.dart';
import '../../core/services/sync_service.dart';
import '../../data/local/hive_service.dart';
import '../../data/models/settings.dart';

// ─── Settings Provider ────────────────────────────────────────────────────────

final settingsProvider = StateNotifierProvider<SettingsNotifier, AppSettings>((
  ref,
) {
  return SettingsNotifier();
});

class SettingsNotifier extends StateNotifier<AppSettings> {
  SettingsNotifier() : super(HiveService.getAppSettings());

  Future<void> update(AppSettings newSettings) async {
    final userId = SupabaseService.currentUser?.id;
    String? finalLogoPath = newSettings.storeLogoPath;

    if (finalLogoPath != null &&
        finalLogoPath.isNotEmpty &&
        !finalLogoPath.startsWith('http') &&
        userId != null) {
      try {
        final publicUrl = await SupabaseService.uploadStoreLogo(
          userId,
          finalLogoPath,
        );
        if (publicUrl != null) {
          finalLogoPath = publicUrl;
        }
      } catch (e) {
        appLogger.warning('Store logo upload failed: $e');
      }
    }

    final updatedSettings = newSettings.copyWith(storeLogoPath: finalLogoPath);
    await HiveService.saveAppSettings(updatedSettings);
    state = updatedSettings;
    await NotificationService.scheduleFromSettings(updatedSettings);
    // Push settings to cloud so they survive app reinstall.
    // Fire-and-forget: failures are logged inside syncSettings() and
    // won't block the UI.
    SyncService.syncSettings().catchError((_) {});
  }
}

// ─── Theme Providers ──────────────────────────────────────────────────────────

final themeModeProvider = StateNotifierProvider<ThemeModeNotifier, ThemeMode>((
  ref,
) {
  return ThemeModeNotifier(ref);
});

final themeColorProvider = StateNotifierProvider<ThemeColorNotifier, Color>((
  ref,
) {
  return ThemeColorNotifier(ref);
});

final fontFamilyProvider = StateNotifierProvider<FontFamilyNotifier, String>((
  ref,
) {
  return FontFamilyNotifier(ref);
});

final backgroundProvider =
    StateNotifierProvider<BackgroundNotifier, BackgroundConfig>((ref) {
      return BackgroundNotifier(ref);
    });

// Helper: parse hex color string like '0xFF2563EB'
Color _parseColor(String? hex) {
  if (hex == null || hex.isEmpty) return AppColors.primary;
  try {
    final cleanHex = hex.startsWith('0x') ? hex.substring(2) : hex;
    return Color(int.parse(cleanHex, radix: 16));
  } catch (_) {
    return AppColors.primary;
  }
}

class ThemeModeNotifier extends StateNotifier<ThemeMode> {
  final Ref _ref;
  ThemeModeNotifier(this._ref) : super(ThemeMode.system) {
    state = _ref.read(settingsProvider).darkMode
        ? ThemeMode.dark
        : ThemeMode.light;
  }

  Future<void> toggle() async {
    final isDark = state == ThemeMode.dark;
    state = isDark ? ThemeMode.light : ThemeMode.dark;
    final s = _ref.read(settingsProvider);
    await _ref
        .read(settingsProvider.notifier)
        .update(s.copyWith(darkMode: !isDark));
  }
}

class ThemeColorNotifier extends StateNotifier<Color> {
  final Ref _ref;
  ThemeColorNotifier(this._ref) : super(AppColors.primary) {
    state = _parseColor(_ref.read(settingsProvider).themeColorHex);
  }

  Future<void> setColor(Color color) async {
    state = color;
    final s = _ref.read(settingsProvider);
    await _ref
        .read(settingsProvider.notifier)
        .update(
          s.copyWith(themeColorHex: '0x${color.toARGB32().toRadixString(16)}'),
        );
  }
}

class FontFamilyNotifier extends StateNotifier<String> {
  final Ref _ref;
  FontFamilyNotifier(this._ref) : super('IBM Plex Sans Arabic') {
    state = _ref.read(settingsProvider).fontFamily;
  }

  Future<void> setFontFamily(String fontFamily) async {
    state = fontFamily;
    final s = _ref.read(settingsProvider);
    await _ref
        .read(settingsProvider.notifier)
        .update(s.copyWith(fontFamily: fontFamily));
  }
}

// ─── Background Config ────────────────────────────────────────────────────────

class BackgroundConfig {
  final String type; // 'solid', 'gradient', 'image'
  final Color? solidColor;
  final Color? gradientStart;
  final Color? gradientEnd;
  final String? imagePath;

  BackgroundConfig({
    required this.type,
    this.solidColor,
    this.gradientStart,
    this.gradientEnd,
    this.imagePath,
  });

  BackgroundConfig copyWith({
    String? type,
    Color? solidColor,
    Color? gradientStart,
    Color? gradientEnd,
    String? imagePath,
  }) {
    return BackgroundConfig(
      type: type ?? this.type,
      solidColor: solidColor ?? this.solidColor,
      gradientStart: gradientStart ?? this.gradientStart,
      gradientEnd: gradientEnd ?? this.gradientEnd,
      imagePath: imagePath ?? this.imagePath,
    );
  }
}

class BackgroundNotifier extends StateNotifier<BackgroundConfig> {
  final Ref _ref;
  BackgroundNotifier(this._ref)
    : super(
        BackgroundConfig(type: 'solid', solidColor: AppColors.backgroundLight),
      ) {
    _load();
  }

  void _load() {
    final s = _ref.read(settingsProvider);
    switch (s.backgroundType) {
      case 'gradient':
        state = BackgroundConfig(
          type: 'gradient',
          gradientStart: _parseColor(s.backgroundGradientStartHex),
          gradientEnd: _parseColor(s.backgroundGradientEndHex),
        );
        break;
      case 'image':
        state = BackgroundConfig(
          type: 'image',
          imagePath: s.backgroundImagePath,
        );
        break;
      default:
        state = BackgroundConfig(
          type: 'solid',
          solidColor: _parseColor(s.backgroundColorHex),
        );
    }
  }

  Future<void> setSolidColor(Color color) async {
    state = BackgroundConfig(type: 'solid', solidColor: color);
    final s = _ref.read(settingsProvider);
    await _ref
        .read(settingsProvider.notifier)
        .update(
          s.copyWith(
            backgroundType: 'solid',
            backgroundColorHex: '0x${color.toARGB32().toRadixString(16)}',
          ),
        );
  }

  Future<void> setGradient(Color start, Color end) async {
    state = BackgroundConfig(
      type: 'gradient',
      gradientStart: start,
      gradientEnd: end,
    );
    final s = _ref.read(settingsProvider);
    await _ref
        .read(settingsProvider.notifier)
        .update(
          s.copyWith(
            backgroundType: 'gradient',
            backgroundGradientStartHex:
                '0x${start.toARGB32().toRadixString(16)}',
            backgroundGradientEndHex: '0x${end.toARGB32().toRadixString(16)}',
          ),
        );
  }

  Future<void> setImage(String imagePath) async {
    state = BackgroundConfig(type: 'image', imagePath: imagePath);
    final s = _ref.read(settingsProvider);
    await _ref
        .read(settingsProvider.notifier)
        .update(
          s.copyWith(backgroundType: 'image', backgroundImagePath: imagePath),
        );
  }
}
