import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../../core/utils/logger.dart';
import '../../data/local/hive_service.dart';
import '../../data/models/customer.dart';
import '../../data/models/debt.dart';
import '../../data/models/payment.dart';
import '../../core/utils/formatters.dart';
import '../../features/customers/providers/statement_provider.dart';

// White with alpha — PdfColors doesn't provide white30/white70.
const _pdfWhite30 = PdfColor(1, 1, 1, 0.3);
const _pdfWhite70 = PdfColor(1, 1, 1, 0.7);

class PdfService {
  static Uint8List? _cachedLogoBytes;
  static String? _cachedLogoPath;

  static String _s(String text) {
    return text;
  }

  pw.Text _text(
    String text, {
    pw.TextStyle? style,
    pw.TextAlign? textAlign,
    pw.TextDirection textDirection = pw.TextDirection.rtl,
  }) {
    return pw.Text(
      _s(text),
      style: style,
      textAlign: textAlign,
      textDirection: textDirection,
    );
  }

  Future<pw.Font> _loadFont(String path) async {
    final data = await rootBundle.load(path);
    return pw.Font.ttf(data);
  }

  /// Returns a copy of [color] with the given [alpha] (0.0–1.0).
  /// PdfColor has no `withValues`/`withOpacity` helper, so we build one.
  PdfColor _withAlpha(PdfColor color, double alpha) {
    return PdfColor(color.red, color.green, color.blue, alpha);
  }

  static double fontScaleFor(String printerType) {
    switch (printerType) {
      case 'thermal_80mm':
        return 0.7;
      case 'thermal_58mm':
        return 0.6;
      default:
        return 1.0;
    }
  }

  static bool isThermal(String printerType) {
    return printerType == 'thermal_80mm' || printerType == 'thermal_58mm';
  }

  static PdfPageFormat pageFormatFor(String printerType) {
    return _pageFormat(printerType);
  }

  static PdfPageFormat _pageFormat(String printerType) {
    switch (printerType) {
      case 'thermal_80mm':
        return PdfPageFormat(
          80 * PdfPageFormat.mm,
          1000 * PdfPageFormat.mm,
          marginAll: 5 * PdfPageFormat.mm,
        );
      case 'thermal_58mm':
        return PdfPageFormat(
          58 * PdfPageFormat.mm,
          1000 * PdfPageFormat.mm,
          marginAll: 4 * PdfPageFormat.mm,
        );
      default:
        return PdfPageFormat.a4;
    }
  }

  /// يقيس ارتفاع [content] المُصيَّر فعلياً بعرض [width] عبر تمريرة تخطيط
  /// حقيقية (Layout Pass)، لاستخدامه كارتفاع ديناميكي لصفحة الطابعة الحرارية
  /// بحيث تُقصّ الورقة بعد المحتوى مباشرة دون فراغ ثابت أو لانهائي.
  static Future<double> _measureContentHeight(
    pw.Widget content,
    double width,
    pw.ThemeData theme,
  ) async {
    final doc = pw.Document();
    final ctx = pw.Context(document: doc.document);
    final wrapped = pw.Theme(data: theme, child: content);
    wrapped.layout(ctx, pw.BoxConstraints(maxWidth: width));
    final h = wrapped.box?.height;
    if (h == null) {
      throw StateError('تعذّر قياس ارتفاع محتوى صفحة الطابعة الحرارية');
    }
    return h;
  }

  /// يبني [PdfPageFormat] لطابعة حرارية بعرض ثابت وارتفاع مُقاس ديناميكياً
  /// حسب المحتوى الفعلي + هامش أمان بسيط (8mm). لا يستخدم أي رقم ثابت
  /// للارتفاع (لا 1000mm ولا double.infinity).
  static Future<PdfPageFormat> _thermalPageFormat(
    String printerType,
    pw.Widget content,
    pw.ThemeData theme,
  ) async {
    final width =
        (printerType == 'thermal_58mm' ? 58.0 : 80.0) * PdfPageFormat.mm;
    final margin =
        (printerType == 'thermal_58mm' ? 4.0 : 5.0) * PdfPageFormat.mm;
    final contentWidth = width - margin * 2;
    final measured = await _measureContentHeight(content, contentWidth, theme);
    const safety = 8.0 * PdfPageFormat.mm;
    return PdfPageFormat(
      width,
      measured + margin * 2 + safety,
      marginAll: margin,
    );
  }

  /// Fetches logo bytes from a network URL or reads from a local file path.
  /// The raw image is decoded, downscaled to a max edge of 200px (preserving
  /// aspect ratio), and re-encoded as JPEG/q85 — so large store-logo photos
  /// don't bloat the PDF render or the network download.
  Future<Uint8List?> _fetchLogoBytes(String? logoPath) async {
    if (logoPath == null || logoPath.isEmpty) return null;
    if (_cachedLogoBytes != null && _cachedLogoPath == logoPath) {
      return _cachedLogoBytes;
    }
    _cachedLogoPath = logoPath;
    _cachedLogoBytes = null;
    Uint8List? rawBytes;
    try {
      if (logoPath.startsWith('http://') || logoPath.startsWith('https://')) {
        final client = HttpClient();
        final request = await client.getUrl(Uri.parse(logoPath));
        final response = await request.close();
        final bytes = <int>[];
        await for (final chunk in response) {
          bytes.addAll(chunk);
        }
        client.close();
        rawBytes = Uint8List.fromList(bytes);
      } else {
        final file = File(logoPath);
        if (await file.exists()) {
          rawBytes = await file.readAsBytes();
        }
      }
    } catch (_) {
      // If logo fetch fails, continue without logo
    }
    if (rawBytes == null) return null;

    final swResize = Stopwatch()..start();
    try {
      final decoded = img.decodeImage(rawBytes);
      if (decoded != null) {
        final maxEdge = 200;
        img.Image resized;
        if (decoded.width > maxEdge || decoded.height > maxEdge) {
          // Fit within a maxEdge square, preserving aspect ratio.
          resized = img.copyResize(
            decoded,
            width: decoded.width >= decoded.height ? maxEdge : -1,
            height: decoded.height > decoded.width ? maxEdge : -1,
          );
        } else {
          resized = decoded;
        }
        final out = img.encodeJpg(resized, quality: 85);
        appLogger.info(
          'logo resize: ${decoded.width}x${decoded.height} -> '
          '${resized.width}x${resized.height} '
          '${rawBytes.length}->${out.length} bytes '
          'in ${swResize.elapsedMilliseconds}ms',
        );
        return Uint8List.fromList(out);
      }
    } catch (e) {
      appLogger.warning('logo resize failed, using raw bytes: $e');
    }
    _cachedLogoBytes = rawBytes;
    return rawBytes;
  }

  Future<File> generateInvoice({
    required Customer customer,
    required List<Debt> debts,
    required String storeName,
    String? storeLogoPath,
    String? storePhone,
    String printerType = 'a4',
  }) async {
    final pdf = pw.Document();
    final arabicFont = await _loadFont('assets/fonts/Amiri-Regular.ttf');
    final arabicFontBold = await _loadFont('assets/fonts/Amiri-Bold.ttf');
    final logoBytes = await _fetchLogoBytes(storeLogoPath);

    // Fetch payments for all debts so they appear in the running balance table
    final allPayments = <Payment>[];
    for (final d in debts) {
      allPayments.addAll(HiveService.getPaymentsByDebt(d.id));
    }

    final theme = pw.ThemeData.withFont(base: arabicFont, bold: arabicFontBold);
    final content = pw.Directionality(
      textDirection: pw.TextDirection.rtl,
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: [
          _buildHeader(storeName, logoBytes, storePhone, printerType),
          pw.SizedBox(height: 16),
          _buildInvoiceMeta(
            customer,
            printerType: printerType,
            invoiceNumber: debts.isNotEmpty && debts.first.invoiceNumber != null
                ? '#${debts.first.invoiceNumber}'
                : null,
          ),
          pw.SizedBox(height: 16),
          _buildRunningBalanceTable(debts, allPayments, printerType),
          pw.SizedBox(height: 16),
          _buildSummaryBlock(debts, printerType),
          if (printerType == 'a4') pw.Spacer(),
          _buildFooter(printerType),
        ],
      ),
    );

    final pageFormat = isThermal(printerType)
        ? await _thermalPageFormat(printerType, content, theme)
        : _pageFormat(printerType);

    pdf.addPage(
      pw.Page(
        pageFormat: pageFormat,
        theme: theme,
        build: (pw.Context context) => content,
      ),
    );

    final directory = await getApplicationDocumentsDirectory();
    final file = File(
      '${directory.path}/invoice_${customer.name}_${DateTime.now().millisecondsSinceEpoch}.pdf',
    );
    await file.writeAsBytes(await pdf.save());
    return file;
  }

  Future<File> generateSelectedOperationsInvoice({
    required Customer customer,
    required List<Debt> selectedDebts,
    required List<Payment> selectedPayments,
    required String storeName,
    String? storeLogoPath,
    String? storePhone,
    String printerType = 'a4',
  }) async {
    final pdf = pw.Document();
    final arabicFont = await _loadFont('assets/fonts/Amiri-Regular.ttf');
    final arabicFontBold = await _loadFont('assets/fonts/Amiri-Bold.ttf');
    final logoBytes = await _fetchLogoBytes(storeLogoPath);

    // Collect every debt that is involved: explicitly selected debts PLUS the
    // parent debts of any selected payment. This guarantees that when the user
    // prints a single payment, the purchased item (type + price) is also shown.
    final selectedDebtIds = selectedDebts.map((d) => d.id).toSet();
    final paymentDebtIds = selectedPayments.map((p) => p.debtId).toSet();
    final involvedDebtIds = <String>{...selectedDebtIds, ...paymentDebtIds};

    // Resolve full Debt objects for every involved debt id so we can read the
    // real amount / paidAmount / productName for both the table and the totals.
    final allDebts = HiveService.getAllDebts();
    final involvedDebts = <String, Debt>{};
    for (final d in allDebts) {
      if (involvedDebtIds.contains(d.id)) {
        involvedDebts[d.id] = d;
      }
    }

    // Build rows from involved debts + their selected payments. The purchase
    // (debt) row is always emitted first so the item type (product name) and
    // price (debt amount) are visible even when only a payment was selected.
    final rows = <Map<String, dynamic>>[];
    for (final debtId in involvedDebtIds) {
      final debt = involvedDebts[debtId];
      if (debt == null) continue;
      final itemLabel = debt.productName ?? 'دين';
      rows.add({
        'date': debt.createdAt,
        'desc': itemLabel,
        'debt': debt.amount,
        'payment': 0.0,
      });
      // Add the selected payments for this debt, annotated with the item type
      // so the payment row mentions what the customer purchased.
      for (final p in selectedPayments.where((p) => p.debtId == debt.id)) {
        rows.add({
          'date': p.createdAt,
          'desc': 'تسديد — $itemLabel',
          'debt': 0.0,
          'payment': p.amount,
        });
      }
    }
    rows.sort(
      (a, b) => (a['date'] as DateTime).compareTo(b['date'] as DateTime),
    );
    // Compute running balance in chronological order
    double runningBalance = 0;
    for (final row in rows) {
      runningBalance += (row['debt'] as double);
      runningBalance -= (row['payment'] as double);
      row['balance'] = runningBalance;
    }

    // Compute the summary totals from the real debt records so they reflect
    // the actual account state (total debt, total paid, balance due) rather
    // than just the selected rows. This keeps the balance due meaningful even
    // when only a single payment is printed.
    double totalDebt = 0;
    double totalPaid = 0;
    for (final debtId in involvedDebtIds) {
      final debt = involvedDebts[debtId];
      if (debt == null) continue;
      totalDebt += debt.amount;
      totalPaid += debt.paidAmount;
    }
    final balanceDue = totalDebt - totalPaid;

    final theme = pw.ThemeData.withFont(base: arabicFont, bold: arabicFontBold);
    final content = pw.Directionality(
      textDirection: pw.TextDirection.rtl,
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: [
          _buildHeader(storeName, logoBytes, storePhone, printerType),
          pw.SizedBox(height: 16),
          _buildInvoiceMeta(
            customer,
            printerType: printerType,
            invoiceNumber:
                selectedDebts.isNotEmpty &&
                    selectedDebts.first.invoiceNumber != null
                ? '#${selectedDebts.first.invoiceNumber}'
                : 'OPS-${DateTime.now().millisecondsSinceEpoch.toString().substring(5, 13)}',
          ),
          pw.SizedBox(height: 16),
          _buildCustomTable(rows, printerType),
          pw.SizedBox(height: 16),
          _buildSummaryContainer(
            totalDebt: totalDebt,
            totalPaid: totalPaid,
            remaining: balanceDue,
            printerType: printerType,
          ),
          if (printerType == 'a4') pw.Spacer(),
          _buildFooter(printerType),
        ],
      ),
    );

    final pageFormat = isThermal(printerType)
        ? await _thermalPageFormat(printerType, content, theme)
        : _pageFormat(printerType);

    pdf.addPage(
      pw.Page(
        pageFormat: pageFormat,
        theme: theme,
        build: (pw.Context context) => content,
      ),
    );

    final directory = await getApplicationDocumentsDirectory();
    final file = File(
      '${directory.path}/invoice_${customer.name}_${DateTime.now().millisecondsSinceEpoch}.pdf',
    );
    await file.writeAsBytes(await pdf.save());
    return file;
  }

  pw.Widget _buildHeader(
    String storeName,
    Uint8List? logoBytes,
    String? storePhone,
    String printerType,
  ) {
    final s = fontScaleFor(printerType);
    final thermal = isThermal(printerType);
    return pw.Container(
      padding: pw.EdgeInsets.all(thermal ? 8 : 16),
      decoration: pw.BoxDecoration(
        color: PdfColors.blue50,
        borderRadius: pw.BorderRadius.circular(8),
        border: pw.Border.all(color: PdfColors.blue200),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        crossAxisAlignment: pw.CrossAxisAlignment.center,
        children: [
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                _text(
                  storeName,
                  style: pw.TextStyle(
                    fontSize: 22 * s,
                    fontWeight: pw.FontWeight.bold,
                    color: PdfColors.blue800,
                  ),
                ),
                if (storePhone != null && storePhone.isNotEmpty)
                  _text(
                    'هاتف: $storePhone',
                    style: pw.TextStyle(
                      fontSize: 12 * s,
                      color: PdfColors.grey700,
                    ),
                  ),
              ],
            ),
          ),
          if (logoBytes != null)
            pw.Container(
              width: thermal ? 40 : 60,
              height: thermal ? 40 : 60,
              child: pw.Image(
                pw.MemoryImage(logoBytes),
                fit: pw.BoxFit.contain,
              ),
            ),
        ],
      ),
    );
  }

  pw.Widget _buildInvoiceMeta(
    Customer customer, {
    required String printerType,
    String? invoiceNumber,
  }) {
    final s = fontScaleFor(printerType);
    final thermal = isThermal(printerType);
    final inv =
        invoiceNumber ??
        '#${DateTime.now().millisecondsSinceEpoch.toString().substring(5, 13)}';
    return pw.Container(
      padding: pw.EdgeInsets.all(thermal ? 6 : 12),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Row(
        children: [
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                _text(
                  'فاتورة رقم: $inv',
                  style: pw.TextStyle(
                    fontWeight: pw.FontWeight.bold,
                    fontSize: 12 * s,
                  ),
                ),
                pw.SizedBox(height: 4),
                _text(
                  'التاريخ: ${Formatters.formatDate(DateTime.now())}',
                  style: pw.TextStyle(
                    fontSize: 11 * s,
                    color: PdfColors.grey700,
                  ),
                ),
                pw.SizedBox(height: 8),
                _text(
                  'اسم الزبون: ${customer.name}',
                  style: pw.TextStyle(
                    fontWeight: pw.FontWeight.bold,
                    fontSize: 12 * s,
                  ),
                ),
                if (customer.phone != null)
                  _text(
                    'رقم الهاتف: ${customer.phone}',
                    style: pw.TextStyle(
                      fontSize: 11 * s,
                      color: PdfColors.grey700,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  pw.Widget _buildRunningBalanceTable(
    List<Debt> debts,
    List<Payment> payments,
    String printerType,
  ) {
    final rows = <Map<String, dynamic>>[];

    for (final debt in debts) {
      rows.add({
        'date': debt.createdAt,
        'desc': debt.productName ?? 'دين',
        'debt': debt.amount,
        'payment': 0.0,
      });
      // Insert payments belonging to this debt
      for (final p in payments.where((p) => p.debtId == debt.id)) {
        rows.add({
          'date': p.createdAt,
          'desc': 'تسديد',
          'debt': 0.0,
          'payment': p.amount,
        });
      }
    }
    rows.sort(
      (a, b) => (a['date'] as DateTime).compareTo(b['date'] as DateTime),
    );
    // Compute running balance in chronological order
    double balance = 0;
    for (final row in rows) {
      balance += (row['debt'] as double);
      balance -= (row['payment'] as double);
      row['balance'] = balance;
    }

    return _buildCustomTable(rows, printerType);
  }

  pw.Widget _buildCustomTable(
    List<Map<String, dynamic>> rows,
    String printerType,
  ) {
    final s = fontScaleFor(printerType);
    final thermal = isThermal(printerType);
    return pw.Table(
      border: pw.TableBorder.all(color: PdfColors.grey300),
      columnWidths: {
        0: pw.FixedColumnWidth(thermal ? 50 : 70),
        1: const pw.FlexColumnWidth(2),
        2: pw.FixedColumnWidth(thermal ? 55 : 80),
        3: pw.FixedColumnWidth(thermal ? 55 : 80),
        4: pw.FixedColumnWidth(thermal ? 60 : 90),
      },
      children: [
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: PdfColors.grey200),
          children: [
            _buildTableCell('التاريخ', isHeader: true, scale: s),
            _buildTableCell('البيان', isHeader: true, scale: s),
            _buildTableCell('الدين', isHeader: true, scale: s),
            _buildTableCell('السداد', isHeader: true, scale: s),
            _buildTableCell('الرصيد', isHeader: true, scale: s),
          ],
        ),
        ...rows.map((row) {
          final debtVal = row['debt'] as double;
          final payVal = row['payment'] as double;
          final balVal = row['balance'] as double;
          return pw.TableRow(
            children: [
              _buildTableCell(
                Formatters.formatDate(row['date'] as DateTime),
                scale: s,
              ),
              _buildTableCell(row['desc'] as String, scale: s),
              _buildTableCell(
                debtVal > 0 ? Formatters.formatAmount(debtVal) : '-',
                color: debtVal > 0 ? PdfColors.red : null,
                scale: s,
              ),
              _buildTableCell(
                payVal > 0 ? Formatters.formatAmount(payVal) : '-',
                color: payVal > 0 ? PdfColors.green : null,
                scale: s,
              ),
              _buildTableCell(
                Formatters.formatAmount(balVal),
                color: balVal > 0 ? PdfColors.red : PdfColors.green,
                isBold: true,
                scale: s,
              ),
            ],
          );
        }),
      ],
    );
  }

  pw.Widget _buildSummaryBlock(List<Debt> debts, String printerType) {
    final totalDebt = debts.fold<double>(0, (s, d) => s + d.amount);
    final totalPaid = debts.fold<double>(0, (s, d) => s + d.paidAmount);
    final remaining = totalDebt - totalPaid;

    return _buildSummaryContainer(
      totalDebt: totalDebt,
      totalPaid: totalPaid,
      remaining: remaining,
      printerType: printerType,
    );
  }

  pw.Widget _buildSummaryContainer({
    required double totalDebt,
    required double totalPaid,
    required double remaining,
    required String printerType,
  }) {
    final s = fontScaleFor(printerType);
    final thermal = isThermal(printerType);
    return pw.Container(
      padding: pw.EdgeInsets.all(thermal ? 8 : 12),
      decoration: pw.BoxDecoration(
        color: PdfColors.grey100,
        borderRadius: pw.BorderRadius.circular(8),
        border: pw.Border.all(color: PdfColors.grey300),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: [
          _buildSummaryRow(
            'إجمالي الدين:',
            Formatters.formatCurrency(totalDebt),
            scale: s,
          ),
          pw.SizedBox(height: 6),
          _buildSummaryRow(
            'إجمالي المدفوع:',
            Formatters.formatCurrency(totalPaid),
            color: PdfColors.green,
            scale: s,
          ),
          pw.Divider(color: PdfColors.grey300),
          _buildSummaryRow(
            'الرصيد المستحق:',
            Formatters.formatCurrency(remaining),
            color: remaining > 0 ? PdfColors.red : PdfColors.green,
            isBold: true,
            fontSize: 14 * s,
            scale: s,
          ),
        ],
      ),
    );
  }

  pw.Widget _buildSummaryRow(
    String label,
    String value, {
    PdfColor? color,
    bool isBold = false,
    double fontSize = 12,
    double scale = 1.0,
  }) {
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        _text(
          label,
          style: pw.TextStyle(
            fontSize: fontSize,
            fontWeight: isBold ? pw.FontWeight.bold : null,
          ),
        ),
        _text(
          value,
          style: pw.TextStyle(
            fontSize: fontSize,
            fontWeight: isBold ? pw.FontWeight.bold : null,
            color: color,
          ),
        ),
      ],
    );
  }

  pw.Widget _buildTableCell(
    String text, {
    bool isHeader = false,
    PdfColor? color,
    bool isBold = false,
    double scale = 1.0,
  }) {
    return pw.Container(
      padding: pw.EdgeInsets.all(scale < 1 ? 4 : 6),
      child: _text(
        text,
        textAlign: pw.TextAlign.center,
        style: pw.TextStyle(
          fontSize: (isHeader ? 11 : 10) * scale,
          fontWeight: isHeader || isBold ? pw.FontWeight.bold : null,
          color: color,
        ),
      ),
    );
  }

  pw.Widget _buildFooter(String printerType) {
    final s = fontScaleFor(printerType);
    return pw.Column(
      children: [
        pw.Divider(color: PdfColors.grey300),
        pw.SizedBox(height: 6),
        _text(
          'شكراً لتعاملكم معنا',
          style: pw.TextStyle(fontSize: 13 * s, color: PdfColors.grey700),
        ),
        pw.SizedBox(height: 4),
        _text(
          'يُرجى الاحتفاظ بهذه الفاتورة',
          style: pw.TextStyle(fontSize: 10 * s, color: PdfColors.grey500),
        ),
        pw.SizedBox(height: 4),
        _text(
          'تم إنشاء هذه الفاتورة عبر تطبيق مدين',
          style: pw.TextStyle(fontSize: 9 * s, color: PdfColors.grey400),
        ),
      ],
    );
  }

  /// Generates a professional multi-page A4 account statement (كشف حساب)
  /// for a customer, including all purchases (debt & cash) and payments
  /// with a running balance, store name, and customer name.
  ///
  /// The layout is designed to look polished and organized like global
  /// banking/invoicing apps: a colored banner header, boxed summary cards,
  /// a zebra-striped transactions table, a highlighted totals box, and
  /// signature lines for both parties.
  Future<File> generateAccountStatement({
    required Customer customer,
    required AccountStatement statement,
    required String storeName,
    String? storeLogoPath,
    String? storePhone,
    String printerType = 'a4',
  }) async {
    final sw = Stopwatch()..start();
    final pdf = await _buildStatementDocument(
      customer: customer,
      statement: statement,
      storeName: storeName,
      storeLogoPath: storeLogoPath,
      storePhone: storePhone,
      printerType: printerType,
    );

    final directory = await getApplicationDocumentsDirectory();
    final file = File(
      '${directory.path}/statement_${customer.name}_${DateTime.now().millisecondsSinceEpoch}.pdf',
    );
    final swSave = Stopwatch()..start();
    await file.writeAsBytes(await pdf.save());
    appLogger.info(
      'statement: pdf.save()=${swSave.elapsedMilliseconds}ms',
    );
    appLogger.info('generateAccountStatement took ${sw.elapsedMilliseconds}ms');
    return file;
  }

  /// Opens the native print dialog with the account statement, allowing the
  /// user to print directly to a connected printer or "Save as PDF". This
  /// reuses the same polished layout as [generateAccountStatement].
  Future<void> printAccountStatement({
    required Customer customer,
    required AccountStatement statement,
    required String storeName,
    String? storeLogoPath,
    String? storePhone,
    String printerType = 'a4',
  }) async {
    await Printing.layoutPdf(
      name: 'كشف حساب - ${customer.name}',
      onLayout: (PdfPageFormat format) async {
        final pdf = await _buildStatementDocument(
          customer: customer,
          statement: statement,
          storeName: storeName,
          storeLogoPath: storeLogoPath,
          storePhone: storePhone,
          printerType: printerType,
        );
        return pdf.save();
      },
    );
  }

  /// Builds the account statement [pw.Document] shared by both the file
  /// export and the direct-print flows.
  Future<pw.Document> _buildStatementDocument({
    required Customer customer,
    required AccountStatement statement,
    required String storeName,
    String? storeLogoPath,
    String? storePhone,
    String printerType = 'a4',
  }) async {
    final pdf = pw.Document();
    final swFont1 = Stopwatch()..start();
    final arabicFont = await _loadFont('assets/fonts/Amiri-Regular.ttf');
    final swFont1Ms = swFont1.elapsedMilliseconds;
    final swFont2 = Stopwatch()..start();
    final arabicFontBold = await _loadFont('assets/fonts/Amiri-Bold.ttf');
    appLogger.info(
      'statement: _loadFont Amiri-Regular=${swFont1Ms}ms, Amiri-Bold=${swFont2.elapsedMilliseconds}ms',
    );
    final swLogo = Stopwatch()..start();
    final logoBytes = await _fetchLogoBytes(storeLogoPath);
    appLogger.info(
      'statement: _fetchLogoBytes=${swLogo.elapsedMilliseconds}ms',
    );

    const staticTexts = <String, String>{
      'meta.الاسم': 'الاسم',
      'meta.الهاتف': 'الهاتف',
      'meta.تاريخ الإصدار': 'تاريخ الإصدار',
      'meta.الفترة': 'الفترة',
      'meta.رقم الكشف': 'رقم الكشف',
      'header.هاتف: ': 'هاتف: ',
      'section.ملخص الحركة': 'ملخص الحركة',
      'section.سجل العمليات': 'سجل العمليات',
      'section.ملخص الحساب': 'ملخص الحساب',
      'summary.إجمالي المشتريات': 'إجمالي المشتريات',
      'summary.مشتريات بالدين': 'مشتريات بالدين',
      'summary.مشتريات نقدية': 'مشتريات نقدية',
      'summary.إجمالي المدفوع': 'إجمالي المدفوع',
      'table.#': '#',
      'table.التاريخ': 'التاريخ',
      'table.البيان': 'البيان',
      'table.النوع': 'النوع',
      'table.المبلغ': 'المبلغ',
      'table.الرصيد': 'الرصيد',
      'totals.عدد العمليات:': 'عدد العمليات:',
      'totals.إجمالي المشتريات:': 'إجمالي المشتريات:',
      'totals.إجمالي المدفوع:': 'إجمالي المدفوع:',
      'signature.توقيع الزبون': 'توقيع الزبون',
      'signature.توقيع المسؤول': 'توقيع المسؤول',
      'footer.تم الإنشاء بواسطة تطبيق مدين': 'تم الإنشاء بواسطة تطبيق مدين',
      'footer.صفحة ': 'صفحة ',
      'footer. من ': ' من ',
      'printName.كشف حساب': 'كشف حساب',
    };
    staticTexts.forEach((tag, t) {});

    // Brand colors used across the document.
    const brandBlue = PdfColor.fromInt(0xFF2563EB);
    const brandBlueDark = PdfColor.fromInt(0xFF1D4ED8);
    const brandRed = PdfColor.fromInt(0xFFEF4444);
    const brandGreen = PdfColor.fromInt(0xFF22C55E);
    const brandAmber = PdfColor.fromInt(0xFFF59E0B);

    final theme = pw.ThemeData.withFont(base: arabicFont, bold: arabicFontBold);

    final swWidgets = Stopwatch()..start();
    final header = await _buildStatementHeader(
      storeName,
      logoBytes,
      storePhone,
      customer,
      statement,
      brandBlue: brandBlue,
      brandBlueDark: brandBlueDark,
    );

    final summary = await _buildStatementSummary(
      statement,
      brandBlue: brandBlue,
      brandRed: brandRed,
      brandGreen: brandGreen,
      brandAmber: brandAmber,
    );

    String? listSvg;
    String? pieChartSvg;
    String? personSvg;
    String? pencilSvg;
    String? receiptSvg;
    try {
      listSvg = await rootBundle.loadString('assets/icon/statement/list.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: list.svg — $e');
    }
    try {
      pieChartSvg = await rootBundle.loadString('assets/icon/statement/pie_chart.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: pie_chart.svg — $e');
    }
    try {
      personSvg = await rootBundle.loadString('assets/icon/statement/person.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: person.svg — $e');
    }
    try {
      pencilSvg = await rootBundle.loadString('assets/icon/statement/pencil.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: pencil.svg — $e');
    }
    try {
      receiptSvg = await rootBundle.loadString('assets/icon/statement/receipt.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: receipt.svg — $e');
    }

    final bodyChildren = <pw.Widget>[
      pw.SizedBox(height: 6),
      summary,
      pw.SizedBox(height: 10),
      pw.Row(
        children: [
          if (listSvg != null)
            pw.SvgImage(
              svg: listSvg,
              colorFilter: brandBlueDark,
              width: 12,
              height: 12,
            )
          else
            pw.SizedBox.shrink(),
          pw.SizedBox(width: 8),
          _buildSectionTitle('سجل العمليات', brandBlueDark),
        ],
      ),
      pw.SizedBox(height: 8),
      _buildStatementTable(
        statement,
        brandBlue: brandBlue,
        brandRed: brandRed,
        brandGreen: brandGreen,
      ),
      pw.SizedBox(height: 10),
      pw.Row(
        children: [
          if (pieChartSvg != null)
            pw.SvgImage(
              svg: pieChartSvg,
              colorFilter: brandBlueDark,
              width: 12,
              height: 12,
            )
          else
            pw.SizedBox.shrink(),
          pw.SizedBox(width: 8),
          _buildSectionTitle('ملخص الحساب', brandBlueDark),
        ],
      ),
      pw.SizedBox(height: 8),
      _buildStatementTotals(statement, brandGreen: brandGreen),
      pw.SizedBox(height: 32),
      pw.Row(
        children: [
          if (personSvg != null)
            pw.SvgImage(
              svg: personSvg,
              colorFilter: PdfColors.grey700,
              width: 12,
              height: 12,
            )
          else
            pw.SizedBox.shrink(),
          pw.SizedBox(width: 8),
          if (pencilSvg != null)
            pw.SvgImage(
              svg: pencilSvg,
              colorFilter: PdfColors.grey700,
              width: 12,
              height: 12,
            )
          else
            pw.SizedBox.shrink(),
        ],
      ),
      pw.SizedBox(height: 32),
      _buildSignatureSection(),
    ];

    final body = pw.Directionality(
      textDirection: pw.TextDirection.rtl,
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: bodyChildren,
      ),
    );

    if (isThermal(printerType)) {
      final measuredContent = pw.Column(
        children: [header, pw.SizedBox(height: 12), body],
      );
      final pageFormat = await _thermalPageFormat(
        printerType,
        measuredContent,
        theme,
      );
      pdf.addPage(
        pw.Page(
          pageFormat: pageFormat,
          theme: theme,
          build: (pw.Context context) =>
              pw.Column(children: [header, pw.SizedBox(height: 12), body]),
        ),
      );
    } else {
      // One RTL source for the whole page: PageTheme.textDirection wraps
      // header + build + footer callbacks in a single InheritedDirectionality
      // (see pdf's page.dart), so the three callbacks no longer each need
      // their own Directionality wrapper. This keeps header/footer repeating
      // on every page (MultiPage behaviour) — a single Column of
      // header+body+footer cannot be used because it would flow once and
      // stop repeating across pages.
      pdf.addPage(
        pw.MultiPage(
          pageFormat: _pageFormat(printerType),
          theme: theme,
          textDirection: pw.TextDirection.rtl,
          margin: const pw.EdgeInsets.all(28),
          header: (pw.Context context) => header,
          build: (pw.Context context) => [body],
          footer: (pw.Context context) => pw.Container(
            padding: const pw.EdgeInsets.only(top: 8),
            decoration: const pw.BoxDecoration(
              border: pw.Border(
                top: pw.BorderSide(color: PdfColors.grey300, width: 0.5),
              ),
            ),
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                _text(
                  'تم الإنشاء بواسطة تطبيق مدين',
                  style: pw.TextStyle(fontSize: 8, color: PdfColors.grey500),
                ),
                pw.Row(
                  children: [
                    if (receiptSvg != null)
                      pw.SvgImage(
                        svg: receiptSvg,
                        colorFilter: PdfColors.grey600,
                        width: 10,
                        height: 10,
                      )
                    else
                      pw.SizedBox.shrink(),
                    pw.SizedBox(width: 4),
                    _text(
                      'صفحة ${context.pageNumber} من ${context.pagesCount}',
                      style: pw.TextStyle(fontSize: 9, color: PdfColors.grey600),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    }

    appLogger.info(
      'statement: build widgets+pages=${swWidgets.elapsedMilliseconds}ms',
    );

    return pdf;
  }

  /// Colored banner header with store info on one side and customer/statement
  /// meta on the other, separated by a thin accent rule.
  Future<pw.Widget> _buildStatementHeader(
    String storeName,
    Uint8List? logoBytes,
    String? storePhone,
    Customer customer,
    AccountStatement statement, {
    required PdfColor brandBlue,
    required PdfColor brandBlueDark,
  }) async {
    String? cartSvg;
    String? personSvg;
    String? phoneSvg;
    String? receiptSvg;
    String? calendarSvg;
    String? dateRangeSvg;
    try {
      cartSvg = await rootBundle.loadString('assets/icon/statement/cart.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: cart.svg — $e');
    }
    try {
      personSvg = await rootBundle.loadString('assets/icon/statement/person.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: person.svg — $e');
    }
    try {
      phoneSvg = await rootBundle.loadString('assets/icon/statement/phone.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: phone.svg — $e');
    }
    try {
      receiptSvg = await rootBundle.loadString('assets/icon/statement/receipt.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: receipt.svg — $e');
    }
    try {
      calendarSvg = await rootBundle.loadString('assets/icon/statement/calendar.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: calendar.svg — $e');
    }
    try {
      dateRangeSvg = await rootBundle.loadString('assets/icon/statement/calendar_range.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: calendar_range.svg — $e');
    }

    return pw.Container(
      padding: const pw.EdgeInsets.all(20),
      decoration: pw.BoxDecoration(
        gradient: pw.LinearGradient(
          colors: [brandBlue, brandBlueDark],
          begin: pw.Alignment.topRight,
          end: pw.Alignment.bottomLeft,
        ),
      ),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          // Store identity (right side in RTL).
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              if (logoBytes != null)
                pw.Container(
                  width: 48,
                  height: 48,
                  margin: const pw.EdgeInsets.only(left: 12),
                  decoration: const pw.BoxDecoration(
                    color: PdfColors.white,
                    shape: pw.BoxShape.circle,
                  ),
                  child: pw.ClipOval(
                    child: pw.Image(
                      pw.MemoryImage(logoBytes),
                      fit: pw.BoxFit.contain,
                    ),
                  ),
                )
                 else
                 pw.Container(
                   width: 48,
                   height: 48,
                   margin: const pw.EdgeInsets.only(left: 12),
                   decoration: const pw.BoxDecoration(
                     color: PdfColors.white,
                     shape: pw.BoxShape.circle,
                   ),
                   child: pw.Center(
                     child: cartSvg != null
                         ? pw.SvgImage(
                             svg: cartSvg,
                             colorFilter: PdfColors.white,
                             width: 48,
                             height: 48,
                           )
                         : pw.SizedBox.shrink(),
                   ),
                 ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  _text(
                    storeName,
                    style: pw.TextStyle(
                      fontSize: 22,
                      fontWeight: pw.FontWeight.bold,
                      color: PdfColors.white,
                    ),
                  ),
                  _text(
                    'كشف حساب العميل',
                    style: pw.TextStyle(
                      fontSize: 12,
                      color: PdfColors.white,
                    ),
                  ),
                  pw.Container(
                    width: 200,
                    height: 1,
                    margin: const pw.EdgeInsets.only(top: 8),
                    decoration: const pw.BoxDecoration(
                      color: _pdfWhite30,
                    ),
                  ),
                ],
              ),
            ],
          ),
          pw.SizedBox(width: 16),
          // Customer & statement meta (left side in RTL).
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              _buildIconMetaRow('العميل', customer.name, isBold: true, svg: personSvg),
              if (customer.phone != null && customer.phone!.isNotEmpty)
                _buildIconMetaRow('رقم الهاتف', customer.phone!, fontSize: 10, svg: phoneSvg),
              _buildIconMetaRow(
                'رقم الكشف',
                'ST-${DateTime.now().millisecondsSinceEpoch.toString().substring(5)}',
                svg: receiptSvg,
              ),
              _buildIconMetaRow(
                'تاريخ الإصدار',
                Formatters.formatDate(DateTime.now()),
                svg: calendarSvg,
              ),
              if (statement.firstDate != null && statement.lastDate != null)
                _buildIconMetaRow(
                  'الفترة',
                  '${Formatters.formatDate(statement.firstDate!)} — ${Formatters.formatDate(statement.lastDate!)}',
                  svg: dateRangeSvg,
                ),
            ],
          ),
        ],
      ),
    );
  }

  /// A small section heading rendered above each block of the statement —
  /// a colored accent bar plus the title text. Gives the document a clean
  /// "sectioned" rhythm similar to modern banking statements.
  pw.Widget _buildSectionTitle(String title, PdfColor accent) {
    return pw.Row(
      crossAxisAlignment: pw.CrossAxisAlignment.center,
      children: [
        pw.Container(
          width: 3,
          height: 14,
          margin: const pw.EdgeInsets.only(left: 8),
          decoration: pw.BoxDecoration(
            color: accent,
            borderRadius: pw.BorderRadius.circular(2),
          ),
        ),
        _text(
          title,
          style: pw.TextStyle(
            fontSize: 12,
            fontWeight: pw.FontWeight.bold,
            color: PdfColors.grey800,
          ),
        ),
        pw.SizedBox(width: 8),
        pw.Divider(color: PdfColors.grey300, thickness: 0.6),
      ],
    );
  }

  pw.Widget _buildIconMetaRow(
    String label,
    String value, {
    bool isBold = false,
    double fontSize = 10,
    String? svg,
  }) {
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 4),
      child: pw.Row(
        mainAxisSize: pw.MainAxisSize.min,
        children: [
          if (svg != null)
            pw.SvgImage(
              svg: svg,
              colorFilter: PdfColors.white,
              width: 10,
              height: 10,
            )
          else
            pw.SizedBox.shrink(),
          pw.SizedBox(width: 6),
          _text(
            '$label:',
            style: pw.TextStyle(fontSize: fontSize, color: _pdfWhite70),
          ),
          pw.SizedBox(width: 4),
          _text(
            value,
            style: pw.TextStyle(
              fontSize: fontSize + 1,
              fontWeight: isBold ? pw.FontWeight.bold : null,
              color: PdfColors.white,
            ),
          ),
        ],
      ),
    );
  }

  /// Boxed summary cards row — each card has a colored top accent and a
  /// large value, reminiscent of dashboard cards in global apps.
  ///
  /// Note: the "current balance" and "outstanding balance" totals are
  /// intentionally omitted from the printed output per product requirements;
  /// only per-row running balances inside the transactions table remain.
  Future<pw.Widget> _buildStatementSummary(
    AccountStatement statement, {
    required PdfColor brandBlue,
    required PdfColor brandRed,
    required PdfColor brandGreen,
    required PdfColor brandAmber,
  }) async {
    String? walletSvg;
    String? cartSvg;
    String? clockSvg;
    String? arrowDownSvg;
    try {
      walletSvg = await rootBundle.loadString('assets/icon/statement/wallet.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: wallet.svg — $e');
    }
    try {
      cartSvg = await rootBundle.loadString('assets/icon/statement/cart.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: cart.svg — $e');
    }
    try {
      clockSvg = await rootBundle.loadString('assets/icon/statement/clock.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: clock.svg — $e');
    }
    try {
      arrowDownSvg = await rootBundle.loadString('assets/icon/statement/arrow_down.svg');
    } catch (e) {
      appLogger.error('failed to load statement icon: arrow_down.svg — $e');
    }

    return pw.SizedBox(
      width: 539.0,
      child: pw.Row(
        mainAxisSize: pw.MainAxisSize.max,
        children: [
          pw.Expanded(
            child: _buildSummaryCard(
              'الرصيد الحالي',
              Formatters.formatCurrency(statement.currentBalance),
              brandBlue,
              svg: walletSvg,
            ),
          ),
          pw.SizedBox(width: 6),
          pw.Expanded(
            child: _buildSummaryCard(
              'إجمالي المشتريات',
              Formatters.formatCurrency(statement.totalDebtPurchases),
              brandRed,
              svg: cartSvg,
            ),
          ),
          pw.SizedBox(width: 6),
          pw.Expanded(
            child: _buildSummaryCard(
              'المشتريات الآجلة',
              Formatters.formatCurrency(statement.totalDebtPurchases),
              brandAmber,
              svg: clockSvg,
            ),
          ),
          pw.SizedBox(width: 6),
          pw.Expanded(
            child: _buildSummaryCard(
              'إجمالي المدفوع',
              Formatters.formatCurrency(statement.totalPayments),
              brandGreen,
              svg: arrowDownSvg,
            ),
          ),
        ],
      ),
    );
  }

  pw.Widget _buildSummaryCard(
    String label,
    String value,
    PdfColor color, {
    String? svg,
  }) {
    final lightColor = _withAlpha(color, 0.1);
    return pw.Container(
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        color: PdfColors.white,
        borderRadius: pw.BorderRadius.circular(8),
        border: pw.Border.all(color: _withAlpha(color, 0.5), width: 0.5),
      ),
      child: pw.Column(
        children: [
          if (svg != null)
            pw.Container(
              width: 36,
              height: 36,
              decoration: pw.BoxDecoration(
                color: lightColor,
                shape: pw.BoxShape.circle,
              ),
              child: pw.Center(
                child: pw.SvgImage(
                  svg: svg,
                  colorFilter: color,
                  width: 18,
                  height: 18,
                ),
              ),
            ),
          pw.SizedBox(height: 6),
          _text(
            label,
            style: pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
            textAlign: pw.TextAlign.center,
          ),
          pw.SizedBox(height: 2),
          _text(
            value,
            style: pw.TextStyle(
              fontSize: 14,
              fontWeight: pw.FontWeight.bold,
              color: color,
            ),
            textAlign: pw.TextAlign.center,
          ),
          _text(
            'د.ع',
            style: pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
          ),
        ],
      ),
    );
  }

  /// Zebra-striped transactions table with a colored header row.
  /// Columns are ordered RTL: # | التاريخ | البيان | النوع | المبلغ | الرصيد
  pw.Widget _buildStatementTable(
    AccountStatement statement, {
    required PdfColor brandBlue,
    required PdfColor brandRed,
    required PdfColor brandGreen,
  }) {
    final rows = statement.entries;
    return pw.Table(
      border: pw.TableBorder(
        horizontalInside: const pw.BorderSide(
          color: PdfColors.grey200,
          width: 0.5,
        ),
        verticalInside: const pw.BorderSide(
          color: PdfColors.grey200,
          width: 0.5,
        ),
        top: pw.BorderSide(color: brandBlue, width: 1.2),
        bottom: pw.BorderSide(color: brandBlue, width: 1.2),
        left: const pw.BorderSide(color: PdfColors.grey300, width: 0.5),
        right: const pw.BorderSide(color: PdfColors.grey300, width: 0.5),
      ),
      // pw.Table does NOT reverse columns for RTL automatically.
      // We arrange columns RTL manually (index 0 = rightmost):
      // Index 0: # (rightmost)
      // Index 1: التاريخ
      // Index 2: البيان
      // Index 3: النوع
      // Index 4: المبلغ
      // Index 5: الرصيد (leftmost)
      columnWidths: {
        0: const pw.FixedColumnWidth(32), // # (rightmost)
        1: const pw.FixedColumnWidth(72), // التاريخ
        2: const pw.FlexColumnWidth(2.6), // البيان
        3: const pw.FixedColumnWidth(58), // النوع
        4: const pw.FixedColumnWidth(78), // المبلغ
        5: const pw.FixedColumnWidth(78), // الرصيد (leftmost)
      },
      children: [
        pw.TableRow(
          decoration: pw.BoxDecoration(
            color: brandBlue,
            borderRadius: const pw.BorderRadius.only(
              topLeft: pw.Radius.circular(4),
              topRight: pw.Radius.circular(4),
            ),
          ),
          children: [
            _buildStatementCell('#', isHeader: true),
            _buildStatementCell(
              'التاريخ',
              isHeader: true,
              alignment: pw.Alignment.centerRight,
            ),
            _buildStatementCell(
              'البيان',
              isHeader: true,
              alignment: pw.Alignment.centerRight,
            ),
            _buildStatementCell(
              'النوع',
              isHeader: true,
              alignment: pw.Alignment.centerRight,
            ),
            _buildStatementCell(
              'المبلغ',
              isHeader: true,
              alignment: pw.Alignment.centerRight,
            ),
            _buildStatementCell(
              'الرصيد',
              isHeader: true,
              alignment: pw.Alignment.centerRight,
            ),
          ],
        ),
        ...rows.asMap().entries.map((entry) {
          final idx = rows.length - entry.key; // oldest = 1
          final e = entry.value;
          final isDebt = e.type == StatementEntryType.debt;
          final isPayment = e.type == StatementEntryType.payment;
          final isEvenRow = entry.key % 2 == 0;
          return pw.TableRow(
            decoration: pw.BoxDecoration(
              color: isEvenRow ? PdfColors.grey50 : PdfColors.white,
            ),
            children: [
              _buildStatementCell('$idx', color: PdfColors.grey600),
              _buildStatementCell(
                Formatters.formatDate(e.date),
                alignment: pw.Alignment.centerRight,
              ),
              _buildStatementCell(
                e.description,
                alignment: pw.Alignment.centerRight,
              ),
              _buildStatementCell(
                e.typeLabel,
                color: isDebt ? brandRed : (isPayment ? brandGreen : brandBlue),
                isBold: true,
                alignment: pw.Alignment.centerRight,
              ),
              _buildStatementCell(
                Formatters.formatAmount(e.amount),
                color: isDebt ? brandRed : (isPayment ? brandGreen : brandBlue),
                isBold: true,
                alignment: pw.Alignment.centerRight,
              ),
              _buildStatementCell(
                Formatters.formatAmount(e.runningBalance),
                color: e.runningBalance > 0 ? brandRed : brandGreen,
                isBold: true,
                alignment: pw.Alignment.centerRight,
              ),
            ],
          );
        }),
      ],
    );
  }

  /// A single table cell with configurable alignment and padding.
  pw.Widget _buildStatementCell(
    String text, {
    bool isHeader = false,
    PdfColor? color,
    bool isBold = false,
    pw.Alignment alignment = pw.Alignment.center,
  }) {
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 7),
      alignment: alignment,
      child: _text(
        text,
        textAlign: alignment == pw.Alignment.centerRight
            ? pw.TextAlign.right
            : pw.TextAlign.center,
        style: pw.TextStyle(
          fontSize: isHeader ? 10 : 9,
          fontWeight: isHeader || isBold ? pw.FontWeight.bold : null,
          color: isHeader ? PdfColors.white : color,
        ),
      ),
    );
  }

  /// Totals box rendered below the transactions table. Per product
  /// requirements, the "current balance" and "outstanding balance" lines
  /// are intentionally omitted from the printed statement; only neutral
  /// aggregates (count / purchases / payments) remain.
  pw.Widget _buildStatementTotals(
    AccountStatement statement, {
    required PdfColor brandGreen,
  }) {
    const headerBlue = PdfColor.fromInt(0xFF1D4ED8);
    const highlightBg = PdfColor.fromInt(0xFFDBEAFE);
    const highlightText = PdfColor.fromInt(0xFF1E40AF);

    return pw.Table(
      border: const pw.TableBorder(
        horizontalInside: pw.BorderSide(color: PdfColors.grey200, width: 0.5),
        verticalInside: pw.BorderSide(color: PdfColors.grey200, width: 0.5),
        top: pw.BorderSide(color: PdfColors.grey300, width: 0.5),
        bottom: pw.BorderSide(color: PdfColors.grey300, width: 0.5),
        left: pw.BorderSide(color: PdfColors.grey300, width: 0.5),
        right: pw.BorderSide(color: PdfColors.grey300, width: 0.5),
      ),
      columnWidths: {
        0: const pw.FlexColumnWidth(1.4),
        1: const pw.FlexColumnWidth(1),
      },
      children: [
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: headerBlue),
          children: [
            _buildStatementCell(
              'البيان',
              isHeader: true,
              alignment: pw.Alignment.centerRight,
            ),
            _buildStatementCell(
              'القيمة (د.ع)',
              isHeader: true,
              alignment: pw.Alignment.centerLeft,
            ),
          ],
        ),
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: PdfColors.grey50),
          children: [
            _buildStatementCell(
              'عدد العمليات',
              alignment: pw.Alignment.centerRight,
            ),
            _buildStatementCell(
              '${statement.entries.length}',
              alignment: pw.Alignment.centerLeft,
            ),
          ],
        ),
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: PdfColors.white),
          children: [
            _buildStatementCell(
              'إجمالي المشتريات',
              alignment: pw.Alignment.centerRight,
            ),
            _buildStatementCell(
              Formatters.formatCurrency(statement.totalDebtPurchases),
              alignment: pw.Alignment.centerLeft,
            ),
          ],
        ),
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: PdfColors.grey50),
          children: [
            _buildStatementCell(
              'إجمالي المدفوع',
              color: brandGreen,
              isBold: true,
              alignment: pw.Alignment.centerRight,
            ),
            _buildStatementCell(
              Formatters.formatCurrency(statement.totalPayments),
              color: brandGreen,
              isBold: true,
              alignment: pw.Alignment.centerLeft,
            ),
          ],
        ),
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: highlightBg),
          children: [
            _buildStatementCell(
              'الرصيد الحالي',
              color: highlightText,
              isBold: true,
              alignment: pw.Alignment.centerRight,
            ),
            _buildStatementCell(
              Formatters.formatCurrency(statement.currentBalance),
              color: highlightText,
              isBold: true,
              alignment: pw.Alignment.centerLeft,
            ),
          ],
        ),
      ],
    );
  }

  /// Signature lines for the store and the customer, placed at the bottom
  /// of the statement so the document can be acknowledged physically.
  pw.Widget _buildSignatureSection() {
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.center,
          children: [
            _text(
              'توقيع الزبون',
              style: pw.TextStyle(fontSize: 10, color: PdfColors.grey700),
            ),
            pw.SizedBox(height: 28),
            pw.Container(
              width: 160,
              decoration: const pw.BoxDecoration(
                border: pw.Border(
                  top: pw.BorderSide(color: PdfColors.grey500, width: 0.8),
                ),
              ),
            ),
          ],
        ),
        pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.center,
          children: [
            _text(
              'توقيع المسؤول',
              style: pw.TextStyle(fontSize: 10, color: PdfColors.grey700),
            ),
            pw.SizedBox(height: 28),
            pw.Container(
              width: 160,
              decoration: const pw.BoxDecoration(
                border: pw.Border(
                  top: pw.BorderSide(color: PdfColors.grey500, width: 0.8),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
