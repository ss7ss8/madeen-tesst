import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:flutter/material.dart';

import '../../core/utils/formatters.dart';
import '../../data/models/customer.dart';
import '../../data/models/debt.dart';
import '../../data/models/settings.dart';
import 'thermal_isolate.dart';
import 'thermal_render_primitives.dart';

/// Thermal paper width options.
///
/// 58mm printers: 384 dots per line (8 dots/mm, 48mm printable width)
/// 80mm printers: 576 dots per line (8 dots/mm, 72mm printable width)
enum ThermalPaperWidth { mm58, mm80 }

/// Extension providing pixel width and [PaperSize] for each thermal paper size.
extension ThermalPaperWidthX on ThermalPaperWidth {
  /// Dot/pixel count per line at 203 DPI (8 dots/mm).
  int get pixels => switch (this) {
    ThermalPaperWidth.mm58 => 384,
    ThermalPaperWidth.mm80 => 576,
  };

  /// Corresponding [PaperSize] for ESC/POS commands.
  PaperSize get paperSize => switch (this) {
    ThermalPaperWidth.mm58 => PaperSize.mm58,
    ThermalPaperWidth.mm80 => PaperSize.mm80,
  };
}

/// Modern thermal invoice renderer with emoji icons and professional layout.
///
/// Enhanced Layout (RTL, Arabic - Modern Design):
///
///  ┌──────────────────────────────────┐
///  │   [اسم المحل]  [logo]            │  ← dark header band
///  │   📱 هاتف: ...                   │
///  ├══════════════════════════════════╡
///  │    📄 فاتورة دين                │  ← title with icon
///  ├══════════════════════════════════╡
///  │ 🔢 رقم الفاتورة:   #XXX         │  ← icons for clarity
///  │ 📅 التاريخ:        DD/MM/YYYY    │
///  │ ⏰ الاستحقاق:      DD/MM/YYYY    │
///  ├ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┤
///  │ 👤 الزبون:         اسم الزبون   │
///  │ 📞 الهاتف:         XXXXXXXXX     │
///  ├ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┤
///  │ 📦 المنتج:         اسم المنتج    │
///  │ #️⃣  الكمية:         X            │
///  │ 📝 ملاحظات:        ...           │
///  ├ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┤
///  │ ┌────────────────────────────┐   │
///  │ │ 💰 الإجمالي: 10,000,000 د.ع│   │  ← modern card
///  │ │ ✅ المدفوع:      0 د.ع     │   │
///  │ │ 🔴 المتبقي:  10,000,000 د.ع│   │  ← highlighted
///  │ └────────────────────────────┘   │
///  ├══════════════════════════════════╡
///  │    ✨ شكراً لتعاملكم معنا ✨    │
///  │       🔒 احتفظ بالفاتورة        │
///  └──────────────────────────────────┘
class ThermalInvoiceRenderer {
  ThermalInvoiceRenderer._();

  // ===========================================================================
  // Public API
  // ===========================================================================

  /// Renders [debt] as a thermal-printable invoice and returns ESC/POS bytes.
  static Future<Uint8List> renderInvoice({
    required Debt debt,
    required Customer customer,
    required AppSettings settings,
    required ThermalPaperWidth paperWidth,
  }) async {
    final widthPx = paperWidth.pixels;

    // 1. Render the invoice layout as a ui.Image using Flutter Canvas.
    final rendered = await _drawInvoiceCanvas(
      debt: debt,
      customer: customer,
      settings: settings,
      widthPx: widthPx,
    );

    // 2. Convert ui.Image → PNG bytes (must run on the main isolate —
    //    the Flutter rendering / toByteData API is not available in a
    //    background isolate).
    final byteData = await rendered.toByteData(format: ui.ImageByteFormat.png);
    if (byteData == null) {
      throw Exception('فشل تحويل الصورة');
    }
    final pngBytes = byteData.buffer.asUint8List();

    // 3. + 4. Decode PNG and rasterize to ESC/POS bytes in a background
    //    isolate. These two steps (img.decodePng + Generator.image) are
    //    the CPU-heavy part of the pipeline — running them on the main
    //    isolate was the root cause of the "49 dropped frames" UI freeze
    //    when printing. CapabilityProfile is loaded here on the main
    //    isolate (it reads a bundled asset via rootBundle, which is a
    //    platform channel unavailable in a background isolate) and then
    //    sent across to the worker; it is fully sendable (String name +
    //    List<CodePage> of int/String).
    final profile = await CapabilityProfile.load();
    return pngBytesToEscPos(
      pngBytes: pngBytes,
      paperWidth: paperWidth,
      profile: profile,
    );
  }

  /// Renders the invoice as a [ui.Image] (for on-screen preview).
  static Future<ui.Image> renderInvoiceImage({
    required Debt debt,
    required Customer customer,
    required AppSettings settings,
    required ThermalPaperWidth paperWidth,
  }) {
    return _drawInvoiceCanvas(
      debt: debt,
      customer: customer,
      settings: settings,
      widthPx: paperWidth.pixels,
    );
  }

  // ===========================================================================
  // Canvas Drawing
  // ===========================================================================

  static Future<ui.Image> _drawInvoiceCanvas({
    required Debt debt,
    required Customer customer,
    required AppSettings settings,
    required int widthPx,
  }) async {
    const fontFamily = 'IBMPlexSansArabic';
    final is58mm = widthPx <= 384;

    // ── Modern Font sizes with better spacing ────────────────────────────────
    final storeNameSize = is58mm ? 22.0 : 28.0;
    final titleSize = is58mm ? 18.0 : 23.0;
    final bodySize = is58mm ? 14.0 : 16.0;
    final amountSize = is58mm ? 15.0 : 18.0;
    final footerSize = is58mm ? 13.0 : 15.0;

    // ── Modern Padding for better spacing ─────────────────────────────────────
    final padding = is58mm ? 16.0 : 20.0;
    final contentWidth = widthPx - padding * 2;

    // ── Collect lines ─────────────────────────────────────────────────────────
    final lines = <RenderLine>[];

    // 1. Header band (store name + logo)
    lines.add(
      RenderLine.logoBand(
        logo: null, // No logo needed for simple invoice
        text: settings.storeName,
        logoSize: 0,
        fontSize: storeNameSize,
        fontWeight: FontWeight.bold,
        fontFamily: fontFamily,
        marginTop: 0,
      ),
    );

    // Store phone (centered, white-on-dark not possible outside band, so below)
    if ((settings.storePhone ?? '').isNotEmpty) {
      lines.add(
        RenderLine.text(
          'هاتف: ${settings.storePhone}',
          fontSize: bodySize - 1,
          fontWeight: FontWeight.normal,
          align: TextAlign.center,
          fontFamily: fontFamily,
          marginTop: 5,
        ),
      );
    }

    // 2. Invoice title with icon
    lines.add(RenderLine.doubleDivider());
    lines.add(
      RenderLine.text(
        '📄 ── فاتورة دين ──',
        fontSize: titleSize,
        fontWeight: FontWeight.bold,
        align: TextAlign.center,
        fontFamily: fontFamily,
        marginTop: 6,
      ),
    );
    lines.add(RenderLine.doubleDivider());

    // 3. Invoice meta (two-column rows with icons)
    final invoiceNo = debt.invoiceNumber ?? 0;
    lines.add(
      RenderLine.twoColumnRow(
        '🔢 رقم الفاتورة:',
        '#$invoiceNo',
        fontSize: bodySize,
        marginTop: 8,
        fontFamily: fontFamily,
      ),
    );
    lines.add(
      RenderLine.twoColumnRow(
        '📅 التاريخ:',
        Formatters.formatDate(debt.createdAt),
        fontSize: bodySize,
        marginTop: 4,
        fontFamily: fontFamily,
      ),
    );
    if (debt.dueDate != null) {
      lines.add(
        RenderLine.twoColumnRow(
          '⏰ الاستحقاق:',
          Formatters.formatDate(debt.dueDate!),
          fontSize: bodySize,
          marginTop: 4,
          fontFamily: fontFamily,
        ),
      );
    }

    lines.add(RenderLine.divider());

    // 4. Customer info with icons
    lines.add(
      RenderLine.twoColumnRow(
        '👤 الزبون:',
        customer.name,
        fontSize: bodySize,
        marginTop: 4,
        isTwoColBold: true,
        fontFamily: fontFamily,
      ),
    );
    if ((customer.phone ?? '').isNotEmpty) {
      lines.add(
        RenderLine.twoColumnRow(
          '📞 الهاتف:',
          customer.phone!,
          fontSize: bodySize,
          marginTop: 4,
          fontFamily: fontFamily,
        ),
      );
    }

    // 5. Product info (if available) with icons
    if ((debt.productName ?? '').isNotEmpty) {
      lines.add(RenderLine.divider());
      lines.add(
        RenderLine.twoColumnRow(
          '📦 المنتج:',
          debt.productName!,
          fontSize: bodySize,
          marginTop: 4,
          fontFamily: fontFamily,
        ),
      );
      lines.add(
        RenderLine.twoColumnRow(
          '#️⃣ الكمية:',
          '${debt.productQuantity}',
          fontSize: bodySize,
          marginTop: 4,
          fontFamily: fontFamily,
        ),
      );
    }

    // 6. Notes (if available) with icon
    if ((debt.notes ?? '').isNotEmpty) {
      lines.add(RenderLine.divider());
      lines.add(
        RenderLine.text(
          '📝 ملاحظات: ${debt.notes}',
          fontSize: bodySize - 1,
          fontWeight: FontWeight.normal,
          align: TextAlign.right,
          fontFamily: fontFamily,
          marginTop: 4,
        ),
      );
    }

    // 7. Installment info with icon
    if (debt.isInstallment && debt.installmentCount > 1) {
      lines.add(RenderLine.divider());
      lines.add(
        RenderLine.twoColumnRow(
          '💳 نوع الدفع:',
          'أقساط (${debt.installmentCount})',
          fontSize: bodySize,
          marginTop: 4,
          fontFamily: fontFamily,
        ),
      );
    }

    lines.add(RenderLine.divider());

    // 8. Summary box (totals) with modern icons
    final summaryRows = <SummaryRow>[
      SummaryRow('💰 الإجمالي:', Formatters.formatCurrency(debt.amount)),
      if (debt.paidAmount > 0)
        SummaryRow('✅ المدفوع:', Formatters.formatCurrency(debt.paidAmount)),
      SummaryRow(
        debt.remainingAmount > 0 ? '🔴 المتبقي:' : '✅ مسدد كاملاً:',
        Formatters.formatCurrency(debt.remainingAmount),
        isTotal: true,
      ),
    ];

    lines.add(
      RenderLine.summaryBox(summaryRows, fontSize: amountSize, marginTop: 8),
    );

    // 9. Modern footer with icons
    lines.add(RenderLine.doubleDivider());
    lines.add(
      RenderLine.text(
        '✨ شكراً لتعاملكم معنا ✨',
        fontSize: footerSize,
        fontWeight: FontWeight.bold,
        align: TextAlign.center,
        fontFamily: fontFamily,
        marginTop: 6,
      ),
    );
    lines.add(
      RenderLine.text(
        '🔒 يُرجى الاحتفاظ بهذه الفاتورة',
        fontSize: footerSize - 2,
        fontWeight: FontWeight.normal,
        align: TextAlign.center,
        fontFamily: fontFamily,
        marginTop: 3,
      ),
    );

    // ── First pass: layout all lines and compute total height ─────────────────
    double totalHeight = padding;
    for (final line in lines) {
      line.layout(contentWidth);
      totalHeight += line.marginTop + line.height;
    }
    totalHeight += padding * 1.5; // bottom padding

    final heightPx = totalHeight.round();

    // ── Second pass: draw onto canvas ─────────────────────────────────────────
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder);

    // Modern light background for better contrast
    canvas.drawRect(
      ui.Rect.fromLTWH(0, 0, widthPx.toDouble(), heightPx.toDouble()),
      ui.Paint()..color = const ui.Color(0xFFF8F9FA),
    );

    double y = padding;
    for (final line in lines) {
      y += line.marginTop;
      line.paint(canvas, padding, y, contentWidth);
      y += line.height;
    }

    final picture = recorder.endRecording();
    return picture.toImage(widthPx, heightPx);
  }
}
