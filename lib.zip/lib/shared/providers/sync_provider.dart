import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/config/app_config.dart';
import '../../core/services/supabase_service.dart';
import '../../data/local/hive_service.dart';

/// Tracks whether a full data restore from Supabase is in progress.
///
/// While `true`, the home shell shows a loading indicator instead of the
/// normal content so the UI never renders with empty/zero data (which would
/// incorrectly show "تم التسديد" on a fresh install before restore completes).
final isRestoringProvider = StateProvider<bool>((ref) => false);

/// يتتبع حالة تهيئة التطبيق (Hive + Supabase + Env).
///
/// يُقرأ في `DebtTrackerApp.build` قبل `authStateProvider` كي تظهر
/// `SplashScreen` فور إطلاق التطبيق أثناء اكتمال التهيئة في الخلفية.
final appInitProvider = FutureProvider<void>((ref) async {
  // تحميل .env فقط في وضع التصحيح (debug) لمنع تضمينه في APK
  if (kDebugMode) {
    await AppConfig.loadEnvFallback();
  }
  await Future.wait([
    HiveService.init(),
    SupabaseService.init(
      url: AppConfig.supabaseUrl,
      publishableKey: AppConfig.supabasePublishableKey,
    ),
  ]);
});
