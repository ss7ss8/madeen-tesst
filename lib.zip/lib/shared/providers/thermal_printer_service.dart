import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';

import '../../data/models/settings.dart';

/// Represents a paired Bluetooth device discovered by the platform.
@immutable
class ThermalPrinterDevice {
  final String name;
  final String mac;

  const ThermalPrinterDevice({required this.name, required this.mac});

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ThermalPrinterDevice && mac == other.mac && name == other.name;

  @override
  int get hashCode => mac.hashCode ^ name.hashCode;

  @override
  String toString() => 'ThermalPrinterDevice(name: $name, mac: $mac)';
}

/// Connection status of the thermal printer service.
enum ThermalConnectionStatus { disconnected, connecting, connected, error }

/// Result of a print attempt.
class ThermalPrintResult {
  final bool success;
  final String message;

  const ThermalPrintResult({required this.success, required this.message});

  factory ThermalPrintResult.ok() =>
      const ThermalPrintResult(success: true, message: 'تمت الطباعة بنجاح');

  factory ThermalPrintResult.fail(String msg) =>
      ThermalPrintResult(success: false, message: msg);
}

/// State exposed by [ThermalPrinterNotifier].
class ThermalPrinterState {
  final ThermalConnectionStatus status;
  final ThermalPrinterDevice? connectedDevice;
  final String? errorMessage;

  const ThermalPrinterState({
    this.status = ThermalConnectionStatus.disconnected,
    this.connectedDevice,
    this.errorMessage,
  });

  bool get isConnected => status == ThermalConnectionStatus.connected;

  ThermalPrinterState copyWith({
    ThermalConnectionStatus? status,
    ThermalPrinterDevice? connectedDevice,
    String? errorMessage,
  }) {
    return ThermalPrinterState(
      status: status ?? this.status,
      connectedDevice: connectedDevice ?? this.connectedDevice,
      errorMessage: errorMessage,
    );
  }
}

/// Riverpod notifier managing Bluetooth thermal printer lifecycle.
///
/// All methods are async and never block the UI thread. Connection attempts
/// use a timeout so the user is never stuck waiting indefinitely.
class ThermalPrinterNotifier extends StateNotifier<ThermalPrinterState> {
  ThermalPrinterNotifier() : super(const ThermalPrinterState());

  static const Duration _connectTimeout = Duration(seconds: 15);
  static const Duration _scanTimeout = Duration(seconds: 10);

  /// Requests the necessary Bluetooth / location permissions.
  ///
  /// Returns `true` if all required permissions are granted. On Android 12+
  /// we request [Permission.bluetoothScan] + [Permission.bluetoothConnect].
  /// On Android 11- we request [Permission.location] (needed for BLE scan).
  Future<bool> _requestPermissions() async {
    final permissions = <Permission>[
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.location,
    ];
    final results = await permissions.request();
    final allGranted = results.values.every((s) => s.isGranted);
    if (!allGranted) {
      // On older Android (< 12) bluetoothScan/bluetoothConnect may be
      // permanently denied because the OS doesn't know about them —
      // fall back to checking location only.
      final locationGranted = results[Permission.location]?.isGranted ?? false;
      return locationGranted;
    }
    return true;
  }

  /// Returns a list of paired / bonded Bluetooth devices.
  ///
  /// Automatically requests permissions first. Throws on timeout or platform
  /// error.
  Future<List<ThermalPrinterDevice>> getPairedDevices() async {
    final granted = await _requestPermissions();
    if (!granted) {
      throw Exception('لم يتم منح أذونات البلوتوث');
    }

    try {
      final bonded = await PrintBluetoothThermal.pairedBluetooths.timeout(
        _scanTimeout,
      );
      return bonded
          .map(
            (info) =>
                ThermalPrinterDevice(name: info.name, mac: info.macAdress),
          )
          .toList();
    } on TimeoutException {
      throw Exception('انتهت مهلة البحث عن الطابعات');
    } catch (e) {
      throw Exception('فشل البحث عن الطابعات: $e');
    }
  }

  /// Connects to a printer by its MAC address.
  ///
  /// Sets state to [ThermalConnectionStatus.connecting] then attempts the
  /// connection with a timeout. On failure sets [ThermalConnectionStatus.error]
  /// with an Arabic message.
  Future<bool> connect(String mac, {String? name}) async {
    if (state.isConnected) await disconnect();

    state = state.copyWith(
      status: ThermalConnectionStatus.connecting,
      errorMessage: null,
    );

    try {
      final granted = await _requestPermissions();
      if (!granted) {
        state = state.copyWith(
          status: ThermalConnectionStatus.error,
          errorMessage: 'لم يتم منح أذونات البلوتوث',
        );
        return false;
      }

      final result = await PrintBluetoothThermal.connect(
        macPrinterAddress: mac,
      ).timeout(_connectTimeout);

      if (result) {
        state = state.copyWith(
          status: ThermalConnectionStatus.connected,
          connectedDevice: ThermalPrinterDevice(name: name ?? mac, mac: mac),
        );
        return true;
      } else {
        state = state.copyWith(
          status: ThermalConnectionStatus.error,
          errorMessage: 'فشل الاتصال بالطابعة',
        );
        return false;
      }
    } on TimeoutException {
      state = state.copyWith(
        status: ThermalConnectionStatus.error,
        errorMessage: 'انتهت مهلة الاتصال — تأكد من تشغيل الطابعة',
      );
      return false;
    } catch (e) {
      state = state.copyWith(
        status: ThermalConnectionStatus.error,
        errorMessage: 'خطأ في الاتصال: $e',
      );
      return false;
    }
  }

  /// Disconnects from the current printer.
  Future<void> disconnect() async {
    try {
      await PrintBluetoothThermal.disconnect;
    } catch (_) {
      // ignore — best-effort disconnect
    }
    state = const ThermalPrinterState();
  }

  /// Checks whether a printer is currently connected.
  Future<bool> checkConnection() async {
    try {
      final connected = await PrintBluetoothThermal.connectionStatus;
      if (!connected) {
        state = state.copyWith(status: ThermalConnectionStatus.disconnected);
      }
      return connected;
    } catch (_) {
      return false;
    }
  }

  /// Sends raw ESC/POS bytes to the connected printer.
  ///
  /// Returns a [ThermalPrintResult] with an Arabic message. Does not block the
  /// UI thread — runs on the platform channel asynchronously.
  Future<ThermalPrintResult> printBytes(Uint8List bytes) async {
    if (!state.isConnected) {
      final ok = await checkConnection();
      if (!ok) {
        return const ThermalPrintResult(
          success: false,
          message: 'لا توجد طابعة متصلة — يرجى الاقتران أولاً',
        );
      }
    }

    try {
      final success = await PrintBluetoothThermal.writeBytes(
        bytes,
      ).timeout(const Duration(seconds: 30));
      if (success) {
        return ThermalPrintResult.ok();
      } else {
        return const ThermalPrintResult(
          success: false,
          message: 'فشل إرسال البيانات للطابعة',
        );
      }
    } on TimeoutException {
      // Connection likely dropped — reset state so user is prompted to retry.
      state = state.copyWith(
        status: ThermalConnectionStatus.error,
        errorMessage: 'انقطع الاتصال أثناء الطباعة — يرجى إعادة المحاولة',
      );
      return const ThermalPrintResult(
        success: false,
        message: 'انقطع الاتصال أثناء الطباعة — يرجى إعادة المحاولة',
      );
    } catch (e) {
      return ThermalPrintResult.fail('خطأ في الطباعة: $e');
    }
  }

  /// Auto-connects to the last known printer stored in [AppSettings].
  ///
  /// Returns `true` if connection succeeded. Returns `false` silently (no
  /// error state) when no MAC is stored — this is expected on first run.
  Future<bool> autoConnectFromSettings(AppSettings settings) async {
    final mac = settings.lastPrinterMac;
    if (mac == null || mac.isEmpty) return false;

    // Already connected to the same device?
    if (state.isConnected && state.connectedDevice?.mac == mac) {
      return true;
    }

    final ok = await connect(mac, name: settings.lastPrinterName);
    return ok;
  }
}

/// Riverpod provider for the thermal printer service.
final thermalPrinterProvider =
    StateNotifierProvider<ThermalPrinterNotifier, ThermalPrinterState>((ref) {
      return ThermalPrinterNotifier();
    });
