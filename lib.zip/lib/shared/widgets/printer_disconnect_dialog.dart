import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/settings.dart';
import '../providers/thermal_printer_service.dart';

/// Arabic retry dialog shown when the thermal printer disconnects mid-print.
///
/// Shared between the invoice flow (`customer_detail_screen.dart`) and the
/// account-statement flow (`account_statement_screen.dart`) — previously
/// duplicated verbatim in both files (see TODO.md "دَين تقني").
///
/// Returns `true` after a successful reconnect (or `false` on "إلغاء").
Future<bool> showPrinterDisconnectDialog(
  BuildContext context,
  WidgetRef ref,
  AppSettings settings, {
  String? message,
}) async {
  final choice = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (ctx) => AlertDialog(
      title: const Text('انقطاع الاتصال بالطابعة'),
      content: Text(
        message ?? 'انقطع الاتصال بالطابعة. هل تريد إعادة المحاولة؟',
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(false),
          child: const Text('إلغاء'),
        ),
        ElevatedButton(
          onPressed: () => Navigator.of(ctx).pop(true),
          child: const Text('إعادة المحاولة'),
        ),
      ],
    ),
  );

  if (choice != true) return false;

  // المستخدم اختار إعادة المحاولة — أعد الاتصال بآخر طابعة محفوظة.
  if (settings.lastPrinterMac != null &&
      settings.lastPrinterMac!.isNotEmpty) {
    final ok = await ref
        .read(thermalPrinterProvider.notifier)
        .connect(settings.lastPrinterMac!, name: settings.lastPrinterName);
    return ok;
  }
  return false;
}
