import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

/// A performant image widget that handles both remote (Supabase Storage)
/// URLs and local file paths with:
///
/// - **Disk caching** for network images via `CachedNetworkImage`, so images
///   are never re-downloaded after the first load.
/// - **Memory-resident decode resizing** (`memCacheWidth`/`cacheWidth`) so
///   large source images are decoded at display resolution (scaled to physical pixels)
///   instead of native resolution — dramatically reducing memory while maintaining sharpness.
/// - **Fade-in transition** and a spinner while loading.
/// - **Error fallback** to a configurable placeholder icon.
class AppNetworkImage extends StatelessWidget {
  final String? imageUrl;
  final double? width;
  final double? height;
  final BoxFit fit;
  final IconData placeholderIcon;
  final Color? placeholderColor;

  const AppNetworkImage({
    super.key,
    required this.imageUrl,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.placeholderIcon = Icons.inventory_2,
    this.placeholderColor,
  });

  @override
  Widget build(BuildContext context) {
    final url = imageUrl;
    if (url == null || url.isEmpty) {
      return _buildPlaceholder(context);
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        // الحصول على نسبة بكسل الجهاز لضمان دقة الصورة وعدم ظهورها بشكل مغبش.
        final devicePixelRatio = MediaQuery.maybeDevicePixelRatioOf(context) ?? 2.0;

        // تحديد الأبعاد بناءً على القيم الممررة أو المساحة المتاحة ديناميكياً.
        final displayW = width ?? (constraints.maxWidth.isFinite ? constraints.maxWidth : 400.0);
        final displayH = height ?? (constraints.maxHeight.isFinite ? constraints.maxHeight : 400.0);

        // حساب الحجم الفعلي بالبكسل الحقيقي لفك ترميز الصور بدقة مناسبة مع الحفاظ على نسبة الأبعاد الأصلية.
        final targetW = (displayW * devicePixelRatio).round();

        if (url.startsWith('http')) {
          return CachedNetworkImage(
            imageUrl: url,
            fit: fit,
            width: displayW,  // تمرير العرض الفعلي لتجنب التمدد
            height: displayH, // تمرير الارتفاع الفعلي لتجنب التمدد
            memCacheWidth: targetW, // تحديد العرض فقط لفك الترميز يحافظ على النسبة الأصلية للأبعاد
            placeholder: (_, __) => _buildLoading(context),
            errorWidget: (_, __, ___) => _buildPlaceholder(context),
            fadeInDuration: const Duration(milliseconds: 200),
            fadeOutDuration: const Duration(milliseconds: 100),
            filterQuality: FilterQuality.medium, // جودة تصفية أفضل عند تصغير الحجم
          );
        }

        return Image.file(
          File(url),
          fit: fit,
          width: displayW,  // تمرير العرض الفعلي لتجنب التمدد
          height: displayH, // تمرير الارتفاع الفعلي لتجنب التمدد
          cacheWidth: targetW, // تحديد العرض فقط لفك الترميز يحافظ على النسبة الأصلية للأبعاد
          gaplessPlayback: true,
          filterQuality: FilterQuality.medium, // جودة تصفية أفضل عند تصغير الحجم
          errorBuilder: (_, __, ___) => _buildPlaceholder(context),
        );
      },
    );
  }

  Widget _buildLoading(BuildContext context) {
    final color = placeholderColor ?? Theme.of(context).colorScheme.primary;
    return ColoredBox(
      color: color.withValues(alpha: 0.06),
      child: Center(
        child: SizedBox(
          width: 24,
          height: 24,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation(color.withValues(alpha: 0.5)),
          ),
        ),
      ),
    );
  }

  Widget _buildPlaceholder(BuildContext context) {
    final color = placeholderColor ?? Theme.of(context).colorScheme.primary;
    return ColoredBox(
      color: color.withValues(alpha: 0.06),
      child: Center(
        child: Icon(
          placeholderIcon,
          size: 40,
          color: color.withValues(alpha: 0.3),
        ),
      ),
    );
  }
}
