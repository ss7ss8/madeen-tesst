import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

/// Bottom-sheet barcode/QR scanner shared across the app.
///
/// Opens a camera scanner inside a modal bottom sheet and resolves with the
/// scanned value (`String`) on detection, or `null` when the user cancels
/// (closes the sheet / taps "إلغاء").
///
/// Intentionally decoupled from any screen or button — wiring it into a
/// specific flow is a separate, later task.
Future<String?> showBarcodeScannerSheet(BuildContext context) async {
  final controller = MobileScannerController(
    formats: const [BarcodeFormat.all],
  );

  String? result;

  try {
    final value = await showModalBottomSheet<String?>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => PopScope(
        canPop: true,
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          child: Container(
            height: MediaQuery.of(ctx).size.height * 0.75,
            color: Colors.black,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 8, 8),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'مسح الباركود',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: () => Navigator.of(ctx).pop(null),
                        tooltip: 'إلغاء',
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: MobileScanner(
                    controller: controller,
                    onDetect: (capture) {
                      final code = capture.barcodes.firstOrNull?.rawValue;
                      if (code != null && code.isNotEmpty) {
                        result = code;
                        Navigator.of(ctx).pop(code);
                      }
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(ctx).pop(null),
                      child: const Text('إلغاء'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    return value ?? result;
  } finally {
    controller.dispose();
  }
}
