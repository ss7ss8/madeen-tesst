import 'package:flutter/material.dart';
import '../../data/local/hive_service.dart';

class CustomerAvatar extends StatelessWidget {
  final String name;
  final String? imageUrl;
  final double radius;
  final String? reliability;

  const CustomerAvatar({
    super.key,
    required this.name,
    this.imageUrl,
    this.radius = 28,
    this.reliability,
  });

  static const _gradients = [
    [Color(0xFF2563EB), Color(0xFF3B82F6)],
    [Color(0xFF10B981), Color(0xFF34D399)],
    [Color(0xFF8B5CF6), Color(0xFFA78BFA)],
    [Color(0xFFEC4899), Color(0xFFF472B6)],
    [Color(0xFFF59E0B), Color(0xFFFBBF24)],
    [Color(0xFF06B6D4), Color(0xFF22D3EE)],
    [Color(0xFFEF4444), Color(0xFFF87171)],
    [Color(0xFF6366F1), Color(0xFF818CF8)],
  ];

  static List<Color> _gradientFor(String name) {
    final index = name.hashCode.abs() % _gradients.length;
    return _gradients[index];
  }

  Color _reliabilityColor() => HiveService.reliabilityColor(reliability);

  @override
  Widget build(BuildContext context) {
    final hasImage = imageUrl != null && imageUrl!.isNotEmpty;
    final size = radius * 2;

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          ClipOval(
            child: SizedBox(
              width: size,
              height: size,
              child: Stack(
                children: [
                  _buildGradientLayer(),
                  if (hasImage) _buildImageLayer(),
                ],
              ),
            ),
          ),
          if (reliability != null)
            Positioned(
              bottom: -2,
              right: -2,
              child: Tooltip(
                message: 'الموثوقية: ${_reliabilityLabel()}',
                child: Container(
                  width: radius > 30 ? 16 : 14,
                  height: radius > 30 ? 16 : 14,
                  decoration: BoxDecoration(
                    color: _reliabilityColor(),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildGradientLayer() {
    final colors = _gradientFor(name);
    return Container(
      width: radius * 2,
      height: radius * 2,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: colors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Text(
          name.isNotEmpty ? name[0].toUpperCase() : '?',
          style: TextStyle(
            fontSize: radius * 0.7,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _buildImageLayer() {
    return Image.network(
      imageUrl!,
      width: radius * 2,
      height: radius * 2,
      fit: BoxFit.cover,
      // Decode at display resolution to avoid holding full-res images in memory.
      // × 3 is a safe upper bound for device pixel ratio across all devices.
      cacheWidth: (radius * 2 * 3).round(),
      cacheHeight: (radius * 2 * 3).round(),
      errorBuilder: (_, __, ___) => const SizedBox.shrink(),
      loadingBuilder: (_, child, progress) {
        if (progress == null) return child;
        return _buildGradientLayer();
      },
    );
  }

  String _reliabilityLabel() => HiveService.reliabilityLabel(reliability);
}
