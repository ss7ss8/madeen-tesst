import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../data/local/hive_service.dart';
import '../data/models/customer.dart';
import '../data/models/debt.dart';
import '../data/models/product.dart';
import '../data/models/payment.dart';
import '../data/models/settings.dart';
import '../core/services/supabase_service.dart';
import '../core/services/sync_service.dart';
import '../core/services/notification_service.dart';
import '../core/utils/logger.dart';

enum BackupStatus { idle, backingUp, success, error }

class BackupResult {
  final bool success;
  final String message;
  final int customersCount;
  final int debtsCount;
  final int productsCount;
  final int paymentsCount;
  final DateTime? backupTime;
  final String? errorDetails;

  BackupResult({
    required this.success,
    required this.message,
    this.customersCount = 0,
    this.debtsCount = 0,
    this.productsCount = 0,
    this.paymentsCount = 0,
    this.backupTime,
    this.errorDetails,
  });
}

class BackupService {
  static BackupStatus _status = BackupStatus.idle;
  static BackupResult? _lastResult;

  static BackupStatus get status => _status;
  static BackupResult? get lastResult => _lastResult;

  /// Full backup all local data to Supabase using upsert
  /// Returns BackupResult with statistics and status
  static Future<BackupResult> backupToSupabase() async {
    final userId = SupabaseService.currentUser?.id;

    if (userId == null) {
      _status = BackupStatus.error;
      _lastResult = BackupResult(
        success: false,
        message: 'لم يتم تسجيل الدخول. يرجى تسجيل الدخول أولاً.',
      );
      return _lastResult!;
    }

    _status = BackupStatus.backingUp;
    _lastResult = null;

    try {
      // Check connectivity
      if (!await SyncService.isOnline()) {
        _status = BackupStatus.error;
        _lastResult = BackupResult(
          success: false,
          message: 'لا يوجد اتصال بالإنترنت. يرجى التحقق من اتصالك.',
        );
        return _lastResult!;
      }

      appLogger.info('Starting full backup to Supabase...');

      // 1. Backup Customers
      final customers = HiveService.getAllCustomers();
      int customersBackedUp = 0;
      for (final customer in customers) {
        try {
          await SupabaseService.upsertCustomer(customer.toJson());
          customersBackedUp++;
        } catch (e) {
          appLogger.warning('Error backing up customer ${customer.id}: $e');
        }
      }
      appLogger.info('Backed up $customersBackedUp customers');

      // 2. Backup Products
      final products = HiveService.getAllProducts();
      int productsBackedUp = 0;
      for (final product in products) {
        try {
          await SupabaseService.upsertProduct(product.toJson());
          productsBackedUp++;
        } catch (e) {
          appLogger.warning('Error backing up product ${product.id}: $e');
        }
      }
      appLogger.info('Backed up $productsBackedUp products');

      // 3. Backup Debts
      final debts = HiveService.getAllDebts();
      int debtsBackedUp = 0;
      for (final debt in debts) {
        try {
          await SupabaseService.upsertDebt(debt.toJson());
          debtsBackedUp++;
        } catch (e) {
          appLogger.warning('Error backing up debt ${debt.id}: $e');
        }
      }
      appLogger.info('Backed up $debtsBackedUp debts');

      // 4. Backup Payments
      final payments = HiveService.getAllPayments();
      int paymentsBackedUp = 0;
      for (final payment in payments) {
        try {
          final debt = HiveService.getAllDebts(
            includeDeleted: true,
          ).where((d) => d.id == payment.debtId).firstOrNull;
          final cid = debt?.customerId;
          if (cid == null) {
            appLogger.warning(
              'Skipping payment ${payment.id}: parent debt ${payment.debtId} '
              'not found or has no customerId',
            );
            continue;
          }
          await SupabaseService.upsertPayment(
            payment.toJson(customerId: cid),
          );
          paymentsBackedUp++;
        } catch (e) {
          appLogger.warning('Error backing up payment ${payment.id}: $e');
        }
      }
      appLogger.info('Backed up $paymentsBackedUp payments');

      // 5. Update last_backup_at in settings
      final settings = HiveService.getAppSettings();
      settings.lastBackupAt = DateTime.now();
      await HiveService.saveAppSettings(settings);

      final backupTime = DateTime.now();
      _status = BackupStatus.success;

      final totalRecords =
          customersBackedUp +
          productsBackedUp +
          debtsBackedUp +
          paymentsBackedUp;
      _lastResult = BackupResult(
        success: true,
        message: 'تم إنشاء نسخة احتياطية بنجاح! ($totalRecords سجل)',
        customersCount: customersBackedUp,
        productsCount: productsBackedUp,
        debtsCount: debtsBackedUp,
        paymentsCount: paymentsBackedUp,
        backupTime: backupTime,
      );

      appLogger.info('Backup complete: $totalRecords total records backed up');
      return _lastResult!;
    } catch (e, stackTrace) {
      _status = BackupStatus.error;
      _lastResult = BackupResult(
        success: false,
        message: 'حدث خطأ أثناء إنشاء النسخة الاحتياطية',
        errorDetails: e.toString(),
      );
      appLogger.error('Backup error: $e\n$stackTrace');
      return _lastResult!;
    }
  }



  /// Get last backup info
  static DateTime? getLastBackupTime() {
    final settings = HiveService.getAppSettings();
    return settings.lastBackupAt;
  }

  /// Check if backup is needed (more than 24 hours since last backup)
  static bool isBackupNeeded() {
    final lastBackup = getLastBackupTime();
    if (lastBackup == null) return true;

    final hoursSinceLastBackup = DateTime.now().difference(lastBackup).inHours;
    return hoursSinceLastBackup >= 24;
  }

  /// Get time since last backup as human readable string
  static String getLastBackupTimeAgo() {
    final lastBackup = getLastBackupTime();
    if (lastBackup == null) return 'لم يتم إنشاء نسخة احتياطية من قبل';

    final now = DateTime.now();
    final difference = now.difference(lastBackup);

    if (difference.inDays > 0) {
      return 'منذ ${difference.inDays} ${difference.inDays == 1 ? 'يوم' : 'أيام'}';
    } else if (difference.inHours > 0) {
      return 'منذ ${difference.inHours} ${difference.inHours == 1 ? 'ساعة' : 'ساعات'}';
    } else if (difference.inMinutes > 0) {
      return 'منذ ${difference.inMinutes} ${difference.inMinutes == 1 ? 'دقيقة' : 'دقائق'}';
    } else {
      return 'الآن';
    }
  }

  /// Exports all local data to a JSON file and returns the file path.
  static Future<BackupResult> exportToFile() async {
    _status = BackupStatus.backingUp;
    _lastResult = null;

    try {
      final customers = HiveService.getAllCustomers(includeDeleted: true);
      final debts = HiveService.getAllDebts(includeDeleted: true);
      final products = HiveService.getAllProducts(includeDeleted: true);
      final payments = HiveService.getAllPayments(includeDeleted: true);
      final settings = HiveService.getAppSettings();

      final backupData = {
        'version': '1.0',
        'exported_at': DateTime.now().toIso8601String(),
        'customers': customers.map((c) => c.toJson()).toList(),
        'debts': debts.map((d) => d.toJson()).toList(),
        'products': products.map((p) => p.toJson()).toList(),
        'payments': payments.map((p) => p.toJson()).toList(),
        'settings': settings.toJson(),
      };

      final jsonStr = jsonEncode(backupData);

      final dir = await getApplicationDocumentsDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final file = File('${dir.path}/debt_tracker_backup_$timestamp.json');
      await file.writeAsString(jsonStr);

      final totalRecords =
          customers.length + debts.length + products.length + payments.length;

      _status = BackupStatus.success;
      _lastResult = BackupResult(
        success: true,
        message: 'تم تصدير النسخة الاحتياطية بنجاح ($totalRecords سجل)',
        customersCount: customers.length,
        debtsCount: debts.length,
        productsCount: products.length,
        paymentsCount: payments.length,
        backupTime: DateTime.now(),
      );

      appLogger.info('Exported backup to ${file.path}');
      return _lastResult!;
    } catch (e, stackTrace) {
      _status = BackupStatus.error;
      _lastResult = BackupResult(
        success: false,
        message: 'حدث خطأ أثناء تصدير النسخة الاحتياطية',
        errorDetails: e.toString(),
      );
      appLogger.error('Export error: $e\n$stackTrace');
      return _lastResult!;
    }
  }

  /// Shares the backup file via system share sheet.
  static Future<bool> shareBackupFile() async {
    try {
      final files = await getBackupFiles();
      late File fileToShare;

      if (files.isNotEmpty) {
        fileToShare = files.first as File;
      } else {
        final result = await exportToFile();
        if (!result.success) return false;
        final newFiles = await getBackupFiles();
        if (newFiles.isEmpty) return false;
        fileToShare = newFiles.first as File;
      }

      await Share.shareXFiles(
        [XFile(fileToShare.path)],
        subject: 'نسخة احتياطية - مدين',
        text: 'نسخة احتياطية من بيانات تطبيق مدين',
      );
      return true;
    } catch (e) {
      appLogger.warning('Share backup error: $e');
      return false;
    }
  }

  /// Imports data from a backup file (JSON). Clears existing data first.
  static Future<BackupResult> importFromFile(File file) async {
    _status = BackupStatus.backingUp;
    _lastResult = null;

    try {
      final content = await file.readAsString();
      final backupData = jsonDecode(content) as Map<String, dynamic>;

      // Validate backup structure
      if (!backupData.containsKey('customers') ||
          !backupData.containsKey('debts')) {
        _status = BackupStatus.error;
        _lastResult = BackupResult(
          success: false,
          message: 'ملف النسخة الاحتياطية غير صالح',
        );
        return _lastResult!;
      }

      // Resolve the authenticated user. When signed in, every imported record
      // must be reassigned to this ID so that Supabase RLS accepts them on
      // the next sync. Falls back to preserving the stored userId if not signed in.
      final realUserId = SupabaseService.currentUser?.id;

      // Clear existing data
      await HiveService.clearAll();
      await NotificationService.cancelAll();

      // Restore customers
      int customersCount = 0;
      final customersList = backupData['customers'] as List<dynamic>? ?? [];
      for (final item in customersList) {
        try {
          var customer = Customer.fromJson(item as Map<String, dynamic>);
          if (realUserId != null) {
            customer = customer.copyWith(userId: realUserId);
          }
          await HiveService.saveCustomer(customer, addToSync: false);
          customersCount++;
        } catch (e) {
          appLogger.warning('Error importing customer: $e');
        }
      }

      // Restore products
      int productsCount = 0;
      final productsList = backupData['products'] as List<dynamic>? ?? [];
      for (final item in productsList) {
        try {
          var product = Product.fromJson(item as Map<String, dynamic>);
          if (realUserId != null) {
            product = product.copyWith(userId: realUserId);
          }
          await HiveService.saveProduct(product, addToSync: false);
          productsCount++;
        } catch (e) {
          appLogger.warning('Error importing product: $e');
        }
      }

      // Restore debts
      int debtsCount = 0;
      final debtsList = backupData['debts'] as List<dynamic>? ?? [];
      for (final item in debtsList) {
        try {
          var debt = Debt.fromJson(item as Map<String, dynamic>);
          if (realUserId != null) {
            debt = debt.copyWith(userId: realUserId);
          }
          await HiveService.saveDebt(debt, addToSync: false);
          debtsCount++;
        } catch (e) {
          appLogger.warning('Error importing debt: $e');
        }
      }

      // Restore payments
      int paymentsCount = 0;
      final paymentsList = backupData['payments'] as List<dynamic>? ?? [];
      for (final item in paymentsList) {
        try {
          var payment = Payment.fromJson(item as Map<String, dynamic>);
          if (realUserId != null) {
            payment = payment.copyWith(userId: realUserId);
          }
          await HiveService.savePayment(payment, addToSync: false);
          paymentsCount++;
        } catch (e) {
          appLogger.warning('Error importing payment: $e');
        }
      }

      // Restore settings (optional)
      if (backupData.containsKey('settings')) {
        try {
          final settings = AppSettings.fromJson(
            backupData['settings'] as Map<String, dynamic>,
          );
          await HiveService.saveAppSettings(settings);
          // Reschedule notifications using the newly imported settings
          await NotificationService.scheduleFromSettings(settings);
        } catch (e) {
          appLogger.warning('Error importing settings: $e');
        }
      }

      final totalRecords =
          customersCount + productsCount + debtsCount + paymentsCount;

      _status = BackupStatus.success;
      _lastResult = BackupResult(
        success: true,
        message: 'تم استيراد النسخة الاحتياطية بنجاح ($totalRecords سجل)',
        customersCount: customersCount,
        debtsCount: debtsCount,
        productsCount: productsCount,
        paymentsCount: paymentsCount,
        backupTime: DateTime.now(),
      );

      appLogger.info(
        'Imported backup: $customersCount customers, $productsCount products, '
        '$debtsCount debts, $paymentsCount payments',
      );
      return _lastResult!;
    } catch (e, stackTrace) {
      _status = BackupStatus.error;
      _lastResult = BackupResult(
        success: false,
        message: 'حدث خطأ أثناء استيراد النسخة الاحتياطية',
        errorDetails: e.toString(),
      );
      appLogger.error('Import error: $e\n$stackTrace');
      return _lastResult!;
    }
  }

  /// Returns list of backup files sorted by date (newest first).
  static Future<List<FileSystemEntity>> getBackupFiles() async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      return dir
          .listSync()
          .whereType<File>()
          .where((f) => f.path.contains('debt_tracker_backup_'))
          .toList()
        ..sort((a, b) => b.path.compareTo(a.path));
    } catch (e) {
      appLogger.warning('Error listing backup files: $e');
      return [];
    }
  }
}
