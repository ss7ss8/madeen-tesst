import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'core/theme/app_theme.dart';
import 'core/services/notification_service.dart';
import 'core/utils/logger.dart';
import 'data/local/hive_service.dart';
import 'shared/providers/theme_provider.dart';
import 'features/auth/screens/login_screen.dart';
import 'features/auth/screens/splash_screen.dart';
import 'features/auth/providers/auth_provider.dart';
import 'routing/app_lock_wrapper.dart';
import 'core/services/supabase_service.dart';
import 'core/services/sync_service.dart';
import 'core/services/app_shortcuts_service.dart';
import 'core/services/home_widget_service.dart';
import 'shared/providers/sync_provider.dart';
import 'shared/providers/thermal_printer_service.dart';

const _log = Logger('App');

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (kDebugMode) {
  }

  // منع Google Fonts من التحميل الشبكي — استخدم الخط المخزّن مؤقتاً فقط
  GoogleFonts.config.allowRuntimeFetching = false;

  // Show build errors in release mode instead of black screen
  ErrorWidget.builder = (details) => MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('خطأ: ${details.exception}'),
        ),
      ),
    ),
  );

  // شغّل فوراً — SplashScreen تظهر في الحال.
  // التهيئة (Env + Hive + Supabase) تتم في الخلفية عبر appInitProvider.
  runApp(const ProviderScope(child: DebtTrackerApp()));
}

class DebtTrackerApp extends ConsumerStatefulWidget {
  const DebtTrackerApp({super.key});

  @override
  ConsumerState<DebtTrackerApp> createState() => _DebtTrackerAppState();
}

class _DebtTrackerAppState extends ConsumerState<DebtTrackerApp> {
  String? _lastSyncedUserIdForSession;
  bool _isInitialSyncDone = false;

  @override
  void initState() {
    super.initState();
    // سجّل مستمع onConnectivityChanged فوراً (دون addPostFrameCallback)
    // حتى لا تضيع إشارة عودة الإنترنت في الثواني الأولى بعد الفتح.
    try {
      SyncService.init();
    } catch (e) {
      _log.error('SyncService.init failed: $e');
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initializeDeferredServices();
    });
  }

  Future<void> _initializeDeferredServices() async {
    // انتظر اكتمال التهيئة الأساسية (Env + Hive + Supabase) أولاً
    // قبل تشغيل الخدمات المؤجلة التي تعتمد عليها.
    try {
      await ref.read(appInitProvider.future);
    } catch (e) {
      _log.error('appInitProvider failed — skipping deferred services: $e');
      return;
    }

    try {
      AppShortcutsService.init();
    } catch (e) {
      _log.error('AppShortcutsService.init failed: $e');
    }

    try {
      HomeWidgetService.init();
    } catch (e) {
      _log.error('HomeWidgetService.init failed: $e');
    }

    try {
      await NotificationService.init();
      await NotificationService.scheduleFromSettings(
        HiveService.getAppSettings(),
      );
    } catch (e) {
      _log.error('Notification deferred init error: $e');
    }

    // (البند 6) أعد الاتصال التلقائي بآخر طابعة محفوظة في الخلفية دون
    // حجب الواجهة — إن لم يوجد MAC محفوظ فلا شيء يحدث (أمر متوقع أول مرة).
    try {
      final settings = HiveService.getAppSettings();
      if (settings.lastPrinterMac != null &&
          settings.lastPrinterMac!.isNotEmpty) {
        await ref
            .read(thermalPrinterProvider.notifier)
            .autoConnectFromSettings(settings);
        _log.info('autoConnectFromSettings completed');
      }
    } catch (e) {
      _log.error('autoConnectFromSettings failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeMode = ref.watch(themeModeProvider);
    final themeColor = ref.watch(themeColorProvider);

    // اقرأ حالة التهيئة (Env + Hive + Supabase) أولاً.
    // أثناء التهيئة أو عند الخطأ → اعرض SplashScreen.
    final initState = ref.watch(appInitProvider);

    // When auth resolves: switch per-user Hive boxes + restore from Supabase
    // + trigger sync. This handles:
    //   - Fresh install with existing Supabase account (restore)
    //   - App restart while signed in (restore + sync)
    //   - Account switch (switchUser clears old boxes, restore pulls new)
    ref.listen(authStateProvider, (_, next) {
      next.whenData((user) async {
        if (user != null) {
          await HiveService.switchUser(user.id);

          if (SyncService.isSyncing) {
            _log.info('[App] Auth sync skipped: already syncing');
            return;
          }
          if (_isInitialSyncDone &&
              user.id == _lastSyncedUserIdForSession) {
            _log.info(
              '[App] Auth sync skipped: initialSession duplicate for user=${user.id}',
            );
            return;
          }
          _isInitialSyncDone = true;
          _lastSyncedUserIdForSession = user.id;

          // Determine whether this is a fresh install (no local data) or a
          // regular app restart with existing local data.
          //
          // FRESH INSTALL / NEW LOGIN → local DB is empty:
          //   Pull everything from Supabase first so the UI is populated,
          //   then run syncAll to drain any pending queue items.
          //
          // APP RESTART with local data → local DB has records:
          //   Skip the full restore to avoid overwriting un-synced local
          //   changes with stale server data. Run syncAll to push pending
          //   writes and then pull back the latest server state.
          final hasLocalData =
              HiveService.getAllCustomers(includeDeleted: true).isNotEmpty ||
              HiveService.getAllDebts(includeDeleted: true).isNotEmpty;

          if (!hasLocalData) {
            // حساب جديد — restore كامل من Supabase
            _log.info('[App] Auth: no local data — restoring from Supabase');
            try {
              await SyncService.restoreAllDataFromSupabase();
              _log.info('[App] Auth restore succeeded');
            } catch (e) {
              _log.error('[App] Auth restore failed: $e');
            }
          } else {
            // بيانات محلية موجودة — sync كافٍ (يشمل _pullRemoteChanges).
            // السحب الكامل عبر restoreAllDataFromSupabase غير ضروري عند كل فتح.
            _log.info('[App] Auth: local data found — syncing only');
            try {
              await SyncService.syncAll();
              _log.info('[App] Auth: sync completed');
            } catch (e) {
              _log.error('[App] Auth sync failed: $e');
            }
          }
        } else {
          await HiveService.switchUser(null);
          _isInitialSyncDone = false;
          _lastSyncedUserIdForSession = null;
        }
      });
    });

    return MaterialApp(
      title: 'مدين',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme(primaryColor: themeColor),
      darkTheme: AppTheme.darkTheme(primaryColor: themeColor),
      themeMode: themeMode,
      locale: const Locale('ar', 'IQ'),
      supportedLocales: const [Locale('ar', 'IQ'), Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: initState.when(
        loading: () => const SplashScreen(),
        // لا تُبقِ المستخدم عالقاً على Splash عند فشل التهيئة —
        // اعرض شاشة خطأ مع زر إعادة المحاولة.
        error: (e, _) => _InitErrorScreen(
          error: e,
          onRetry: () => ref.invalidate(appInitProvider),
        ),
        data: (_) {
          // التهيئة اكتملت — تابع بمنطق المصادقة الأصلي.
          final authState = ref.watch(authStateProvider);
          return authState.when(
            data: (user) {
              if (user == null) {
                return const LoginScreen();
              }
              return const AppLockWrapper();
            },
            loading: () => const SplashScreen(),
            error: (error, _) {
              // Fallback: if a network auth error somehow bypassed the
              // StreamTransformer, use the locally-cached session so the
              // app keeps working offline.
              final cachedUser = SupabaseService.currentUser;
              if (cachedUser != null) {
                return const AppLockWrapper();
              }
              // No cached session and a real error — show login screen
              // (user will need to sign in when connectivity is restored).
              return const LoginScreen();
            },
          );
        },
      ),
    );
  }
}

/// شاشة خطأ التهيئة مع زر إعادة المحاولة — تمنع البقاء عالقاً على Splash.
class _InitErrorScreen extends StatelessWidget {
  final Object error;
  final VoidCallback onRetry;

  const _InitErrorScreen({required this.error, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 64, color: Colors.red),
              const SizedBox(height: 16),
              const Text(
                'فشل في تهيئة التطبيق',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                '$error',
                style: const TextStyle(fontSize: 14, color: Colors.grey),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh),
                label: const Text('إعادة المحاولة'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
