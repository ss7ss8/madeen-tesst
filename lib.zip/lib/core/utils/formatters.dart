import 'package:intl/intl.dart';

class Formatters {
  Formatters._();

  static final _iqdFormatter = NumberFormat('#,##0', 'ar_IQ');
  static final _dateFormatter = DateFormat('yyyy/MM/dd', 'ar');
  static final _dateTimeFormatter = DateFormat('yyyy/MM/dd HH:mm', 'ar');
  static final _timeFormatter = DateFormat('HH:mm', 'ar');
  static final _monthYearFormatter = DateFormat('MMMM yyyy', 'ar');
  static final _shortDateFormatter = DateFormat('d/M', 'ar');

  /// Format amount as Iraqi Dinar (full number always).
  static String formatCurrency(num amount) {
    return '${_iqdFormatter.format(amount)} د.ع';
  }

  /// Format amount as Iraqi Dinar with compact notation.
  /// - amount < 1000: full number with " د.ع"
  /// - amount >= 1000: automatically shortened (ألف/مليون/مليار)
  static String formatCurrencyCompact(num amount) {
    if (amount.abs() >= 1000) {
      return _formatShortCurrency(amount);
    }
    return '${_iqdFormatter.format(amount)} د.ع';
  }

  /// Format amount as Iraqi Dinar with a dual notation for messages.
  /// - First part: full number with " د.ع" (same as formatCurrency).
  /// - Second part (in parentheses): same logic as formatCurrencyCompact but
  ///   with the full word "دينار عراقي" instead of "د.ع".
  /// - For amounts < 1000: second part is omitted (no repetition).
  static String formatCurrencyDual(num amount) {
    final first = formatCurrency(amount);
    if (amount.abs() < 1000) {
      return first;
    }
    return '$first (${_formatShortCurrencyWord(amount)})';
  }

  static String _formatShortCurrency(num amount) {
    final isNegative = amount < 0;
    final abs = amount.abs();
    String suffix;
    if (abs >= 1000000000) {
      final val = abs / 1000000000;
      suffix = '${val.toStringAsFixed(val == val.toInt() ? 0 : 1)} مليار';
    } else if (abs >= 1000000) {
      final val = abs / 1000000;
      suffix = '${val.toStringAsFixed(val == val.toInt() ? 0 : 1)} مليون';
    } else if (abs >= 1000) {
      final val = abs / 1000;
      suffix = '${val.toStringAsFixed(val == val.toInt() ? 0 : 1)} ألف';
    } else {
      return '${_iqdFormatter.format(amount)} د.ع';
    }
    return '${isNegative ? '-' : ''}$suffix د.ع';
  }

  static String _formatShortCurrencyWord(num amount) {
    final isNegative = amount < 0;
    final abs = amount.abs();
    String suffix;
    if (abs >= 1000000000) {
      final val = abs / 1000000000;
      suffix = '${val.toStringAsFixed(val == val.toInt() ? 0 : 1)} مليار';
    } else if (abs >= 1000000) {
      final val = abs / 1000000;
      suffix = '${val.toStringAsFixed(val == val.toInt() ? 0 : 1)} مليون';
    } else if (abs >= 1000) {
      final val = abs / 1000;
      suffix = '${val.toStringAsFixed(val == val.toInt() ? 0 : 1)} ألف';
    } else {
      return _iqdFormatter.format(amount);
    }
    return '${isNegative ? '-' : ''}$suffix دينار عراقي';
  }

  /// Format amount without currency symbol
  static String formatAmount(num amount) {
    return _iqdFormatter.format(amount);
  }

  /// Format currency input (removes commas, returns number)
  static num parseCurrency(String value) {
    final cleaned = value.replaceAll(RegExp(r'[^\d]'), '');
    return num.tryParse(cleaned) ?? 0;
  }

  /// Format currency for input field (adds commas as user types)
  static String formatCurrencyInput(String value) {
    final number = parseCurrency(value);
    if (number == 0 && value.isEmpty) return '';
    return formatAmount(number);
  }

  /// Format date (e.g., 2024/06/15)
  static String formatDate(DateTime date) {
    return _dateFormatter.format(date);
  }

  /// Format date and time
  static String formatDateTime(DateTime date) {
    return _dateTimeFormatter.format(date);
  }

  /// Format time only
  static String formatTime(DateTime date) {
    return _timeFormatter.format(date);
  }

  /// Format month and year
  static String formatMonthYear(DateTime date) {
    return _monthYearFormatter.format(date);
  }

  /// Format short date (e.g., 15/6)
  static String formatShortDate(DateTime date) {
    return _shortDateFormatter.format(date);
  }

  /// Alias for formatShortDate — used in PDF service
  static String formatDateShort(DateTime date) => formatShortDate(date);

  /// Format relative date (e.g., "منذ 3 أيام", "اليوم", "غداً")
  static String formatRelativeDate(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final dateOnly = DateTime(date.year, date.month, date.day);
    final difference = today.difference(dateOnly).inDays;

    if (difference == 0) return 'اليوم';
    if (difference == 1) return 'أمس';
    if (difference == -1) return 'غداً';
    if (difference > 1 && difference < 7) return 'منذ $difference أيام';
    if (difference >= 7 && difference < 30) {
      final weeks = (difference / 7).floor();
      return 'منذ $weeks ${weeks == 1 ? 'أسبوع' : 'أسابيع'}';
    }
    if (difference >= 30) {
      final months = (difference / 30).floor();
      return 'منذ $months ${months == 1 ? 'شهر' : 'أشهر'}';
    }
    return formatDate(date);
  }

  /// Format phone number
  static String formatPhone(String phone) {
    if (phone.isEmpty) return '';
    // Format: 0770 123 4567
    final cleaned = phone.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.length == 10) {
      return '${cleaned.substring(0, 4)} ${cleaned.substring(4, 7)} ${cleaned.substring(7)}';
    }
    if (cleaned.length == 11) {
      return '${cleaned.substring(0, 4)} ${cleaned.substring(4, 7)} ${cleaned.substring(7)}';
    }
    return phone;
  }

  /// Format phone number for WhatsApp international format (e.g., 9647701234567)
  static String formatPhoneForWhatsApp(String rawPhone) {
    String digits = rawPhone.replaceAll(RegExp(r'[^\d+]'), '');
    if (digits.isEmpty) return '';
    if (digits.startsWith('+')) {
      digits = digits.substring(1);
    }
    if (digits.startsWith('0')) {
      digits = digits.substring(1);
    }
    if (!digits.startsWith('964')) {
      digits = '964$digits';
    }
    return digits;
  }

  /// Format percentage
  static String formatPercentage(double value) {
    return '${(value * 100).toStringAsFixed(1)}%';
  }

  /// Format quantity
  static String formatQuantity(int quantity) {
    if (quantity == 1) return 'قطعة واحدة';
    if (quantity == 2) return 'قطعتان';
    if (quantity < 11) return '$quantity قطع';
    return '$quantity قطعة';
  }
}
