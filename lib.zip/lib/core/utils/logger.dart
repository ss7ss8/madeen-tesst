import 'package:flutter/foundation.dart';

/// Lightweight logger that only outputs in debug mode.
/// In release builds, all calls are no-ops (the compiler tree-shakes
/// the string interpolation, so there is zero runtime cost).
class Logger {
  final String _name;

  const Logger(this._name);

  void info(String message) {
    if (kDebugMode) debugPrint('[$_name] $message');
  }

  void warn(String message) {
    if (kDebugMode) debugPrint('[$_name] ⚠ $message');
  }

  void error(String message) {
    if (kDebugMode) debugPrint('[$_name] ✗ $message');
  }

  /// Verbose diagnostic output — only in debug mode.
  void debug(String message) {
    if (kDebugMode) debugPrint('[$_name] $message');
  }

  /// Convenience aliases that match the call-sites in the codebase.
  void warning(String message) => warn(message);
}

/// Global logger instance for the app.
const appLogger = Logger('App');
