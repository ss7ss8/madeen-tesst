import 'dart:io';

import 'package:flutter/foundation.dart';

/// Build-time configuration injected via --dart-define.
///
/// In debug builds, values can also be read from a local `.env` file on disk
/// for developer convenience. Release builds rely only on compile-time values
/// and never bundle `.env` into the APK.
class AppConfig {
  AppConfig._();

  static final Map<String, String> _runtimeEnv = {};

  /// Supabase project URL (via --dart-define=SUPABASE_URL=... or local .env).
  static String get supabaseUrl => _envOr(
        'SUPABASE_URL',
        const String.fromEnvironment('SUPABASE_URL'),
      );

  /// Supabase anonymous/publishable key.
  static String get supabasePublishableKey => _envOr(
        'SUPABASE_ANON_KEY',
        const String.fromEnvironment('SUPABASE_ANON_KEY'),
      );

  /// Google OAuth Web Client ID.
  static String get googleWebClientId => _envOr(
        'GOOGLE_WEB_CLIENT_ID',
        const String.fromEnvironment('GOOGLE_WEB_CLIENT_ID'),
      );

  /// Current environment. Defaults to 'prod' so release builds are safe even
  /// if APP_ENV is accidentally omitted from the build command.
  static String get _appEnv => _envOr(
        'APP_ENV',
        const String.fromEnvironment('APP_ENV'),
        defaultValue: 'prod',
      );

  /// Loads a local `.env` file in debug mode only.
  static Future<void> loadEnvFallback() async {
    if (!kDebugMode) return;

    _runtimeEnv.clear();

    if (!kIsWeb) {
      // Build candidate list safely.
      // Order: cwd → executable dir → executable's parent dirs.
      final candidatePaths = <String>[
        '.env',
        '${Directory(Platform.resolvedExecutable).parent.path}/.env',
        '${Directory(Platform.resolvedExecutable).parent.parent.path}/.env',
        '${Directory(Platform.resolvedExecutable).parent.parent.parent.path}/.env',
      ];

      for (final path in candidatePaths) {
        try {
          final envFile = File(path);
          if (!await envFile.exists()) continue;

          final lines = await envFile.readAsLines();
          for (final rawLine in lines) {
            final line = rawLine.trim();
            if (line.isEmpty || line.startsWith('#')) continue;

            final separatorIndex = line.indexOf('=');
            if (separatorIndex <= 0) continue;

            final key = line.substring(0, separatorIndex).trim();
            final value = line.substring(separatorIndex + 1).trim();
            _runtimeEnv[key] = _normalizeValue(value);
          }
          break; // Found and loaded — stop searching.
        } catch (_) {
          // Try next candidate.
        }
      }
    }

    // ── Debug-only hardcoded fallback ────────────────────────────────────────
    // Applied ONLY when a key is still missing after reading .env and
    // --dart-define. This guarantees the app always runs during development
    // without extra setup steps. Never compiled into release builds.
    if (kDebugMode) {
      _runtimeEnv.putIfAbsent(
        'SUPABASE_URL',
        () => 'https://rqiuineaqyocfzjjfizo.supabase.co',
      );
      _runtimeEnv.putIfAbsent(
        'SUPABASE_ANON_KEY',
        () =>
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJxaXVpbmVhcXlvY2Z6ampmaXpvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE5NzY5OTksImV4cCI6MjA5NzU1Mjk5OX0.PhKHBF5VEguP7QqogdsmWmNOPRai4zduZ0aUZwzvqFc',
      );
      _runtimeEnv.putIfAbsent(
        'GOOGLE_WEB_CLIENT_ID',
        () =>
            '96024199507-m8q17img9plvl43la31b0q55cjte9i0h.apps.googleusercontent.com',
      );
    }
    // ────────────────────────────────────────────────────────────────────────
  }

  static String _envOr(String key, String defineValue, {String defaultValue = ''}) {
    if (defineValue.isNotEmpty) return defineValue;
    return _runtimeEnv[key] ?? defaultValue;
  }

  static String _normalizeValue(String value) {
    if (value.length >= 2) {
      final first = value.substring(0, 1);
      final last = value.substring(value.length - 1);
      if ((first == '"' && last == '"') || (first == "'" && last == "'")) {
        return value.substring(1, value.length - 1);
      }
    }
    return value;
  }

  /// `true` when built with APP_ENV=prod (or no APP_ENV define).
  static bool get isProduction => _appEnv == 'prod';

  /// `true` when built with APP_ENV=dev.
  static bool get isDevelopment => _appEnv == 'dev';
}
