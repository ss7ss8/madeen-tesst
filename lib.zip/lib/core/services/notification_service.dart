import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../../data/models/customer.dart';
import '../../data/models/debt.dart';
import '../../data/models/payment.dart';
import '../../data/models/settings.dart';

class NotificationService {
  NotificationService._();

  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static const String _androidChannelId = 'debt_tracker_channel';
  static const String _androidChannelName = 'DebtTracker Notifications';

  // Using zonedSchedule IDs; store nothing persistent here.
  static const String _dailyScheduleKey = 'daily_reminder';
  static const String _weeklyScheduleKey = 'weekly_reminder';

  static Future<void> init() async {
    tz.initializeTimeZones();

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    final iosInit = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    final initSettings = InitializationSettings(
      android: androidInit,
      iOS: iosInit,
    );

    await _plugin.initialize(initSettings);
    await _ensureAndroidChannel();

    // Request POST_NOTIFICATIONS permission on Android 13+
    final androidPlugin = _plugin
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >();
    await androidPlugin?.requestNotificationsPermission();
    await androidPlugin?.requestExactAlarmsPermission();
  }

  static Future<void> _ensureAndroidChannel() async {
    final androidPlugin = _plugin
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >();

    if (androidPlugin == null) return;

    await androidPlugin.createNotificationChannel(
      const AndroidNotificationChannel(
        _androidChannelId,
        _androidChannelName,
        description: 'إشعارات إدارة الديون',
        importance: Importance.high,
      ),
    );
  }

  static Future<void> showImmediateDebtAdded({
    required AppSettings settings,
    required Customer customer,
    required Debt debt,
  }) async {
    if (!settings.notificationsEnabled ||
        !settings.immediateNotificationsEnabled) {
      return;
    }

    final title = 'تمت إضافة دين جديد';
    final body =
        'الزبون: ${customer.name} - المتبقي: ${debt.remainingAmount.toStringAsFixed(0)} د.ع';

    await _plugin.show(
      _randomImmediateId(),
      title,
      body,
      _notificationDetails(payload: 'customer:${customer.id}'),
    );
  }

  static Future<void> showImmediateDebtPaid({
    required AppSettings settings,
    required Customer customer,
    required Debt debt,
    required Payment payment,
  }) async {
    if (!settings.notificationsEnabled ||
        !settings.immediateNotificationsEnabled) {
      return;
    }

    final paidAmount = payment.amount.toStringAsFixed(0);
    final remaining = debt.remainingAmount.toStringAsFixed(0);

    final title = debt.isPaid ? 'تم التسديد بالكامل' : 'تم تسديد جزء من الدين';
    final body =
        'الزبون: ${customer.name}\nالمسدد: $paidAmount - المتبقي: $remaining د.ع';

    await _plugin.show(
      _randomImmediateId(),
      title,
      body,
      _notificationDetails(payload: 'customer:${customer.id}'),
    );
  }

  static Future<void> scheduleDailyReminder({
    required AppSettings settings,
    required tz.TZDateTime firstInstance,
    required String title,
    required String body,
  }) async {
    if (!settings.notificationsEnabled || !settings.dailyNotificationsEnabled) {
      return;
    }

    await _plugin.zonedSchedule(
      _dailyScheduleId(),
      title,
      body,
      firstInstance,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          _androidChannelId,
          _androidChannelName,
          importance: Importance.high,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      payload: _dailyScheduleKey,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  static Future<void> scheduleWeeklyReminder({
    required AppSettings settings,
    required tz.TZDateTime firstInstance,
    required String title,
    required String body,
  }) async {
    if (!settings.notificationsEnabled ||
        !settings.weeklyNotificationsEnabled) {
      return;
    }

    // Flutter Local Notifications doesn't support "every Monday" out of the box
    // without specifying day-of-week components; for simplicity we schedule weekly
    // at the same weekday as firstInstance.
    await _plugin.zonedSchedule(
      _weeklyScheduleId(),
      title,
      body,
      firstInstance,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          _androidChannelId,
          _androidChannelName,
          importance: Importance.high,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      payload: _weeklyScheduleKey,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      // weekly: match day-of-week + time
      matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
    );
  }

  static Future<void> showLimitWarning({
    required AppSettings settings,
    required Customer customer,
    required double totalDebt,
  }) async {
    if (!settings.notificationsEnabled) return;

    final limit = customer.maxDebtLimit;
    if (limit == null || limit <= 0) return;

    final ratio = totalDebt / limit;
    if (ratio < 0.8) return;

    final title = ratio >= 1.0
        ? 'تجاوز حد الدين الأقصى'
        : 'اقتراب من حد الدين الأقصى';
    final body =
        'الزبون: ${customer.name}\nالرصيد: ${totalDebt.toStringAsFixed(0)} / ${limit.toStringAsFixed(0)} د.ع';

    await _plugin.show(
      _limitWarningId(),
      title,
      body,
      _notificationDetails(payload: 'customer:${customer.id}'),
    );
  }

  /// Schedule or cancel daily/weekly reminders based on current settings.
  /// Call this on app startup and whenever notification settings change.
  static Future<void> scheduleFromSettings(AppSettings settings) async {
    // Cancel existing scheduled notifications first
    await _plugin.cancel(_dailyScheduleId());
    await _plugin.cancel(_weeklyScheduleId());

    if (!settings.notificationsEnabled) return;

    if (settings.dailyNotificationsEnabled) {
      final next9am = nextInstanceAtHourMinute(hour: 9, minute: 0);
      await scheduleDailyReminder(
        settings: settings,
        firstInstance: next9am,
        title: 'تذكير يومي - مدين',
        body: 'راجع ديون زبائنك اليوم 💼',
      );
    }

    if (settings.weeklyNotificationsEnabled) {
      // Schedule for Saturday 9am (day 6 in Dart, weekday 6 = Saturday)
      final now = tz.TZDateTime.now(tz.local);
      int daysUntilSaturday = (6 - now.weekday + 7) % 7;
      if (daysUntilSaturday == 0 && now.hour >= 9) daysUntilSaturday = 7;
      final nextSaturday = tz.TZDateTime(
        tz.local,
        now.year,
        now.month,
        now.day + daysUntilSaturday,
        9,
        0,
      );
      await scheduleWeeklyReminder(
        settings: settings,
        firstInstance: nextSaturday,
        title: 'ملخص أسبوعي - مدين',
        body: 'لديك زبائن متأخرون أكثر من ${settings.lateThresholdDays} يوم 📋',
      );
    }
  }

  static Future<void> cancelAll() async {
    await _plugin.cancelAll();
  }

  static NotificationDetails _notificationDetails({String? payload}) {
    return NotificationDetails(
      android: const AndroidNotificationDetails(
        _androidChannelId,
        _androidChannelName,
        importance: Importance.high,
        priority: Priority.high,
      ),
      iOS: const DarwinNotificationDetails(),
    );
  }

  /// Schedule notifications for an installment debt:
  /// 1) Early notification 1 day before due (if notifyBeforeInstallment enabled)
  /// 2) Due-date notification (always, if the due date is in the future)
  static Future<void> scheduleInstallmentNotification({
    required AppSettings settings,
    required String debtId,
    required int installmentIndex,
    required DateTime dueDate,
    required double amount,
    required String customerName,
  }) async {
    if (!settings.notificationsEnabled) return;
    if (dueDate.isBefore(DateTime.now())) return;

    final amountStr = amount.toStringAsFixed(0);

    // Due-date notification (always schedule if future)
    final dueTz = tz.TZDateTime.from(dueDate, tz.local);
    await _plugin.zonedSchedule(
      _installmentNotifId(debtId, installmentIndex, isEarly: false),
      'قسط مستحق اليوم',
      '$customerName - $amountStr د.ع',
      dueTz,
      _notificationDetails(payload: 'debt:$debtId'),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );

    // Early notification (1 day before) if enabled and future
    if (!settings.notifyBeforeInstallment) return;
    final earlyDate = dueDate.subtract(const Duration(days: 1));
    if (earlyDate.isBefore(DateTime.now())) return;

    final earlyTz = tz.TZDateTime.from(earlyDate, tz.local);
    await _plugin.zonedSchedule(
      _installmentNotifId(debtId, installmentIndex, isEarly: true),
      'قسط مستحق غداً',
      '$customerName - $amountStr د.ع',
      earlyTz,
      _notificationDetails(payload: 'debt:$debtId'),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  /// Schedule notifications for all installments of a debt
  static Future<void> scheduleAllInstallmentNotifications({
    required AppSettings settings,
    required Debt debt,
    required String customerName,
  }) async {
    if (!debt.isInstallment ||
        debt.installmentDates == null ||
        debt.installmentAmounts == null) {
      return;
    }
    for (int i = 0; i < debt.installmentDates!.length; i++) {
      if (debt.installmentStatuses != null &&
          i < debt.installmentStatuses!.length &&
          debt.installmentStatuses![i] == 'paid') {
        continue;
      }
      await scheduleInstallmentNotification(
        settings: settings,
        debtId: debt.id,
        installmentIndex: i,
        dueDate: debt.installmentDates![i],
        amount: debt.installmentAmounts![i],
        customerName: customerName,
      );
    }
  }

  /// Schedule notifications for a regular debt with a due date:
  /// 1) Early notification 1 day before due (if notifyBeforeInstallment enabled)
  /// 2) Due-date notification (always, if the due date is in the future)
  static Future<void> scheduleRegularDebtNotification({
    required AppSettings settings,
    required String debtId,
    required DateTime dueDate,
    required double amount,
    required String customerName,
  }) async {
    if (!settings.notificationsEnabled) return;
    if (dueDate.isBefore(DateTime.now())) return;

    final amountStr = amount.toStringAsFixed(0);

    // Due-date notification
    final dueTz = tz.TZDateTime.from(dueDate, tz.local);
    await _plugin.zonedSchedule(
      _regularDebtNotifId(debtId, isEarly: false),
      'دين مستحق اليوم',
      'الزبون: $customerName - المبلغ: $amountStr د.ع',
      dueTz,
      _notificationDetails(payload: 'debt:$debtId'),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );

    // Early notification (1 day before) if enabled and future
    if (!settings.notifyBeforeInstallment) return;
    final earlyDate = dueDate.subtract(const Duration(days: 1));
    if (earlyDate.isBefore(DateTime.now())) return;

    final earlyTz = tz.TZDateTime.from(earlyDate, tz.local);
    await _plugin.zonedSchedule(
      _regularDebtNotifId(debtId, isEarly: true),
      'دين مستحق غداً',
      'الزبون: $customerName - المبلغ: $amountStr د.ع',
      earlyTz,
      _notificationDetails(payload: 'debt:$debtId'),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  /// Cancel both notifications for a specific installment
  static Future<void> cancelInstallmentNotifications(
    String debtId,
    int installmentIndex,
  ) async {
    await _plugin.cancel(
      _installmentNotifId(debtId, installmentIndex, isEarly: true),
    );
    await _plugin.cancel(
      _installmentNotifId(debtId, installmentIndex, isEarly: false),
    );
  }

  /// Cancel ALL notifications for a debt (both installment and regular)
  static Future<void> cancelAllDebtNotifications(String debtId) async {
    // Cancel regular debt notifications
    await _plugin.cancel(_regularDebtNotifId(debtId, isEarly: true));
    await _plugin.cancel(_regularDebtNotifId(debtId, isEarly: false));

    // Cancel up to a reasonable max (e.g., 100 installments)
    for (int i = 0; i < 100; i++) {
      await _plugin.cancel(
        _installmentNotifId(debtId, i, isEarly: true),
      );
      await _plugin.cancel(
        _installmentNotifId(debtId, i, isEarly: false),
      );
    }
  }

  static int _randomImmediateId() =>
      DateTime.now().millisecondsSinceEpoch ~/ 1000;

  static int _dailyScheduleId() => 2000;
  static int _weeklyScheduleId() => 2001;
  static int _limitWarningId() => 3000;

  /// Generate deterministic notification ID for installment.
  /// Uses range 10000+ to avoid collision with existing IDs (2000, 2001, 3000).
  static int _installmentNotifId(String debtId, int index,
      {required bool isEarly}) {
    return 10000 +
        (debtId.hashCode.abs() % 900000) +
        index * 2 +
        (isEarly ? 0 : 1);
  }

  /// Generate deterministic notification ID for a regular debt.
  /// Uses range 1000000+ to avoid collision with installments.
  static int _regularDebtNotifId(String debtId, {required bool isEarly}) {
    return 1000000 + (debtId.hashCode.abs() % 9000000) + (isEarly ? 0 : 1);
  }

  static tz.TZDateTime nextInstanceAtHourMinute({
    required int hour,
    required int minute,
  }) {
    final now = tz.TZDateTime.now(tz.local);

    tz.TZDateTime scheduled = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      hour,
      minute,
    );

    if (scheduled.isBefore(now) || scheduled.isAtSameMomentAs(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }
    return scheduled;
  }
}
