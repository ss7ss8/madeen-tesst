import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../utils/logger.dart';

const _log = Logger('Supabase');

class SupabaseService {
  static SupabaseClient get client => Supabase.instance.client;

  static User? get currentUser => client.auth.currentUser;

  static Stream<User?> get authStateChanges =>
      client.auth.onAuthStateChange.map((event) => event.session?.user);

  static Future<void> init({
    required String url,
    required String publishableKey,
  }) async {
    await Supabase.initialize(url: url, publishableKey: publishableKey);

    client.auth.onAuthStateChange.listen((data) {
      final user = data.session?.user;
      _log.info(
        'Auth event: ${data.event}, user: ${user != null ? "${user.id.substring(0, 8)}..." : "null"}',
      );
    });
  }

  static Future<void> signOut() async {
    await client.auth.signOut();
  }

  // ============ CUSTOMERS ============

  static Future<List<Map<String, dynamic>>> getCustomers(String userId) async {
    final response = await client
        .from('customers')
        .select()
        .eq('user_id', userId)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(response);
  }

  static Future<void> upsertCustomer(Map<String, dynamic> customer) async {
    try {
      await client.from('customers').upsert(customer);
      _log.info('upsertCustomer OK');
    } catch (e) {
      _log.error('upsertCustomer FAILED: $e');
      if (e is PostgrestException) {
        _log.error('  code=${e.code} message=${e.message}');
      }
      rethrow;
    }
  }

  /// Batch upsert for customers — sends all rows in a single network request.
  static Future<void> upsertCustomersBatch(
    List<Map<String, dynamic>> customers,
  ) async {
    if (customers.isEmpty) return;
    try {
      await client.from('customers').upsert(customers);
      _log.info('upsertCustomersBatch OK (${customers.length} rows)');
    } catch (e) {
      _log.error('upsertCustomersBatch FAILED: $e');
      if (e is PostgrestException) {
        _log.error('  code=${e.code} message=${e.message}');
      }
      rethrow;
    }
  }

  static Future<void> deleteCustomer(String id) async {
    await client
        .from('customers')
        .update({'deleted_at': DateTime.now().toIso8601String()})
        .eq('id', id);
  }

  static Future<void> permanentDeleteCustomer(String id) async {
    await client.from('customers').delete().eq('id', id);
  }

  // ============ DEBTS ============

  static Future<List<Map<String, dynamic>>> getDebts(String userId) async {
    final response = await client
        .from('debts')
        .select()
        .eq('user_id', userId)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(response);
  }

  static Future<void> upsertDebt(Map<String, dynamic> debt) async {
    try {
      await client.from('debts').upsert(debt);
      _log.info('upsertDebt OK');
    } catch (e) {
      _log.error('upsertDebt FAILED: $e');
      if (e is PostgrestException) {
        _log.error('  code=${e.code} message=${e.message}');
      }
      rethrow;
    }
  }

  /// Batch upsert for debts — sends all rows in a single network request.
  static Future<void> upsertDebtsBatch(List<Map<String, dynamic>> debts) async {
    if (debts.isEmpty) return;
    try {
      await client.from('debts').upsert(debts);
      _log.info('upsertDebtsBatch OK (${debts.length} rows)');
    } catch (e) {
      _log.error('upsertDebtsBatch FAILED: $e');
      if (e is PostgrestException) {
        _log.error('  code=${e.code} message=${e.message}');
      }
      rethrow;
    }
  }

  static Future<void> deleteDebt(String id) async {
    await client
        .from('debts')
        .update({'deleted_at': DateTime.now().toIso8601String()})
        .eq('id', id);
  }

  static Future<void> permanentDeleteDebt(String id) async {
    await client.from('debts').delete().eq('id', id);
  }

  // ============ PRODUCTS ============

  static Future<List<Map<String, dynamic>>> getProducts(String userId) async {
    final response = await client
        .from('products')
        .select()
        .eq('user_id', userId)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(response);
  }

  static Future<void> upsertProduct(Map<String, dynamic> product) async {
    try {
      await client.from('products').upsert(product);
      _log.info('upsertProduct OK');
    } catch (e) {
      _log.error('upsertProduct FAILED: $e');
      if (e is PostgrestException) {
        _log.error('  code=${e.code} message=${e.message}');
      }
      rethrow;
    }
  }

  /// Batch upsert for products — sends all rows in a single network request.
  static Future<void> upsertProductsBatch(
    List<Map<String, dynamic>> products,
  ) async {
    if (products.isEmpty) return;
    try {
      await client.from('products').upsert(products);
      _log.info('upsertProductsBatch OK (${products.length} rows)');
    } catch (e) {
      _log.error('upsertProductsBatch FAILED: $e');
      if (e is PostgrestException) {
        _log.error('  code=${e.code} message=${e.message}');
      }
      rethrow;
    }
  }

  static Future<void> deleteProduct(String id) async {
    await client
        .from('products')
        .update({'deleted_at': DateTime.now().toIso8601String()})
        .eq('id', id);
  }

  static Future<void> permanentDeleteProduct(String id) async {
    await client.from('products').delete().eq('id', id);
  }

  // ============ PAYMENTS ============

  static Future<List<Map<String, dynamic>>> getPayments(String userId) async {
    final response = await client
        .from('payments')
        .select()
        .eq('user_id', userId)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(response);
  }

  static Future<void> upsertPayment(Map<String, dynamic> payment) async {
    try {
      await client.from('payments').upsert(payment);
      _log.info('upsertPayment OK');
    } catch (e) {
      _log.error('upsertPayment FAILED: $e');
      if (e is PostgrestException) {
        _log.error('  code=${e.code} message=${e.message}');
      }
      rethrow;
    }
  }

  /// Batch upsert for payments — sends all rows in a single network request.
  static Future<void> upsertPaymentsBatch(
    List<Map<String, dynamic>> payments,
  ) async {
    if (payments.isEmpty) return;
    try {
      await client.from('payments').upsert(payments);
      _log.info('upsertPaymentsBatch OK (${payments.length} rows)');
    } catch (e) {
      _log.error('upsertPaymentsBatch FAILED: $e');
      if (e is PostgrestException) {
        _log.error('  code=${e.code} message=${e.message}');
      }
      rethrow;
    }
  }

  static Future<void> deletePayment(String id) async {
    await client
        .from('payments')
        .update({'deleted_at': DateTime.now().toIso8601String()})
        .eq('id', id);
  }

  static Future<void> permanentDeletePayment(String id) async {
    await client.from('payments').delete().eq('id', id);
  }

  // ============ DEBT ITEMS ============

  static Future<List<Map<String, dynamic>>> getDebtItems(String debtId) async {
    final response = await client
        .from('debt_items')
        .select()
        .eq('debt_id', debtId);
    return List<Map<String, dynamic>>.from(response);
  }

  static Future<void> upsertDebtItem(Map<String, dynamic> item) async {
    await client.from('debt_items').upsert(item);
  }

  // ============ INSTALLMENTS ============

  static Future<List<Map<String, dynamic>>> getInstallments(
    String userId,
  ) async {
    final response = await client
        .from('installments')
        .select()
        .eq('user_id', userId)
        .order('installment_number', ascending: true);
    return List<Map<String, dynamic>>.from(response);
  }

  static Future<void> upsertInstallment(
    Map<String, dynamic> installment,
  ) async {
    await client.from('installments').upsert(installment);
  }

  // ============ USER SETTINGS ============

  /// Returns the user's settings row from the `user_settings` table, or
  /// `null` if no row exists yet (first sign-in). The caller should treat
  /// a null result as "use defaults".
  static Future<Map<String, dynamic>?> getUserSettings(String userId) async {
    final response = await client
        .from('user_settings')
        .select()
        .eq('user_id', userId)
        .maybeSingle();
    return response;
  }

  /// Upserts the user's settings row.
  ///
  /// IMPORTANT: `onConflict: 'user_id'` is required because the
  /// `user_settings` table has a separate auto-generated `id` primary key
  /// AND a unique constraint on `user_id` (`user_settings_user_id_key`).
  /// Without `onConflict`, PostgREST resolves conflicts on the primary key
  /// only, so re-uploading an existing user's settings (which carries a
  /// different/null `id` from local Hive) violates the `user_id` unique
  /// constraint → PostgrestException code 23505 "duplicate key value".
  /// Specifying `onConflict: 'user_id'` makes the upsert resolve on the
  /// `user_id` unique constraint instead, turning the insert into an
  /// update of the existing row.
  ///
  /// As defense-in-depth, if the upsert still hits a 23505 conflict
  /// (e.g. due to a schema/RLS edge case), we fall back to an explicit
  /// UPDATE filtered by `user_id` so the settings sync never aborts the
  /// entire `syncAll` loop.
  static Future<void> upsertUserSettings(Map<String, dynamic> settings) async {
    try {
      await client
          .from('user_settings')
          .upsert(settings, onConflict: 'user_id');
      _log.info('upsertUserSettings OK');
    } catch (e) {
      if (e is PostgrestException && e.code == '23505') {
        final userId = settings['user_id'] as String?;
        if (userId != null) {
          _log.warn(
            'upsertUserSettings: 23505 conflict — falling back to UPDATE by user_id',
          );
          // Strip user_id from the payload since it's used in the .eq() filter.
          final updatePayload = Map<String, dynamic>.from(settings)
            ..remove('user_id');
          await client
              .from('user_settings')
              .update(updatePayload)
              .eq('user_id', userId);
          _log.info('upsertUserSettings OK (via fallback UPDATE)');
          return;
        }
      }
      _log.error('upsertUserSettings FAILED: $e');
      if (e is PostgrestException) {
        _log.error('  code=${e.code} message=${e.message}');
      }
      rethrow;
    }
  }

  // ============ STORAGE (Customer Images) ============

  static const String _customerImagesBucket = 'customer-images';

  static Future<String?> uploadCustomerImage(
    String customerId,
    String filePath,
  ) async {
    try {
      final ext = filePath.split('.').last;
      final fileName =
          '${customerId}_${DateTime.now().millisecondsSinceEpoch}.$ext';
      final response = await client.storage
          .from(_customerImagesBucket)
          .upload(fileName, File(filePath));

      if (response.isNotEmpty) {
        final publicUrl = client.storage
            .from(_customerImagesBucket)
            .getPublicUrl(fileName);
        return publicUrl;
      }
      return null;
    } catch (e) {
      _log.error('Upload customer image error: $e');
      return null;
    }
  }

  static Future<void> deleteCustomerImage(String url) async {
    try {
      final uri = Uri.parse(url);
      final fileName = uri.pathSegments.last;
      await client.storage.from(_customerImagesBucket).remove([fileName]);
    } catch (e) {
      _log.error('Delete customer image error: $e');
    }
  }

  // ============ STORAGE (Product Images) ============

  static const String _productImagesBucket = 'product-images';

  /// Uploads a product image to the `product-images` bucket and returns
  /// the public URL. Returns `null` on failure so callers can fall back
  /// to the local file path.
  static Future<String?> uploadProductImage(
    String productId,
    String filePath,
  ) async {
    try {
      final ext = filePath.split('.').last;
      final fileName =
          '${productId}_${DateTime.now().millisecondsSinceEpoch}.$ext';
      final response = await client.storage
          .from(_productImagesBucket)
          .upload(fileName, File(filePath));

      if (response.isNotEmpty) {
        final publicUrl = client.storage
            .from(_productImagesBucket)
            .getPublicUrl(fileName);
        return publicUrl;
      }
      return null;
    } catch (e) {
      _log.error('Upload product image FAILED: type=${e.runtimeType} message=$e');
      return null;
    }
  }

  static Future<void> deleteProductImage(String url) async {
    try {
      final uri = Uri.parse(url);
      final fileName = uri.pathSegments.last;
      await client.storage.from(_productImagesBucket).remove([fileName]);
    } catch (e) {
      _log.error('Delete product image error: $e');
    }
  }

  // ============ STORAGE (Store Logos) ============

  static const String _storeLogosBucket = 'store-logos';

  static Future<String?> uploadStoreLogo(String userId, String filePath) async {
    try {
      final ext = filePath.split('.').last;
      final fileName =
          '${userId}_${DateTime.now().millisecondsSinceEpoch}.$ext';
      final response = await client.storage
          .from(_storeLogosBucket)
          .upload(fileName, File(filePath));

      if (response.isNotEmpty) {
        final publicUrl = client.storage
            .from(_storeLogosBucket)
            .getPublicUrl(fileName);
        return publicUrl;
      }
      return null;
    } catch (e) {
      _log.error('Upload store logo error: $e');
      return null;
    }
  }

  static Future<void> deleteStoreLogo(String url) async {
    try {
      final uri = Uri.parse(url);
      final fileName = uri.pathSegments.last;
      await client.storage.from(_storeLogosBucket).remove([fileName]);
    } catch (e) {
      _log.error('Delete store logo error: $e');
    }
  }

  // ============ AUDIT LOGS ============

  static Future<List<Map<String, dynamic>>> getAuditLogs(String userId) async {
    final response = await client
        .from('audit_logs')
        .select()
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(100);
    return List<Map<String, dynamic>>.from(response);
  }

  static Future<void> upsertAuditLog(Map<String, dynamic> log) async {
    await client.from('audit_logs').upsert(log);
  }

  /// Batch upsert for audit logs — sends all rows in a single network request.
  static Future<void> upsertAuditLogsBatch(
    List<Map<String, dynamic>> logs,
  ) async {
    if (logs.isEmpty) return;
    await client.from('audit_logs').upsert(logs);
    _log.info('upsertAuditLogsBatch OK (${logs.length} rows)');
  }

  static Future<void> deleteAuditLog(String id) async {
    await client.from('audit_logs').delete().eq('id', id);
  }
}
