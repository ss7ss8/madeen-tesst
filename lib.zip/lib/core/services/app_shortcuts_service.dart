import 'package:quick_actions/quick_actions.dart';
import '../utils/logger.dart';

class AppShortcutsService {
  AppShortcutsService._();

  static final QuickActions _quickActions = QuickActions();

  static const _actionNewCustomer = 'action_new_customer';
  static const _actionViewDashboard = 'action_view_dashboard';
  static const _actionAddDebt = 'action_add_debt';

  /// Initialize app shortcuts.
  static void init() {
    _quickActions.initialize((shortcutType) {
      appLogger.info('App shortcut tapped: $shortcutType');
    });
    _setShortcuts();
  }

  static void _setShortcuts() {
    _quickActions.setShortcutItems(<ShortcutItem>[
      const ShortcutItem(
        type: _actionNewCustomer,
        localizedTitle: 'زبون جديد',
        icon: 'ic_add_person',
      ),
      const ShortcutItem(
        type: _actionViewDashboard,
        localizedTitle: 'الرئيسية',
        icon: 'ic_dashboard',
      ),
      const ShortcutItem(
        type: _actionAddDebt,
        localizedTitle: 'إضافة دين',
        icon: 'ic_add_debt',
      ),
    ]);
  }
}
