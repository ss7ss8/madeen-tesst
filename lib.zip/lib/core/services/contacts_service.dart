import 'package:flutter/services.dart';
import 'package:flutter_contacts/flutter_contacts.dart';

class ContactsService {
  ContactsService._();

  /// Returns true if contacts permission is granted.
  static Future<bool> hasPermission() async {
    final status = await FlutterContacts.permissions.check(
      PermissionType.read,
    );
    return status == PermissionStatus.granted;
  }

  /// Request contacts permission and return true if granted.
  static Future<bool> requestPermission() async {
    final status = await FlutterContacts.permissions.request(
      PermissionType.read,
    );
    return status == PermissionStatus.granted;
  }

  /// Returns a list of contacts with phone numbers.
  static Future<List<Contact>> getContacts() async {
    final hasPerm = await requestPermission();
    if (!hasPerm) return [];

    try {
      return await FlutterContacts.getAll(
        properties: {ContactProperty.name, ContactProperty.phone},
      ).then(
        (contacts) => contacts.where((c) => c.phones.isNotEmpty).toList(),
      );
    } on PlatformException {
      return [];
    }
  }

  /// Pick a single contact using the native picker dialog.
  static Future<Contact?> pickContact() async {
    final hasPerm = await requestPermission();
    if (!hasPerm) return null;

    try {
      return await FlutterContacts.native.showPicker(
        properties: {ContactProperty.phone},
      );
    } on PlatformException {
      return null;
    }
  }
}
