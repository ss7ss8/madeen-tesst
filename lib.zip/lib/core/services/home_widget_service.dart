import 'package:home_widget/home_widget.dart';
import '../utils/logger.dart';

class HomeWidgetService {
  HomeWidgetService._();

  static const _widgetName = 'DebtTrackerWidget';

  /// Initialize the home widget plugin.
  static void init() {
    HomeWidget.registerInteractivityCallback(backgroundCallback);
  }

  /// Called when the widget background task runs.
  @pragma('vm:entry-point')
  static Future<void> backgroundCallback(Uri? uri) async {
    appLogger.info('Home widget background callback: $uri');
  }

  /// Update the widget with current data.
  static Future<void> updateWidget({
    required int totalCustomers,
    required double totalDebt,
    required int unpaidDebts,
  }) async {
    try {
      await HomeWidget.saveWidgetData<String>(
        '${_widgetName}_total_customers',
        totalCustomers.toString(),
      );
      await HomeWidget.saveWidgetData<String>(
        '${_widgetName}_total_debt',
        totalDebt.toStringAsFixed(0),
      );
      await HomeWidget.saveWidgetData<String>(
        '${_widgetName}_unpaid_debts',
        unpaidDebts.toString(),
      );
      await HomeWidget.updateWidget(
        name: _widgetName,
        androidName: _widgetName,
      );
    } catch (e) {
      appLogger.error('Home widget update error: $e');
    }
  }
}
