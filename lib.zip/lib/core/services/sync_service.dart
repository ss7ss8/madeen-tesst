import 'dart:async';
import 'dart:io';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import '../utils/logger.dart';
import '../../data/local/hive_service.dart';
import '../../data/models/customer.dart';
import '../../data/models/debt.dart';
import '../../data/models/product.dart';
import '../../data/models/payment.dart';
import '../../data/models/audit_log.dart';
import '../../data/models/settings.dart';
import 'supabase_service.dart';

const _log = Logger('Sync');

enum SyncStatus { idle, syncing, success, error }

/// Increments every time a product image is uploaded to Supabase Storage
/// during sync. Providers (e.g. [ProductsNotifier]) listen to this to
/// reload products so the UI swaps the local file path for the remote URL
/// without waiting for a full screen refresh.
final ValueNotifier<int> productImageSyncedVersion = ValueNotifier<int>(0);

/// Increments every time a synchronization run or a database restore
/// successfully finishes. Providers listen to this to reload their cached
/// lists from Hive so the UI refreshes instantly without app restart.
final ValueNotifier<int> syncCompletedVersion = ValueNotifier<int>(0);

class SyncService {
  static bool _isSyncing = false;
  static bool get isSyncing => _isSyncing;

  /// Separate flag for [restoreAllDataFromSupabase] so that a restore
  /// does not reuse [_isSyncing] (which would either skip the restore
  /// entirely if a sync was running, or block [syncAll] from running
  /// afterwards because the flag was left `true` on a restore error).
  static bool _isRestoring = false;
  static bool get isRestoring => _isRestoring;

  /// Set to `true` when [syncAll] is called while a sync is already
  /// running. The active sync loop checks this flag after each pass and
  /// runs another pass if it was set, ensuring items added to the queue
  /// mid-sync (e.g. a debt added right after its customer) are not lost.
  static bool _needsSyncAgain = false;

  /// Debounce timer for [syncAllDebounced]. Cancelled and restarted on
  /// every call so that a burst of rapid writes (add debt, pay debt, etc.)
  /// results in a single network round-trip instead of one per operation.
  static Timer? _debounceTimer;

  /// Connectivity subscription for auto-sync when the device comes online.
  static StreamSubscription<List<ConnectivityResult>>? _connectivitySub;

  /// Tracks the last connectivity state so we only trigger sync on
  /// offline → online transitions.
  static bool _wasOffline = false;

  /// Timestamp of the last successful remote data pull. Used to throttle
  /// redundant [syncAll] → [_pullRemoteChanges] calls when the queue is
  /// empty and no time has passed.
  static DateTime? _lastPullTime;

  static SyncStatus _status = SyncStatus.idle;
  static SyncStatus get status => _status;

  /// Fire-and-forget debounced sync. Multiple calls within [delay] are
  /// collapsed into a single [syncAll] call. Use this from providers after
  /// add / update / delete operations to avoid hammering the network.
  // Before: 500ms.
  // After: 2000ms — combines multiple rapid changes into a single sync
  // request, dramatically reducing network round-trips when a burst of
  // add / update / delete operations happens sequentially (e.g. adding a
  // debt plus its associated payment in quick succession).
  static void syncAllDebounced({
    Duration delay = const Duration(milliseconds: 2000),
  }) {
    _debounceTimer?.cancel();
    _debounceTimer = Timer(delay, () {
      syncAll().catchError((e) {
        _log.error('Debounced syncAll failed: $e');
      });
    });
  }

  static int pendingCount() {
    return HiveService.getSyncQueue().length;
  }

  static Future<void> init() async {
    _connectivitySub?.cancel();
    _connectivitySub = Connectivity().onConnectivityChanged.listen((results) {
      final isOnline = results.any((r) => r != ConnectivityResult.none);
      if (isOnline && _wasOffline) {
        _log.info('Connectivity restored — triggering sync');
        syncAll().catchError((e) {
          _log.error('Connectivity-triggered syncAll failed: $e');
        });
      }
      _wasOffline = !isOnline;
    });
  }

  static Future<bool> isOnline() async {
    try {
      // Stage 1: check for a network interface.
      final results = await Connectivity().checkConnectivity();
      final hasInterface = results.any((r) => r != ConnectivityResult.none);
      if (!hasInterface) return false;

      // Stage 2: verify actual internet reachability with a TCP probe.
      // This catches captive portals, offline-WiFi, and ISP outages that
      // connectivity_plus cannot detect.
      final socket = await Socket.connect(
        'supabase.com',
        443,
        timeout: const Duration(seconds: 3),
      );
      socket.destroy();
      return true;
    } catch (_) {
      // Socket connect failed or platform channel error → treat as offline.
      return false;
    }
  }

  static Future<void> syncAll() async {
    final authUserId = SupabaseService.currentUser?.id;
    _log.info('syncAll START | user=$authUserId | _isSyncing=$_isSyncing');

    if (_isSyncing) {
      // Another sync is already running. Instead of dropping this request
      // (the old behaviour that caused debts to never be synced), flag
      // that we need to sync again once the current run finishes. The
      // active loop will pick up any items added to the queue during the
      // in-progress sync (e.g. a debt added right after its customer).
      _needsSyncAgain = true;
      return;
    }
    if (!await isOnline()) {
      _status = SyncStatus.error;
      return;
    }

    _isSyncing = true;
    _status = SyncStatus.syncing;

    try {
      // Loop until no new sync requests were made during a run. This
      // guarantees that items added to the queue while we were syncing
      // are processed in a follow-up pass instead of being silently
      // dropped — the root cause of the "debt zeroed after reinstall"
      // bug.
      while (true) {
        _needsSyncAgain = false;
        // Remove duplicates from the old queue before synchronization.
        // Legacy queues (from before dedup-on-add was introduced) can
        // contain many duplicate entries per (table, record_id); we
        // collapse them down to the last-seen entry so the upstream
        // upload doesn't see "42 changes" for a handful of records.
        await _deduplicateQueue();
        await _syncQueue();
        await _pullRemoteChanges();
        await syncSettings();
        if (!_needsSyncAgain) break;
      }
      _status = SyncStatus.success;
      syncCompletedVersion.value = syncCompletedVersion.value + 1;
    } catch (e) {
      _status = SyncStatus.error;
      _log.error('syncAll error: $e');
      rethrow;
    } finally {
      _isSyncing = false;
      _needsSyncAgain = false;
      _log.info('syncAll END');
    }
  }

  /// Pulls all remote data for the current user from Supabase and writes
  /// it into the local Hive boxes. Called after [_syncQueue] drains
  /// pending local writes so that the local store reflects the latest
  /// server state.
  ///
  /// IMPORTANT: Records that still have pending entries in the sync queue
  /// are NOT overwritten. This prevents a remote pull from clobbering
  /// local changes that have not yet been pushed to the server — the root
  /// cause of the "installment paid status lost after restart" bug.
  static Future<void> _pullRemoteChanges() async {
    final userId = SupabaseService.currentUser?.id;
    if (userId == null) return;

    // Throttle: skip pulling if we just pulled within 10 seconds and there
    // are no pending local changes. This prevents redundant network calls
    // when a user triggers multiple rapid syncs (e.g. adding a debt then
    // immediately navigating), while still pulling when there's actual
    // work to do or enough time has passed for remote changes to appear.
    if (_lastPullTime != null &&
        DateTime.now().difference(_lastPullTime!) <
            const Duration(seconds: 10) &&
        HiveService.getSyncQueue().isEmpty) {
      return;
    }
    _lastPullTime = DateTime.now();

    // Build a set of record IDs that are still pending in the sync queue.
    // These must NOT be overwritten by the remote pull — the local version
    // is newer and will be pushed to the server in the next sync pass.
    final pendingIds = <String>{};
    for (final entry in HiveService.getSyncQueueWithKeys()) {
      final id = entry.value['record_id'] as String?;
      if (id != null) pendingIds.add(id);
    }
    if (pendingIds.isNotEmpty) {
      _log.warn(
        '  skipping pull-overwrite for ${pendingIds.length} pending-queue records',
      );
    }

    // ── Parallel network fetch ─────────────────────────────────────
    // Fetch all entity types concurrently — cuts pull latency from
    // 4× RTT to ~1× RTT.
    final results = await Future.wait([
      SupabaseService.getCustomers(userId),
      SupabaseService.getDebts(userId),
      SupabaseService.getProducts(userId),
      SupabaseService.getPayments(userId),
    ]);

    final remoteCustomers = results[0];
    final remoteDebts = results[1];
    final remoteProducts = results[2];
    final remotePayments = results[3];

    // ── Parallel Hive writes ───────────────────────────────────────
    // Write all non-pending records concurrently. audit:false on debts
    // and payments avoids generating audit logs for pulled data.
    int skC = 0, skD = 0, skP = 0, skPay = 0;

    await Future.wait([
      // Customers
      Future.wait(
        remoteCustomers.where((row) {
          final id = row['id'] as String?;
          if (id != null && pendingIds.contains(id)) {
            skC++;
            return false;
          }
          return true;
        }).map((row) => HiveService.saveCustomer(
              Customer.fromJson(row),
              addToSync: false,
            )),
      ),
      // Debts — skip audit log for pulled data
      Future.wait(
        remoteDebts.where((row) {
          final id = row['id'] as String?;
          if (id != null && pendingIds.contains(id)) {
            skD++;
            return false;
          }
          return true;
        }).map((row) => HiveService.saveDebt(
              Debt.fromJson(row),
              addToSync: false,
              audit: false,
            )),
      ),
      // Products
        Future.wait(
          remoteProducts.where((row) {
            final id = row['id'] as String?;
            if (id != null && pendingIds.contains(id)) {
              skP++;
              return false;
            }
            return true;
          }).map((row) async {
            final product = Product.fromJson(row);
            final remoteImageUrl = row['image_url'] as String?;
            final localProduct = HiveService.getProduct(product.id);
            final shouldPreserveLocalImage =
                (remoteImageUrl == null ||
                        remoteImageUrl.isEmpty ||
                        remoteImageUrl.startsWith('/data/')) &&
                localProduct != null &&
                localProduct.imageUrl != null &&
                localProduct.imageUrl!.isNotEmpty;
            final savedProduct = shouldPreserveLocalImage
                ? product.copyWith(imageUrl: localProduct.imageUrl)
                : product;
            return HiveService.saveProduct(
              savedProduct,
              addToSync: false,
            );
          }),
        ),
      // Payments — skip audit log for pulled data
      Future.wait(
        remotePayments.where((row) {
          final id = row['id'] as String?;
          if (id != null && pendingIds.contains(id)) {
            skPay++;
            return false;
          }
          return true;
        }).map((row) => HiveService.savePayment(
              Payment.fromJson(row),
              addToSync: false,
              audit: false,
            )),
      ),
    ]);

    _log.info(
      '  pulled ${remoteCustomers.length - skC} customers '
      '(${remoteDebts.length - skD} debts, '
      '${remoteProducts.length - skP} products, '
      '${remotePayments.length - skPay} payments) '
      '— skipped pending: $skC/$skD/$skP/$skPay',
    );

    // Audit logs do not need pull — read-only, local Hive is the source of truth.
    // Skipped to avoid pulling 1000+ rows on every sync (main-thread jank).
  }

  /// Collapses duplicate entries in the sync queue down to one per
  /// (table, record_id) combination — preserving the LAST seen entry.
  ///
  /// Why this exists: older builds of the app wrote to the queue via
  /// `_syncQueueBox.add(...)` without ever checking for duplicates. After
  /// many revisions of the same record (e.g. editing a customer's
  /// phone number ten times in a session) the queue grew to dozens of
  /// entries per record, producing "42 changes" upstream where there
  /// should have been "1 change". This pass is a one-time cleanup that
  /// runs at the start of every [syncAll], is safe to repeat, and is
  /// cheap enough (O(N) over a small in-memory list) to be unconditional.
  ///
  /// Uses the public accessors [HiveService.getSyncQueueWithKeys] and
  /// [HiveService.removeSyncQueueItemByKey] so it does not depend on
  /// any private Hive state — keeping it portable if we ever swap
  /// storage engines.
  static Future<void> _deduplicateQueue() async {
    try {
      final queue = HiveService.getSyncQueueWithKeys();
      if (queue.length < 2) return; // nothing to dedup

      // Track the first-seen key for each compound (table, record_id).
      // For anything seen more than once, the second-and-subsequent
      // keys are flagged for deletion. We preserve the FIRST entry
      // because item order in Hive matches insertion order, and the
      // newest timestamp comes from entries appended most recently;
      // since `_addToSyncQueue` is being updated to dedup on add,
      // legacy duplicates are guaranteed to be older than or equal to
      // the first existing entry — deleting them is safe.
      final seen = <String>{};
      final keysToDelete = <dynamic>[];

      for (final entry in queue) {
        final item = entry.value;
        final table = item['table']?.toString() ?? '';
        final recordId = item['record_id']?.toString() ?? '';
        if (table.isEmpty || recordId.isEmpty) continue;
        final dedupKey = '${table}_$recordId';

        if (seen.contains(dedupKey)) {
          keysToDelete.add(entry.key);
        } else {
          seen.add(dedupKey);
        }
      }

      for (final key in keysToDelete) {
        await HiveService.removeSyncQueueItemByKey(key);
      }

      if (keysToDelete.isNotEmpty) {
        _log.info(
          'Deduplicated queue: removed ${keysToDelete.length} duplicates',
        );
      }
    } catch (e) {
      // Never let a dedup glitch abort the sync. Log and continue.
      _log.error('_deduplicateQueue failed: $e');
    }
  }

  static Future<void> _syncQueue() async {
    // Read the queue WITH Hive keys so we can delete individual items
    // after a successful sync. This avoids the old bug where
    // clearSyncQueue() wiped items that were added to the queue *during*
    // this sync run (e.g. a debt added right after its customer), which
    // caused debts to never reach Supabase and appear as zero after
    // reinstall.
    final queue = HiveService.getSyncQueueWithKeys();

    if (queue.isEmpty) return;

    // ── Phase 1: Batch upserts ──────────────────────────────────────
    // Group all 'upsert' items by table and send them in a SINGLE network
    // request per table. This cuts N round-trips down to ≤5 (one per table).
    // Deletes and items that fail the batch are handled individually in
    // Phase 2 (the original per-item loop).
    final upsertBuckets = <String, List<MapEntry<dynamic, dynamic>>>{
      'customers': [],
      'debts': [],
      'products': [],
      'payments': [],
      'audit_logs': [],
    };

    final deferredItems = <MapEntry<dynamic, dynamic>>[]; // deletes + unknown

    for (final entry in queue) {
      final item = entry.value;
      final table = item['table'] as String?;
      final operation = item['operation'] as String?;
      if (table == null || operation == null) {
        deferredItems.add(entry);
        continue;
      }
      if (operation == 'upsert' && upsertBuckets.containsKey(table)) {
        upsertBuckets[table]!.add(entry);
      } else {
        // Deletes, unknown tables, and non-upsert operations → per-item.
        deferredItems.add(entry);
      }
    }

    // Process each upsert bucket as a batch.
    // Order: customers → debts → products → payments → audit_logs
    // (FK safety: payments depend on debts, so debts go first).
    for (final table in [
      'customers',
      'debts',
      'products',
      'payments',
      'audit_logs',
    ]) {
      final bucket = upsertBuckets[table]!;
      if (bucket.isEmpty) continue;

      // Build the JSON payload list and collect the queue keys to remove.
      final payloads = <Map<String, dynamic>>[];
      final keysToRemove = <dynamic>[];

      for (final entry in bucket) {
        final item = entry.value;
        final recordId = item['record_id'] as String;

        if (table == 'products') {
          final product = HiveService.getProduct(recordId);
          if (product == null) {
            _log.warn('  batch: products/$recordId not in Hive — dropping');
            keysToRemove.add(entry.key);
            continue;
          }
          try {
            final updatedProduct =
                await _uploadLocalProductImageIfNeeded(product);
            final json = updatedProduct.toJson();
            payloads.add(json);
            keysToRemove.add(entry.key);
          } catch (e) {
            _log.warn(
              '  batch: products/$recordId image upload failed — deferring: $e',
            );
            deferredItems.add(entry);
          }
          continue;
        }

        final json = _getRecordJson(table, recordId);
        if (json == null) {
          _log.warn('  batch: $table/$recordId not in Hive — dropping');
          keysToRemove.add(entry.key);
          continue;
        }
        payloads.add(json);
        keysToRemove.add(entry.key);
      }

      if (payloads.isEmpty) {
        // All items in this bucket were missing from Hive — just drop them.
        for (final key in keysToRemove) {
          await HiveService.removeSyncQueueItemByKey(key);
        }
        continue;
      }

      try {
        await _batchUpsert(table, payloads);
        _log.info('  batch upsert $table: ${payloads.length} rows OK');
        // Success — remove all processed items from the queue.
        for (final key in keysToRemove) {
          await HiveService.removeSyncQueueItemByKey(key);
        }
      } catch (e) {
        _log.error('  batch upsert $table FAILED: $e — falling back to per-item');
        // Batch failed — fall back to per-item sync for this bucket so
        // individual failures are isolated and only bad rows stay queued.
        for (final entry in bucket) {
          if (!keysToRemove.contains(entry.key)) {
            // Was already dropped (not in Hive) — skip.
            continue;
          }
          deferredItems.add(entry);
        }
      }
    }

    // ── Phase 2: Per-item sync for deletes and batch-fallback items ──
    // ترتيب الأولوية الصحيح لتجنب foreign key violations:
    // customers → debts → products → payments
    const tableOrder = ['customers', 'debts', 'products', 'payments'];
    final sorted = [
      ...deferredItems.where((e) => e.value['table'] == 'customers'),
      ...deferredItems.where((e) => e.value['table'] == 'debts'),
      ...deferredItems.where((e) => e.value['table'] == 'products'),
      ...deferredItems.where((e) => e.value['table'] == 'payments'),
      ...deferredItems.where(
        (e) => !tableOrder.contains(e.value['table'] as String),
      ),
    ];

    for (final entry in sorted) {
      final item = entry.value;
      final table = item['table'] as String;
      final recordId = item['record_id'] as String;
      final operation = item['operation'] as String;
      try {
        await _syncItem(table, recordId, operation);
        // Success: remove ONLY this item from the queue by its key.
        // Items added concurrently remain untouched and will be
        // processed in the next loop pass (see _needsSyncAgain).
        await HiveService.removeSyncQueueItemByKey(entry.key);
      } catch (e) {
        _log.error('Sync failed for $table/$recordId: $e');
        final isUnrecoverable = e.toString().contains('not in Hive');
        if (isUnrecoverable) {
          // The record no longer exists locally; drop the stale queue
          // item so it doesn't block future syncs.
          await HiveService.removeSyncQueueItemByKey(entry.key);
        }
        // Otherwise leave the item in the queue for a future retry.
      }
    }
  }

  /// Returns the JSON payload for a record, or null if it's not in Hive.
  static Map<String, dynamic>? _getRecordJson(String table, String recordId) {
    switch (table) {
      case 'customers':
        final c = HiveService.getCustomer(recordId);
        return c?.toJson();
      case 'debts':
        final d = HiveService.debts.get(recordId);
        return d?.toJson();
      case 'products':
        final p = HiveService.getProduct(recordId);
        return p?.toJson();
      case 'payments':
        final pay = HiveService.payments.get(recordId);
        if (pay == null) return null;
        final parentDebt = HiveService.debts.get(pay.debtId);
        final customerId = parentDebt?.customerId;
        if (customerId == null) return null;
        return pay.toJson(customerId: customerId);
      case 'audit_logs':
        final log = HiveService.auditLogs.get(recordId);
        return log?.toJson();
      default:
        return null;
    }
  }

  /// Sends a batch upsert for the given table.
  static Future<void> _batchUpsert(
    String table,
    List<Map<String, dynamic>> payloads,
  ) async {
    switch (table) {
      case 'customers':
        await SupabaseService.upsertCustomersBatch(payloads);
      case 'debts':
        await SupabaseService.upsertDebtsBatch(payloads);
      case 'products':
        await SupabaseService.upsertProductsBatch(payloads);
      case 'payments':
        await SupabaseService.upsertPaymentsBatch(payloads);
      case 'audit_logs':
        await SupabaseService.upsertAuditLogsBatch(payloads);
      default:
        throw Exception('Unknown table for batch: $table');
    }
  }

  static Future<void> _syncItem(
    String table,
    String recordId,
    String operation,
  ) async {
    // Implementation of individual item sync
    switch (table) {
      case 'customers':
        await _syncCustomer(recordId, operation);
        break;
      case 'debts':
        await _syncDebt(recordId, operation);
        break;
      case 'products':
        await _syncProduct(recordId, operation);
        break;
      case 'payments':
        await _syncPayment(recordId, operation);
        break;
      case 'audit_logs':
        await _syncAuditLog(recordId, operation);
        break;
      default:
        throw Exception('Unknown table: $table');
    }
  }

  static Future<void> _syncCustomer(String recordId, String operation) async {
    final customer = HiveService.getCustomer(recordId);
    if (customer == null) {
      throw Exception('Customer $recordId not in Hive');
    }

    if (operation == 'delete') {
      await SupabaseService.deleteCustomer(recordId);
    } else {
      await SupabaseService.upsertCustomer(customer.toJson());
    }
  }

  static Future<void> _syncDebt(String recordId, String operation) async {
    final debt = HiveService.debts.get(recordId);
    if (debt == null) {
      throw Exception('Debt $recordId not in Hive');
    }

    if (operation == 'delete') {
      await SupabaseService.deleteDebt(recordId);
    } else {
      await SupabaseService.upsertDebt(debt.toJson());
    }
  }

  static Future<void> _syncProduct(String recordId, String operation) async {
    var product = HiveService.getProduct(recordId);
    if (product == null) {
      throw Exception('Product $recordId not in Hive');
    }

    if (operation == 'delete') {
      await SupabaseService.deleteProduct(recordId);
    } else {
      product = await _uploadLocalProductImageIfNeeded(product);
      await SupabaseService.upsertProduct(product.toJson());
    }
  }

  static Future<Product> _uploadLocalProductImageIfNeeded(
    Product product,
  ) async {
    final imageUrl = product.imageUrl;
    _log.info(
      '_uploadLocalProductImageIfNeeded START | product=${product.id} imageUrl=$imageUrl',
    );

    // No image or already a remote URL — nothing to do.
    if (imageUrl == null || imageUrl.isEmpty || imageUrl.startsWith('http')) {
      _log.info(
        '_uploadLocalProductImageIfNeeded EARLY RETURN | product=${product.id} reason=no-image-or-remote imageUrl=$imageUrl',
      );
      return product;
    }

    // Verify the file physically exists before attempting any operation.
    final imageFile = File(imageUrl);
    if (!imageFile.existsSync()) {
      _log.info(
        '_uploadLocalProductImageIfNeeded EARLY RETURN | product=${product.id} reason=file-missing imageUrl=$imageUrl',
      );
      // Remove the broken local path from Hive so it does not block future syncs.
      final cleaned = product.copyWith(imageUrl: null);
      await HiveService.saveProduct(cleaned, addToSync: false);
      return cleaned;
    }

    File? compressedFile;
    try {
      compressedFile = await _compressProductImage(imageFile);
      final publicUrl = await SupabaseService.uploadProductImage(
        product.id,
        compressedFile.path,
      );
      if (publicUrl == null || publicUrl.isEmpty) {
        // فشل الرفع — لا نُكمل بأي مسار محلي لـSupabase (سيصبح بيانات فاسدة
        // دائمة). نرمي استثناءً لإيقاف upsert هذا المنتج في هذه الجولة،
        // فيبقى في طابور المزامنة للمحاولة التالية.
        throw Exception(
          'Product image upload returned null for ${product.id} — '
          'skipping upsert this round',
        );
      }

      final updated = product.copyWith(imageUrl: publicUrl);
      await HiveService.saveProduct(updated, addToSync: false);
      // Notify listeners that a product image URL changed so the UI can
      // reload and display the remote URL instead of the local file path.
      productImageSyncedVersion.value = productImageSyncedVersion.value + 1;
      return updated;
    } catch (e) {
      _log.error(
        'Image compress/upload failed — skipping upsert this round: $e',
      );
      // Do not stop synchronisation of OTHER products, but do NOT fall back
      // to the local path for THIS product: sending a local file path to
      // Supabase would create permanently-corrupt data. Re-throw so the
      // caller skips the upsert and the product stays in the sync queue for
      // the next attempt.
      throw Exception('Product image upload failed for ${product.id}: $e');
    } finally {
      // Clean up the temporary compressed file to prevent storage bloat
      if (compressedFile != null &&
          compressedFile.path != imageFile.path &&
          compressedFile.existsSync()) {
        try {
          compressedFile.deleteSync();
          _log.info(
            'Cleaned up temporary compressed product image: ${compressedFile.path}',
          );
        } catch (cleanupErr) {
          _log.error('Failed to delete temporary product image: $cleanupErr');
        }
      }
    }
  }

  static Future<File> _compressProductImage(File file) async {
    try {
      final baseName = file.uri.pathSegments.last.replaceAll(
        RegExp(r'\.[^.]+$'),
        '',
      );
      final targetPath =
          '${file.parent.path}/sync_${DateTime.now().millisecondsSinceEpoch}_$baseName.jpg';
      final result = await FlutterImageCompress.compressAndGetFile(
        file.absolute.path,
        targetPath,
        quality: 75,
        format: CompressFormat.jpeg,
      );
      if (result == null) {
        _log.info('Compression returned null — using original file');
        return file;
      }
      return File(result.path);
    } catch (e) {
      _log.error('compressProductImage failed: $e — using original file');
      // Return the original file so the upload can still proceed.
      return file;
    }
  }

  static Future<void> _syncPayment(String recordId, String operation) async {
    final payment = HiveService.payments.get(recordId);
    if (payment == null) {
      throw Exception('Payment $recordId not in Hive');
    }

    if (operation == 'delete') {
      await SupabaseService.deletePayment(recordId);
    } else {
      final parentDebt = HiveService.debts.get(payment.debtId);
      final customerId = parentDebt?.customerId;
      if (customerId == null) {
        throw Exception(
          'Cannot sync payment $recordId: parent debt ${payment.debtId} '
          'not found or has no customerId',
        );
      }
      await SupabaseService.upsertPayment(
        payment.toJson(customerId: customerId),
      );
    }
  }

  static Future<void> _syncAuditLog(String recordId, String operation) async {
    final log = HiveService.auditLogs.get(recordId);
    if (log == null) {
      throw Exception('Audit log $recordId not in Hive');
    }

    if (operation == 'delete') {
      await SupabaseService.deleteAuditLog(recordId);
    } else {
      await SupabaseService.upsertAuditLog(log.toJson());
    }
  }

  /// Uploads the user's local settings to the Supabase `user_settings`
  /// table so they survive app reinstall and account switching.
  ///
  /// This is a best-effort sync: failures are logged but not rethrown so
  /// that callers (e.g. [SettingsNotifier.update]) can fire-and-forget
  /// without crashing the UI. When called from [syncAll], however, errors
  /// propagate normally.
  static Future<void> syncSettings() async {
    final userId = SupabaseService.currentUser?.id;
    if (userId == null) return;

    try {
      final settings = HiveService.getAppSettings();

      // Guard: do NOT push factory-default settings over a real server record.
      // This prevents the post-restore syncAll from overwriting freshly restored
      // user settings with the app's built-in defaults (store name "متجري", etc.).
      // If the local settings have never been tied to a user AND still carry the
      // factory store name, we check whether the server has a real row first.
      if (settings.userId == null && settings.storeName == 'متجري') {
        try {
          final existing = await SupabaseService.getUserSettings(userId);
          if (existing != null) {
            return;
          }
        } catch (_) {
          // Cannot verify — proceed with upload as safe fallback.
        }
      }

      // Ensure the row is tied to the current authenticated user.
      settings.userId = userId;
      final payload = settings.toJson();
      // upsertUserSettings relies on user_id as the primary key.
      await SupabaseService.upsertUserSettings(payload);
      _log.info('syncSettings: uploaded settings for user $userId');
    } catch (e) {
      _log.error('syncSettings: failed: $e');
      // Best-effort: log the error but do not rethrow. A settings upload
      // failure must not abort the rest of syncAll (queue drain + pull).
    }
  }

  static Future<void> restoreAllDataFromSupabase() async {
    final userId = SupabaseService.currentUser?.id;
    if (userId == null) return;

    if (_isRestoring) return;

    _isRestoring = true;
    _log.info('restoreAllDataFromSupabase START');

    try {
      // ── Parallel network fetch ─────────────────────────────────────
      // Fetch all entity types concurrently instead of sequentially.
      // This cuts restore latency from ~6× RTT to ~1× RTT for the fetch phase.
      final results = await Future.wait([
        SupabaseService.getCustomers(userId).catchError((e) {
          _log.error('  customers fetch failed: $e');
          return <Map<String, dynamic>>[];
        }),
        SupabaseService.getProducts(userId).catchError((e) {
          _log.error('  products fetch failed: $e');
          return <Map<String, dynamic>>[];
        }),
        SupabaseService.getDebts(userId).catchError((e) {
          _log.error('  debts fetch failed: $e');
          return <Map<String, dynamic>>[];
        }),
        SupabaseService.getPayments(userId).catchError((e) {
          _log.error('  payments fetch failed: $e');
          return <Map<String, dynamic>>[];
        }),
        SupabaseService.getAuditLogs(userId).catchError((e) {
          _log.error('  audit logs fetch failed: $e');
          return <Map<String, dynamic>>[];
        }),
        SupabaseService.getUserSettings(userId).catchError((e) {
          _log.error('  settings fetch failed: $e');
          return null;
        }),
      ]);

      final remoteCustomers = results[0] as List<Map<String, dynamic>>;
      final remoteProducts = results[1] as List<Map<String, dynamic>>;
      final remoteDebts = results[2] as List<Map<String, dynamic>>;
      final remotePayments = results[3] as List<Map<String, dynamic>>;
      final remoteLogs = results[4] as List<Map<String, dynamic>>;
      final remoteSettings = results[5] as Map<String, dynamic>?;

      // ── Parallel Hive writes ───────────────────────────────────────
      // Write all records of each type concurrently. Hive box.put is safe
      // for concurrent writes to different keys. audit:false skips the
      // per-record audit-log write (and its sync-queue entry), cutting
      // Hive writes from N×4 down to N×1 during restore.
      final now = DateTime.now();

      await Future.wait([
        // Customers
        Future.wait(
          remoteCustomers.map((row) {
            return HiveService.saveCustomer(
              Customer.fromJson(Map<String, dynamic>.from(row)),
              addToSync: false,
            );
          }),
        ),
        // Products
        Future.wait(
          remoteProducts.map((row) async {
            final product =
                Product.fromJson(Map<String, dynamic>.from(row));
            final remoteImageUrl = row['image_url'] as String?;
            final localProduct = HiveService.getProduct(product.id);
            final shouldPreserveLocalImage =
                (remoteImageUrl == null ||
                        remoteImageUrl.isEmpty ||
                        remoteImageUrl.startsWith('/data/')) &&
                localProduct != null &&
                localProduct.imageUrl != null &&
                localProduct.imageUrl!.isNotEmpty;
            final savedProduct = shouldPreserveLocalImage
                ? product.copyWith(imageUrl: localProduct.imageUrl)
                : product;
            return HiveService.saveProduct(
              savedProduct,
              addToSync: false,
            );
          }),
        ),
        // Debts — skip audit log during restore
        Future.wait(
          remoteDebts.map((row) {
            final debt = Debt.fromJson(Map<String, dynamic>.from(row));
            debt.isSynced = true;
            debt.lastSyncedAt = now;
            return HiveService.saveDebt(debt, addToSync: false, audit: false);
          }),
        ),
        // Payments — skip audit log during restore
        Future.wait(
          remotePayments.map((row) {
            return HiveService.savePayment(
              Payment.fromJson(Map<String, dynamic>.from(row)),
              addToSync: false,
              audit: false,
            );
          }),
        ),
        // Audit logs
        Future.wait(
          remoteLogs.map((row) {
            final log = AuditLog.fromJson(Map<String, dynamic>.from(row));
            return HiveService.auditLogs.put(log.id, log);
          }),
        ),
      ]);

      _log.info(
        '  restored ${remoteCustomers.length} customers, '
        '${remoteProducts.length} products, '
        '${remoteDebts.length} debts, '
        '${remotePayments.length} payments, '
        '${remoteLogs.length} audit logs',
      );

      // ── User Settings ──────────────────────────────────────────────
      if (remoteSettings != null) {
        try {
          await HiveService.saveSettings(
            AppSettings.fromJson(Map<String, dynamic>.from(remoteSettings)),
          );
          _log.info('  restored user settings');
        } catch (e) {
          _log.error('  settings restore failed: $e');
        }
      }

      // Mark a fresh pull so the post-restore syncAll skips _pullRemoteChanges
      // — we just downloaded everything, no need to re-download immediately.
      _lastPullTime = DateTime.now();

      syncCompletedVersion.value = syncCompletedVersion.value + 1;
      _log.info('restoreAllDataFromSupabase END');
    } finally {
      _isRestoring = false;
    }
  }
}
