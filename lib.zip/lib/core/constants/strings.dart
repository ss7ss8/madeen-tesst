class AppStrings {
  AppStrings._();

  // App Info
  static const String appName = 'ديوني';
  static const String appDescription = 'إدارة ديون الزبائن';

  // Navigation
  static const String dashboard = 'الرئيسية';
  static const String customers = 'الزبائن';
  static const String inventory = 'المخزون';
  static const String reports = 'التقارير';
  static const String settings = 'الإعدادات';

  // Dashboard
  static const String totalDebts = 'إجمالي الديون';
  static const String totalCustomers = 'عدد الزبائن';
  static const String totalProducts = 'المنتجات';
  static const String lastOperation = 'آخر عملية';
  static const String monthlyDebts = 'الديون الشهرية';
  static const String addCustomer = 'إضافة زبون';

  // Customers
  static const String customerName = 'اسم الزبون';
  static const String phoneNumber = 'رقم الهاتف';
  static const String debtAmount = 'المبلغ';
  static const String product = 'المنتج';
  static const String selectProduct = 'اختر منتج';
  static const String date = 'التاريخ';
  static const String search = 'بحث';
  static const String filter = 'فلترة';
  static const String mostIndebted = 'الأكثر ديناً';
  static const String recent = 'الأحدث';
  static const String paid = 'تم التسديد';
  static const String all = 'الكل';

  // Customer Detail
  static const String debtHistory = 'سجل الديون';
  static const String payDebt = 'تسديد دين';
  static const String addDebt = 'إضافة دين جديد';
  static const String sendReminder = 'تذكير عبر واتساب';
  static const String call = 'اتصال';
  static const String shareInvoice = 'مشاركة الفاتورة';
  static const String fullPayment = 'تسديد كلي';
  static const String partialPayment = 'تسديد جزئي';
  static const String remaining = 'المتبقي';

  // Inventory
  static const String productName = 'اسم المنتج';
  static const String purchasePrice = 'سعر الشراء';
  static const String salePrice = 'سعر البيع';
  static const String quantity = 'الكمية';
  static const String addProduct = 'إضافة منتج';
  static const String editProduct = 'تعديل المنتج';
  static const String deleteProduct = 'حذف المنتج';
  static const String takePhoto = 'تصوير';
  static const String chooseFromGallery = 'اختيار من المعرض';

  // Reports
  static const String daily = 'يومي';
  static const String weekly = 'أسبوعي';
  static const String monthly = 'شهري';
  static const String totalPaid = 'إجمالي المسدد';
  static const String topCustomers = 'أكثر الزبائن ديناً';
  static const String topProducts = 'أكثر المنتجات مبيعاً';
  static const String exportPdf = 'تصدير PDF';
  static const String exportExcel = 'تصدير Excel';

  // Profit Reports (New Feature F5)
  static const String netProfit = 'صافي الربح';
  static const String profitReport = 'تقرير صافي الربح';
  static const String totalRevenue = 'إجمالي الإيرادات';
  static const String totalCost = 'إجمالي التكلفة';
  static const String profitMargin = 'هامش الربح';
  static const String profitMarginLow = 'ربح منخفض';
  static const String profitMarginThreshold = 'عتبة هامش الربح المنخفض';
  static const String profitTrend = 'اتجاه الربح';
  static const String topProfitableProducts = 'أكثر المنتجات ربحية';
  static const String productDetails = 'تفاصيل المنتج';
  static const String salesHistory = 'تاريخ المبيعات';
  static const String recentSales = 'سجل المبيعات الأخيرة';
  static const String salesSummary = 'ملخص المبيعات';
  static const String totalSold = 'إجمالي المبيعات';
  static const String averageProfitPerUnit = 'متوسط ربح/وحدة';
  static const String topBuyers = 'أكثر الزبائن شراءً';
  static const String priceDataCoverage = 'تغطية بيانات الأسعار';
  static const String businessSettings = 'إعدادات الأعمال';
  static const String profitAnalysis = 'تحليل الربحية';

  // Settings
  static const String storeInfo = 'معلومات المتجر';
  static const String storeName = 'اسم المتجر';
  static const String storeLogo = 'شعار المتجر';
  static const String account = 'الحساب';
  static const String signInWithGoogle = 'تسجيل الدخول بـ Google';
  static const String signOut = 'تسجيل الخروج';
  static const String appearance = 'المظهر';
  static const String darkMode = 'الوضع الليلي';
  static const String themeColor = 'اللون الأساسي';
  static const String fontFamily = 'نوع الخط';
  static const String background = 'الخلفية';
  static const String solidColor = 'لون متجانس';
  static const String gradient = 'تدرج لوني';
  static const String image = 'صورة';
  static const String backup = 'النسخ الاحتياطي';
  static const String autoBackup = 'نسخ احتياطي تلقائي';
  static const String backupNow = 'نسخ احتياطي الآن';
  static const String lastBackup = 'آخر نسخ احتياطي';
  static const String exportToFile = 'تصدير نسخة احتياطية';
  static const String exportToFileDesc = 'حفظ نسخة احتياطية كملف على الجهاز';
  static const String importFromFile = 'استيراد نسخة احتياطية';
  static const String importFromFileDesc =
      'استعادة البيانات من ملف نسخة احتياطية';
  static const String shareBackup = 'مشاركة النسخة الاحتياطية';
  static const String shareBackupDesc =
      'مشاركة ملف النسخة الاحتياطية عبر واتساب أو غيره';

  // Actions
  static const String save = 'حفظ';
  static const String cancel = 'إلغاء';
  static const String delete = 'حذف';
  static const String edit = 'تعديل';
  static const String confirm = 'تأكيد';
  static const String done = 'تم';
  static const String retry = 'إعادة المحاولة';

  // Messages
  static const String loading = 'جاري التحميل...';
  static const String noData = 'لا توجد بيانات';
  static const String noCustomers = 'لا يوجد زبائن';
  static const String noProducts = 'لا توجد منتجات';
  static const String noDebts = 'لا توجد ديون';
  static const String confirmDelete = 'هل أنت متأكد من الحذف؟';
  static const String successSaved = 'تم الحفظ بنجاح';
  static const String successDeleted = 'تم الحذف بنجاح';
  static const String errorOccurred = 'حدث خطأ';
  static const String checkConnection = 'تحقق من الاتصال بالإنترنت';
  static const String syncing = 'جاري المزامنة...';
  static const String syncComplete = 'تمت المزامنة';
  static const String offline = 'غير متصل';
  static const String online = 'متصل';

  // Validation
  static const String required = 'هذا الحقل مطلوب';
  static const String invalidPhone = 'رقم الهاتف غير صحيح';
  static const String invalidAmount = 'المبلغ غير صحيح';

  // WhatsApp Message Template
  static const String whatsappReminderTemplate =
      'أهلاً {name} 👋\n'
      'نذكّرك بأنه تبقى عليك {amount} دينار عراقي.\n'
      'للتفاهم أو السداد، تواصل معنا.';

  // Reliability
  static const String reliability = 'الموثوقية';
  static const String reliable = 'موثوق';
  static const String medium = 'متوسط';
  static const String unreliable = 'غير موثوق';
  static const String paysOnTime = 'يسدد في الوقت المحدد';
  static const String overdue30 = 'متأخر 30-90 يوم';
  static const String overdue90 = 'متأخر أكثر من 90 يوم';
  static const String reliabilityLegend =
      'دائرة ملونة بجانب الصورة توضح مستوى الموثوقية';

  // Currency
  static const String currency = 'د.ع';
  static const String currencyFull = 'دينار عراقي';
}
